# AI Requirements & Project Management Assistant

An original, production-grade application for agile requirement analysis, sprint planning, scrum boards, risk tracking, and project intelligence.

Powered by a **React + TypeScript + Tailwind CSS** frontend connected directly to **Supabase** for user authentication and relational database persistence, with an isolated AI mock service layer ready for real LLM grounding.

---

## 🚀 Environment Variables & Supabase Setup

The application reads configuration from client-side environment variables defined in `.env`:

```bash
# Supabase Project URL
VITE_SUPABASE_URL="https://mmfxzkkmnigoptzjbiue.supabase.co"

# Supabase Publishable/Anon Key (never use service_role key on the client)
VITE_SUPABASE_PUBLISHABLE_KEY="sb_publishable_dcyRFxTp_qCEMorNKT59Ew_588DMV2-"
```

If these environment variables are missing or unconfigured, the application presents a clear in-app warning notification and allows users to continue in isolated **Guest Mode**.

---

## 🔐 Authentication & Access Modes

1. **Email & Password Authentication**:
   * Uses `supabase.auth.signInWithPassword` and `supabase.auth.signUp`.
   * Supports email confirmation workflow: if Supabase requires email verification, a prompt directs users to check their inbox.
   * Includes self-service password reset via `authService.resetPasswordForEmail`.
2. **Google OAuth**:
   * Uses `supabase.auth.signInWithOAuth({ provider: 'google' })`.
   * To enable: In your Supabase Dashboard, go to **Authentication -> Providers -> Google**, enable the toggle, and supply your Google Cloud OAuth Client ID and Secret.
3. **Guest Mode**:
   * Completely isolated in-memory workspace initialized with rich sample data.
   * **Guest mode never touches Supabase** and clears all temporary data upon browser refresh.

---

## 🗄️ Database Tables & Schema Architecture

All database queries and mutations in `/src/services/supabaseService.ts` map between client models and the user's Supabase tables:

| Supabase Table | Purpose & Key Fields | Client Mapping / Triggers |
| :--- | :--- | :--- |
| `projects` | `id, owner_id, name, description, goal, project_type, start_date, target_date, project_manager, archived, created_at` | `owner_id` defaults to `auth.uid()`. Health status is dynamically calculated from tasks and risks. |
| `project_members` | `id, project_id, name, email, role` | Loaded and displayed as project team avatars. |
| `sprints` | `id, project_id, name, goal, start_date, end_date, status[planned\|active\|completed], created_at` | Only **one** sprint per project can be `'active'`. Conflicting activations are caught with user feedback. |
| `user_stories` | `id, project_id, story_number, title, description, priority, story_points, acceptance_criteria jsonb, related_requirement, status, sprint_id, sort_order, created_at` | `story_number` is auto-assigned by database triggers and displayed with zero-padding as `US-001`. |
| `tasks` | `id, project_id, story_id, sprint_id, task_number, title, description, status[todo\|in_progress\|review\|done], priority, assignee, due_date, is_blocked, blocked_reason, created_at, updated_at` | `task_number` is auto-assigned by DB trigger and displayed as `T-001`. Status moves update optimistically with rollback on failure. |
| `task_status_history` | `id, task_id, from_status, to_status, changed_by, changed_at` | Automatically recorded on every task status transition. |
| `risks` | `id, project_id, title, description, impact, probability, status, mitigation_plan, owner, ai_suggested, confirmed, created_at` | AI-suggested risks saved with `ai_suggested = true, confirmed = false`. |
| `dependencies` | `id, project_id, title, depends_on, status, created_at` | Maps dependency chain between project deliverables. |
| `decisions` | `id, project_id, item, description, owner, requested_from, due_date, status, created_at` | Tracks critical path approvals with urgency alerts. |
| `retrospectives` | `id, project_id, sprint_id, went_well jsonb, didnt_go_well jsonb, improve jsonb, created_at` | Retrospective boards saved per sprint iteration. |
| `reports` | `id, project_id, report_type, title, content, created_at` | Markdown status reports compiled and persisted. |
| `chats` & `messages` | `chats(id, user_id, title)` & `messages(id, chat_id, role, content, attachments jsonb)` | Requirement analysis chat sessions and history. Attachments store `{ name, size, type, path }`. |
| `project_documents` | `id, project_id, file_name, file_path, file_size, mime_type, created_at` | Metadata for uploaded project specification artifacts and assets. |
| `project_chat_messages` | `id, project_id, role, content, created_at` | Persistent project-specific AI assistant chat logs. |

---

## 📦 Supabase Storage ("user-files" Bucket)

The application stores all uploaded binary artifacts in the private Supabase Storage bucket **`user-files`**:

1. **Storage Path Conventions**:
   * **Requirement Chat Attachments**: `{user_id}/chat/{chat_id}/{timestamp}-{sanitized_file_name}`
   * **Project Documents**: `{user_id}/projects/{project_id}/{timestamp}-{sanitized_file_name}`
2. **Access Control & Multi-Tenant Security**:
   * Row-level and storage policies enforce that each signed-in user can only read, write, and delete files inside folders prefixed with their own `auth.uid()`.
   * Files from one user account are inaccessible to any other user account.
3. **Signed URLs**:
   * All file downloads and previews use temporary signed URLs generated via `supabase.storage.from('user-files').createSignedUrl(path, 3600)`.
   * Public URLs are never used.
4. **Validation & Limits**:
   * Maximum file size: **20 MB** per file.
   * Allowed file formats: **PDF, DOCX, TXT, MD, CSV, XLSX, PPTX, PNG, JPG**.
   * File names are sanitized to remove special characters while preserving original extensions.
5. **Lifecycle Cleanup**:
   * Deleting a requirement chat automatically purges all storage objects under `{user_id}/chat/{chat_id}/`.
   * Deleting a project workspace automatically removes all its storage objects under `{user_id}/projects/{project_id}/` and clears rows from `project_documents`.
6. **Guest Mode Isolation**:
   * Guests operate entirely in client-side memory and never make storage calls to Supabase.

## 🤖 Real AI Integration (Google Gemini API via Supabase Edge Function)

The application connects directly to Google Gemini via a secure Supabase Edge Function (**`ai-gateway`**):

### 1. Architecture & Zero-Client-Key Security
* **No Client Keys**: The Google Gemini API key is **never** included in frontend bundles or `VITE_` variables. The frontend communicates exclusively with `{VITE_SUPABASE_URL}/functions/v1/ai-gateway`.
* **Server Secrets**: The Edge Function reads the API key and model dynamically from Supabase project secrets:
  * `GEMINI_API_KEY`: Your Google Gemini API key.
  * `GEMINI_MODEL`: Model name (e.g. `gemini-2.5-flash`, `gemini-1.5-pro`). Never hardcoded.
* **Streamed & Structured Execution**:
  * **Streamed Actions** (`requirement_chat`, `project_assistant`, `status_report`, `sprint_summary`): Re-emits Gemini's stream as Server-Sent Events (`text/event-stream`): `{"delta":"..."}` chunks followed by `{"done":true}`.
  * **Structured JSON Actions** (`generate_tasks`, `analyze_risks`, `project_summary`, `goal_analysis`, `sprint_plan`, `retro_suggestions`, `followup_message`, `schedule_impact`): Employs Gemini's native JSON mode (`responseMimeType: "application/json"` with formal `responseSchema`) to guarantee type-safe, validated outputs.
* **Stop Generating & Disconnect Handling**: Cleanly supports client `AbortController` cancellation, retaining partial tokens generated so far.
* **Guest & Auth Handling**: Authenticated users send `Authorization: Bearer <user access token>`, while guests provide the publishable key and send in-memory project data.

### 2. Multi-Modal File Reading & Security Isolation
In the **Requirement Analysis** chat, attached files are parsed server-side before querying Gemini:
* **Storage Retrieval**: For signed-in users, the Edge Function securely downloads attachments from the private `user-files` bucket using the user's authenticated client token.
* **Format Parsers**:
  * **PDF & Images (PNG/JPG)**: Transmitted directly to Gemini as multi-modal inline data parts (`inline_data: { mime_type, data: base64 }`). Capped with a clear notification if the file exceeds 15 MB.
  * **TXT, MD, CSV**: Decoded directly as clean UTF-8 text.
  * **DOCX**: Extracted into clean text using `npm:mammoth`.
  * **XLSX**: Sheets and tables parsed into formatted text tables using `npm:xlsx`.
  * **PPTX**: Slide XML extracted from the archive using `npm:jszip`.
* **Prompt Isolation & Security Guardrails**:
  * Extracted text is capped at **100,000 characters** per document with truncation notices if exceeded.
  * File contents are wrapped in explicit delimiters: `<<<DOCUMENT_DATA: filename>>> ... <<<END_DOCUMENT_DATA>>>`.
  * The system prompt instructs Gemini to treat file contents strictly as passive data and ignore any instructions or jailbreaks contained within uploaded files.
* **Guest File Uploads**: Guests send files (max 5 MB) converted to base64 directly in the request payload.

### 3. Deploying the Supabase Edge Function
To deploy the `ai-gateway` function to your Supabase project:

```bash
# 1. Set required secrets in your Supabase project
supabase secrets set GEMINI_API_KEY="your_actual_gemini_api_key"
supabase secrets set GEMINI_MODEL="gemini-2.5-flash"

# 2. Deploy the Edge Function
supabase functions deploy ai-gateway
```

### 4. Rate Limiting & `ai_usage` Table
Rate limiting is enforced by the Edge Function using the Supabase `ai_usage` table with the service role key:
* **Signed-in users**: 60 requests/hour (keyed by `user.id`).
* **Guests**: 10 requests/hour (keyed by client IP address).
* **Cap**: 32,000 max input characters and 4,096 max output tokens. Prompts and keys are never logged.

If not already present, create the `ai_usage` table in your Supabase SQL editor:
```sql
CREATE TABLE IF NOT EXISTS public.ai_usage (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_key TEXT NOT NULL,
  action TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ai_usage_window ON public.ai_usage (user_key, action, created_at);
```

---

## 🧠 Service Layer & AI Boundaries

* **Real AI & Supabase Connected Services**:
  * `/supabase/functions/ai-gateway/index.ts`: Edge Function gateway calling Gemini REST API with SSE streaming, multi-modal file parsing, and structured JSON schemas.
  * `/src/services/ai/aiClient.ts`: Client-side consumer for all AI actions (streamed and non-streamed) with typed error handling and abort support.
  * `/src/services/authService.ts`: Real Supabase authentication, session persistence, and OAuth.
  * `/src/services/supabaseService.ts`: Real Supabase database queries, mutations, and storage with RLS.

---

## 🛠️ Development & Build

```bash
# Install dependencies
npm install

# Start development server on port 3000
npm run dev

# Run linting
npm run lint

# Compile production bundle
npm run build
```
