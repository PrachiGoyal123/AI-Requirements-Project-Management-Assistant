/**
 * File validation and sanitization utilities for Supabase Storage uploads.
 */

export const MAX_FILE_SIZE_BYTES = 20 * 1024 * 1024; // 20 MB

export const ALLOWED_EXTENSIONS = [
  '.pdf',
  '.docx',
  '.txt',
  '.md',
  '.csv',
  '.xlsx',
  '.pptx',
  '.png',
  '.jpg',
  '.jpeg',
];

export const ALLOWED_MIME_TYPES = [
  'application/pdf',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/msword',
  'text/plain',
  'text/markdown',
  'text/x-markdown',
  'text/csv',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'image/png',
  'image/jpeg',
  'image/jpg',
];

export interface FileValidationResult {
  valid: boolean;
  error?: string;
}

/**
 * Validates a file against max size (20MB) and allowed extensions/mime types.
 */
export function validateFile(file: File): FileValidationResult {
  if (file.size > MAX_FILE_SIZE_BYTES) {
    return {
      valid: false,
      error: `"${file.name}" exceeds the maximum allowed size of 20 MB (${(file.size / (1024 * 1024)).toFixed(1)} MB).`,
    };
  }

  const name = file.name.toLowerCase();
  const hasAllowedExt = ALLOWED_EXTENSIONS.some((ext) => name.endsWith(ext));
  const hasAllowedMime = ALLOWED_MIME_TYPES.includes(file.type.toLowerCase());

  if (!hasAllowedExt && !hasAllowedMime) {
    return {
      valid: false,
      error: `"${file.name}" has an unsupported format. Allowed types: PDF, DOCX, TXT, MD, CSV, XLSX, PPTX, PNG, JPG.`,
    };
  }

  return { valid: true };
}

/**
 * Sanitizes a file name by removing spaces and special characters while preserving extension.
 */
export function sanitizeFileName(fileName: string): string {
  const lastDot = fileName.lastIndexOf('.');
  const ext = lastDot !== -1 ? fileName.slice(lastDot).toLowerCase() : '';
  const base = lastDot !== -1 ? fileName.slice(0, lastDot) : fileName;
  const cleanBase = base
    .replace(/[^a-zA-Z0-9_\-\.]/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 80);
  return `${cleanBase || 'file'}${ext}`;
}

/**
 * Formats bytes to human-readable size string.
 */
export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1048576).toFixed(1)} MB`;
}
