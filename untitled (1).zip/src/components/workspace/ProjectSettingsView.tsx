import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../store/AppContext';
import { ProjectType, TeamMember, ProjectDocument } from '../../types/project';
import { validateFile, formatFileSize } from '../../lib/fileValidation';
import { supabaseService } from '../../services/supabaseService';
import { ConfirmDialog } from '../common/ConfirmDialog';
import { 
  Save, 
  Trash2, 
  Archive, 
  Plus, 
  Users, 
  FileText, 
  AlertTriangle,
  Check,
  Upload,
  Download,
  Loader2
} from 'lucide-react';

export const ProjectSettingsView: React.FC = () => {
  const navigate = useNavigate();
  const { 
    user, 
    isGuest, 
    currentProject, 
    updateProject, 
    archiveProject, 
    deleteProject, 
    addProjectDocument, 
    deleteProjectDocument, 
    addToast 
  } = useApp();

  if (!currentProject) return null;

  const [name, setName] = useState(currentProject.name);
  const [description, setDescription] = useState(currentProject.description);
  const [goal, setGoal] = useState(currentProject.goal);
  const [startDate, setStartDate] = useState(currentProject.startDate);
  const [endDate, setEndDate] = useState(currentProject.endDate);
  const [projectType, setProjectType] = useState<ProjectType>(currentProject.projectType);
  const [projectManager, setProjectManager] = useState(currentProject.projectManager);
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>(currentProject.teamMembers);

  // New member inputs
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberEmail, setNewMemberEmail] = useState('');
  const [newMemberRole, setNewMemberRole] = useState('Frontend Engineer');

  // Delete & Archive Confirm State
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [isArchiveConfirmOpen, setIsArchiveConfirmOpen] = useState(false);

  // Document management states
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploadingDoc, setIsUploadingDoc] = useState(false);
  const [downloadingDocId, setDownloadingDocId] = useState<string | null>(null);
  const [docToDelete, setDocToDelete] = useState<ProjectDocument | null>(null);
  const [isDeleteDocConfirmOpen, setIsDeleteDocConfirmOpen] = useState(false);

  const handleSaveInfo = (e: React.FormEvent) => {
    e.preventDefault();
    updateProject(currentProject.id, {
      name: name.trim(),
      description: description.trim(),
      goal: goal.trim(),
      startDate,
      endDate,
      projectType,
      projectManager: projectManager.trim(),
      teamMembers,
    });
  };

  const handleAddMember = () => {
    if (!newMemberName.trim() || !newMemberEmail.trim()) {
      addToast({ title: 'Missing Info', message: 'Name and email are required.', type: 'warning' });
      return;
    }

    const initials = newMemberName
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2) || 'TM';

    const member: TeamMember = {
      id: `tm-${Date.now().toString(36)}`,
      name: newMemberName.trim(),
      email: newMemberEmail.trim(),
      role: newMemberRole,
      avatarInitials: initials,
    };

    const updated = [...teamMembers, member];
    setTeamMembers(updated);
    updateProject(currentProject.id, { teamMembers: updated });
    setNewMemberName('');
    setNewMemberEmail('');
    addToast({ title: 'Team Member Added', type: 'success' });
  };

  const handleRemoveMember = (id: string) => {
    const updated = teamMembers.filter((m) => m.id !== id);
    setTeamMembers(updated);
    updateProject(currentProject.id, { teamMembers: updated });
    addToast({ title: 'Member Removed', type: 'info' });
  };

  const handleArchive = () => {
    archiveProject(currentProject.id);
    navigate('/projects');
  };

  const handleDelete = () => {
    deleteProject(currentProject.id);
    navigate('/projects');
  };

  // Document upload handler
  const handleUploadDocument = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    const validation = validateFile(file);
    if (!validation.valid) {
      addToast({
        title: 'File Rejected',
        message: validation.error || 'Invalid file format or size.',
        type: 'error',
      });
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    setIsUploadingDoc(true);
    try {
      await addProjectDocument(currentProject.id, file);
    } catch (err: any) {
      console.error('Failed to upload document:', err);
      addToast({
        title: 'Upload Failed',
        message: err.message || 'Could not upload document.',
        type: 'error',
      });
    } finally {
      setIsUploadingDoc(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Document download handler (Signed URL)
  const handleDownloadDoc = async (doc: ProjectDocument) => {
    if (!doc.filePath) {
      addToast({
        title: 'Local Document',
        message: `${doc.name} (${doc.size})`,
        type: 'info',
      });
      return;
    }

    setDownloadingDocId(doc.id);
    try {
      // Using private signed URL with 3600 seconds expiration (never public)
      const signedUrl = await supabaseService.createSignedUrl(doc.filePath, 3600);
      const link = document.createElement('a');
      link.href = signedUrl;
      link.download = doc.name;
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      addToast({ title: 'Downloading file...', message: doc.name, type: 'info' });
    } catch (err: any) {
      console.error('Error generating signed URL:', err);
      addToast({
        title: 'Download Failed',
        message: err.message || 'Your session may have expired. Please log in again.',
        type: 'error',
      });
    } finally {
      setDownloadingDocId(null);
    }
  };

  // Document delete confirmation handler
  const handleConfirmDeleteDoc = async () => {
    if (!docToDelete) return;
    try {
      await deleteProjectDocument(currentProject.id, docToDelete.id, docToDelete.filePath);
    } catch (err: any) {
      console.error('Delete doc error:', err);
    } finally {
      setIsDeleteDocConfirmOpen(false);
      setDocToDelete(null);
    }
  };

  return (
    <div className="space-y-8 max-w-4xl">
      
      {/* Title */}
      <div className="pb-4 border-b border-stone-200 dark:border-stone-800">
        <h1 className="text-xl font-bold tracking-tight text-stone-900 dark:text-stone-100">
          Project Settings
        </h1>
        <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
          Manage workspace configuration, team members, uploaded project artifacts, and project lifecycle.
        </p>
      </div>

      {/* Section 1: General Info */}
      <form onSubmit={handleSaveInfo} className="p-6 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs space-y-4">
        <h2 className="text-xs font-bold uppercase tracking-wider text-teal-800 dark:text-teal-400">
          General Project Details
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="sm:col-span-2">
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Project Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 text-stone-900 dark:text-stone-100"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Description
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 leading-relaxed"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Project Goal
            </label>
            <textarea
              rows={2}
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 leading-relaxed"
            />
          </div>

          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Project Type
            </label>
            <select
              value={projectType}
              onChange={(e) => setProjectType(e.target.value as ProjectType)}
              className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
            >
              <option value="Agile Scrum">Agile Scrum</option>
              <option value="Kanban Delivery">Kanban Delivery</option>
              <option value="Product Discovery">Product Discovery</option>
              <option value="Enterprise Migration">Enterprise Migration</option>
              <option value="MVP Launch">MVP Launch</option>
            </select>
          </div>

          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Project Manager
            </label>
            <input
              type="text"
              value={projectManager}
              onChange={(e) => setProjectManager(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
            />
          </div>

          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Start Date
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
            />
          </div>

          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Target Completion Date
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
            />
          </div>
        </div>

        <div className="pt-3 border-t border-stone-100 dark:border-stone-800 flex justify-end">
          <button
            type="submit"
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs transition-colors"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save General Details</span>
          </button>
        </div>
      </form>

      {/* Section 2: Team Members */}
      <div className="p-6 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs space-y-4">
        <h2 className="text-xs font-bold uppercase tracking-wider text-teal-800 dark:text-teal-400">
          Manage Team Members &amp; Roles ({teamMembers.length})
        </h2>

        <div className="space-y-2">
          {teamMembers.map((tm) => (
            <div
              key={tm.id}
              className="flex items-center justify-between p-3 rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-50/40 dark:bg-stone-950 text-xs"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-teal-700 text-white font-bold text-xs flex items-center justify-center">
                  {tm.avatarInitials}
                </div>
                <div>
                  <p className="font-semibold text-stone-900 dark:text-stone-100">{tm.name}</p>
                  <p className="text-[11px] text-stone-400">{tm.email} · {tm.role}</p>
                </div>
              </div>

              {teamMembers.length > 1 && (
                <button
                  type="button"
                  onClick={() => handleRemoveMember(tm.id)}
                  className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg"
                  title="Remove"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          ))}
        </div>

        {/* Add Member Row */}
        <div className="p-3 rounded-xl border border-dashed border-stone-200 dark:border-stone-800 grid grid-cols-1 sm:grid-cols-4 gap-2 items-end text-xs">
          <div>
            <label className="block text-[11px] text-stone-500 mb-1">Full Name</label>
            <input
              type="text"
              value={newMemberName}
              onChange={(e) => setNewMemberName(e.target.value)}
              placeholder="e.g. Liam Taylor"
              className="w-full px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-950"
            />
          </div>
          <div>
            <label className="block text-[11px] text-stone-500 mb-1">Email</label>
            <input
              type="email"
              value={newMemberEmail}
              onChange={(e) => setNewMemberEmail(e.target.value)}
              placeholder="liam.t@company.io"
              className="w-full px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-950"
            />
          </div>
          <div>
            <label className="block text-[11px] text-stone-500 mb-1">Role</label>
            <select
              value={newMemberRole}
              onChange={(e) => setNewMemberRole(e.target.value)}
              className="w-full px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-950"
            >
              <option value="Frontend Engineer">Frontend Engineer</option>
              <option value="Backend Engineer">Backend Engineer</option>
              <option value="QA Engineer">QA Engineer</option>
              <option value="Product Designer">Product Designer</option>
              <option value="DevOps Specialist">DevOps Specialist</option>
            </select>
          </div>
          <button
            type="button"
            onClick={handleAddMember}
            className="flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-teal-800 dark:text-teal-200 bg-teal-50 dark:bg-teal-950/70 border border-teal-200 dark:border-teal-800 hover:bg-teal-100 rounded-lg"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Member</span>
          </button>
        </div>
      </div>

      {/* Section 3: Project Documents */}
      <div className="p-6 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-stone-100 dark:border-stone-800">
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wider text-teal-800 dark:text-teal-400">
              Document Artifacts ({currentProject.documents.length})
            </h2>
            <p className="text-[11px] text-stone-500 dark:text-stone-400 mt-0.5">
              Project specifications and assets stored securely in Supabase Storage.
            </p>
          </div>

          <div>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleUploadDocument}
              className="hidden"
            />
            <button
              type="button"
              disabled={isUploadingDoc}
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-teal-800 dark:text-teal-200 bg-teal-50 dark:bg-teal-950/70 border border-teal-200 dark:border-teal-800 hover:bg-teal-100 dark:hover:bg-teal-900 rounded-xl transition-colors disabled:opacity-50 shadow-2xs cursor-pointer"
            >
              {isUploadingDoc ? (
                <>
                  <Loader2 className="w-3.5 h-3.5 animate-spin text-teal-700 dark:text-teal-400" />
                  <span>Uploading to Storage...</span>
                </>
              ) : (
                <>
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload Document</span>
                </>
              )}
            </button>
          </div>
        </div>

        {currentProject.documents.length === 0 ? (
          <div className="p-6 text-center rounded-xl border border-dashed border-stone-200 dark:border-stone-800 bg-stone-50/40 dark:bg-stone-950/30">
            <FileText className="w-6 h-6 text-stone-400 mx-auto mb-1.5" />
            <p className="text-xs font-medium text-stone-700 dark:text-stone-300">No documents uploaded yet</p>
            <p className="text-[11px] text-stone-400 mt-0.5">
              Click &quot;Upload Document&quot; above to attach architecture specifications, PRDs, or design briefs (max 20 MB).
            </p>
          </div>
        ) : (
          <div className="space-y-2 text-xs">
            {currentProject.documents.map((doc) => (
              <div
                key={doc.id}
                className="flex items-center justify-between p-3 rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-950 hover:border-teal-300/50 dark:hover:border-teal-700/50 transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="p-2 rounded-lg bg-teal-100/60 dark:bg-teal-950/60 text-teal-700 dark:text-teal-400 shrink-0">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <p className="font-semibold text-stone-900 dark:text-stone-100 truncate">{doc.name}</p>
                    <p className="text-[11px] text-stone-400">
                      {doc.size} {doc.uploadedAt ? `· Uploaded ${doc.uploadedAt}` : ''}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1 sm:gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleDownloadDoc(doc)}
                    disabled={downloadingDocId === doc.id}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-stone-600 dark:text-stone-300 hover:text-teal-700 dark:hover:text-teal-400 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-lg transition-colors cursor-pointer"
                    title="Download or open using signed URL"
                  >
                    {downloadingDocId === doc.id ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-teal-600" />
                    ) : (
                      <Download className="w-3.5 h-3.5" />
                    )}
                    <span className="hidden sm:inline">Download</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setDocToDelete(doc);
                      setIsDeleteDocConfirmOpen(true);
                    }}
                    className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg transition-colors cursor-pointer"
                    title="Delete document"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Section 4: Danger Zone (Archive & Delete) */}
      <div className="p-6 rounded-2xl border border-rose-200 dark:border-rose-900/60 bg-rose-50/30 dark:bg-rose-950/20 shadow-xs space-y-4">
        <div>
          <h2 className="text-xs font-bold uppercase tracking-wider text-rose-700 dark:text-rose-400">
            Danger Zone
          </h2>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
            Archiving hides the workspace from active dashboards. Deletion permanently removes all associated sprints, tasks, and stories.
          </p>
        </div>

        <div className="pt-3 border-t border-rose-100 dark:border-rose-900/40 flex flex-wrap items-center justify-between gap-4">
          <button
            type="button"
            onClick={() => setIsArchiveConfirmOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-stone-700 dark:text-stone-300 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 hover:bg-stone-50 rounded-xl transition-colors shadow-2xs"
          >
            <Archive className="w-3.5 h-3.5" />
            <span>Archive Workspace</span>
          </button>

          <button
            type="button"
            onClick={() => setIsDeleteConfirmOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition-colors shadow-xs"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Delete Project Workspace</span>
          </button>
        </div>
      </div>

      {/* CONFIRM ARCHIVE */}
      <ConfirmDialog
        isOpen={isArchiveConfirmOpen}
        title="Archive Project"
        message={`Are you sure you want to archive "${currentProject.name}"? It will be hidden from the active projects directory.`}
        confirmLabel="Archive"
        isDestructive={false}
        onConfirm={handleArchive}
        onCancel={() => setIsArchiveConfirmOpen(false)}
      />

      {/* CONFIRM DELETE */}
      <ConfirmDialog
        isOpen={isDeleteConfirmOpen}
        title="Delete Project Workspace"
        message={`Are you sure you want to permanently delete "${currentProject.name}"? This action cannot be undone.`}
        confirmLabel="Permanently Delete"
        isDestructive={true}
        onConfirm={handleDelete}
        onCancel={() => setIsDeleteConfirmOpen(false)}
      />

      {/* CONFIRM DELETE DOCUMENT */}
      <ConfirmDialog
        isOpen={isDeleteDocConfirmOpen}
        title="Delete Project Document"
        message={`Are you sure you want to permanently delete "${docToDelete?.name}"? The file will be removed from storage.`}
        confirmLabel="Delete Document"
        isDestructive={true}
        onConfirm={handleConfirmDeleteDoc}
        onCancel={() => {
          setIsDeleteDocConfirmOpen(false);
          setDocToDelete(null);
        }}
      />

    </div>
  );
};
