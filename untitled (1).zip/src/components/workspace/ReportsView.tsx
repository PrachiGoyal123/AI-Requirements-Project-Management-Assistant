import React, { useState } from 'react';
import { useApp } from '../../store/AppContext';
import { ReportType, StatusReportData } from '../../types/report';
import { Modal } from '../common/Modal';
import { MarkdownRenderer } from '../common/MarkdownRenderer';
import { aiClient, AiClientError } from '../../services/ai/aiClient';
import { supabaseService } from '../../services/supabaseService';
import { 
  FileText, 
  Sparkles, 
  Download, 
  Copy, 
  Check, 
  TrendingUp, 
  ShieldAlert, 
  Kanban,
  Edit3,
  Calendar,
  Share2,
  RotateCw,
  AlertCircle
} from 'lucide-react';

import { mockProjectService } from '../../services/mockProjectService';

export const ReportsView: React.FC = () => {
  const {
    user,
    isGuest,
    currentProject,
    currentSprint,
    projectTasks,
    projectStories,
    projectRisks,
    projectDecisions,
    projectDependencies,
    addToast,
  } = useApp();

  const [selectedReportType, setSelectedReportType] = useState<ReportType>('Project Status Report');
  const [activeReportData, setActiveReportData] = useState<StatusReportData | null>(null);
  const [editableMarkdown, setEditableMarkdown] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [reportError, setReportError] = useState<string | null>(null);
  const [isCopied, setIsCopied] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);

  // Generate Report from Live State via Real Gemini Stream
  const handleGenerateReport = async (type: ReportType = selectedReportType) => {
    if (!currentProject) return;
    setSelectedReportType(type);
    setIsGenerating(true);
    setReportError(null);

    const initialReport = mockProjectService.compileStatusReport(
      currentProject,
      currentSprint,
      projectTasks,
      projectStories,
      projectRisks,
      projectDecisions,
      projectDependencies
    );

    setActiveReportData(initialReport);
    setEditableMarkdown('');

    const projectData = {
      project: currentProject,
      sprint: currentSprint,
      tasks: projectTasks,
      stories: projectStories,
      risks: projectRisks,
      decisions: projectDecisions,
      dependencies: projectDependencies,
    };

    let accumulatedText = '';

    try {
      if (type === 'Sprint Summary') {
        await aiClient.streamSprintSummary({
          projectData,
          onChunk: (chunk: string) => {
            accumulatedText += chunk;
            setEditableMarkdown((prev) => prev + chunk);
          },
        });
      } else {
        await aiClient.streamStatusReport({
          projectData,
          onChunk: (chunk: string) => {
            accumulatedText += chunk;
            setEditableMarkdown((prev) => prev + chunk);
          },
        });
      }

      addToast({ title: `${type} Compiled`, message: 'Report synthesized with Gemini AI.', type: 'success' });

      // Persist to Supabase if authenticated
      if (user && !isGuest && currentProject && accumulatedText.trim()) {
        supabaseService.saveReport(
          currentProject.id,
          type,
          `${type} - ${currentProject.name}`,
          accumulatedText
        ).catch((err) => {
          console.warn('Failed to persist report to Supabase:', err);
        });
      }
    } catch (err) {
      const msg = err instanceof AiClientError ? err.message : (err instanceof Error ? err.message : 'Failed to generate report');
      setReportError(msg);
      addToast({ title: 'Report Generation Failed', message: msg, type: 'error' });
    } finally {
      setIsGenerating(false);
    }
  };

  // Copy Report
  const handleCopy = () => {
    navigator.clipboard.writeText(editableMarkdown);
    setIsCopied(true);
    addToast({ title: 'Report Copied to Clipboard', type: 'info' });
    setTimeout(() => setIsCopied(false), 2000);
  };

  // Download Report (.md / .txt file download)
  const handleDownload = () => {
    /**
     * NOTE FOR FUTURE BACKEND / PDF INTEGRATION:
     * Replace client-side blob download with a server endpoint:
     * await fetch('/api/reports/pdf', { method: 'POST', body: JSON.stringify({ markdown }) })
     * or use pdfmake/jspdf for rich styled client PDF rendering.
     */
    const filename = `${currentProject?.name.replace(/\s+/g, '_')}_Status_Report_${new Date().toISOString().split('T')[0]}.md`;
    const blob = new Blob([editableMarkdown], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addToast({ title: 'Report Downloaded', message: `Saved as ${filename}`, type: 'success' });
  };

  const reportCards: { type: ReportType; title: string; description: string; icon: any }[] = [
    {
      type: 'Project Status Report',
      title: 'Executive Project Status Report',
      description: 'Comprehensive stakeholder digest containing completion velocity, active blockers, schedule risks, overdue decisions, and client attention items.',
      icon: FileText,
    },
    {
      type: 'Sprint Summary',
      title: 'Sprint Burn-Down & Velocity Digest',
      description: 'Granular assessment of completed story points, remaining tasks, and sprint goal achievement for current iteration.',
      icon: Kanban,
    },
    {
      type: 'Task Progress Report',
      title: 'Engineering Workstream Progress',
      description: 'Tabular audit of all engineering tasks grouped by assignee, due date, status column, and estimate adherence.',
      icon: TrendingUp,
    },
    {
      type: 'Risks & Dependencies Report',
      title: 'Risk Matrix & Dependency Chain Report',
      description: 'Formal risk exposure ledger detailing high-impact vulnerabilities, critical mitigation plans, and external blockers.',
      icon: ShieldAlert,
    },
  ];

  if (!currentProject) return null;

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200 dark:border-stone-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-stone-900 dark:text-stone-100 flex items-center gap-2">
            <span>Project Reports &amp; Exports</span>
          </h1>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
            Generate executive status summaries compiled from real sprint deliverables, impediments, and risk matrices.
          </p>
        </div>

        <button
          onClick={() => handleGenerateReport('Project Status Report')}
          disabled={isGenerating}
          className="flex items-center gap-1.5 py-2 px-3.5 rounded-xl text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 shadow-xs transition-colors shrink-0"
        >
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>{isGenerating ? 'Compiling Report...' : 'Generate Status Report'}</span>
        </button>
      </div>

      {/* 4 Report Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {reportCards.map((rc) => {
          const Icon = rc.icon;
          return (
            <div
              key={rc.type}
              className="p-5 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 hover:border-teal-600 dark:hover:border-teal-500 shadow-xs transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="p-2.5 rounded-xl bg-teal-50 dark:bg-teal-950/70 text-teal-700 dark:text-teal-400">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-teal-800 dark:text-teal-300">
                    Markdown / TXT
                  </span>
                </div>
                <h2 className="text-sm font-bold text-stone-900 dark:text-stone-100">
                  {rc.title}
                </h2>
                <p className="text-xs text-stone-500 dark:text-stone-400 mt-1 leading-relaxed">
                  {rc.description}
                </p>
              </div>

              <div className="pt-4 mt-4 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between">
                <span className="text-[11px] text-stone-400">Compiled from live data</span>
                <button
                  type="button"
                  onClick={() => handleGenerateReport(rc.type)}
                  className="px-3 py-1.5 text-xs font-semibold text-teal-800 dark:text-teal-300 bg-teal-50 dark:bg-teal-950 hover:bg-teal-100 rounded-lg transition-colors"
                >
                  Generate &rarr;
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* REPORT ERROR BANNER */}
      {reportError && (
        <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-800 dark:text-rose-200 flex items-center justify-between gap-3 animate-in fade-in">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{reportError}</span>
          </div>
          <button
            type="button"
            onClick={() => handleGenerateReport(selectedReportType)}
            disabled={isGenerating}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg bg-rose-100 dark:bg-rose-900/60 text-rose-800 dark:text-rose-200 hover:bg-rose-200 transition-colors shrink-0"
          >
            <RotateCw className="w-3 h-3" />
            <span>Retry</span>
          </button>
        </div>
      )}

      {/* ACTIVE REPORT PREVIEW & EDITOR PANEL */}
      {activeReportData && (
        <div className="p-6 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-100 dark:border-stone-800">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-stone-900 dark:text-stone-100">
                  {selectedReportType}: {currentProject.name}
                </h2>
                {isGenerating ? (
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-300 animate-pulse flex items-center gap-1">
                    <RotateCw className="w-2.5 h-2.5 animate-spin" />
                    Streaming...
                  </span>
                ) : (
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300">
                    Editable
                  </span>
                )}
              </div>
              <p className="text-xs text-stone-400 mt-0.5">
                Generated at {new Date(activeReportData.generatedAt).toLocaleTimeString()}
              </p>
            </div>

            {/* Actions: Toggle Edit, Copy, Download */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setIsEditMode(!isEditMode)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl border transition-colors ${
                  isEditMode
                    ? 'border-teal-600 bg-teal-50 dark:bg-teal-950 text-teal-800 dark:text-teal-200'
                    : 'border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-700 dark:text-stone-200 hover:bg-stone-50'
                }`}
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>{isEditMode ? 'View Formatted' : 'Edit Text'}</span>
              </button>

              <button
                type="button"
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-stone-700 dark:text-stone-200 hover:bg-stone-50 transition-colors shadow-2xs"
              >
                {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{isCopied ? 'Copied' : 'Copy'}</span>
              </button>

              <button
                type="button"
                onClick={handleDownload}
                className="flex items-center gap-1.5 px-4 py-1.5 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Report (.md)</span>
              </button>
            </div>
          </div>

          {/* Report Content View or Edit Textarea */}
          {isEditMode ? (
            <div>
              <label className="block text-xs font-semibold text-stone-500 mb-1">
                Raw Markdown Content (Edit freely before downloading)
              </label>
              <textarea
                rows={18}
                value={editableMarkdown}
                onChange={(e) => setEditableMarkdown(e.target.value)}
                className="w-full p-4 font-mono text-xs rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-950 text-stone-900 dark:text-stone-100 focus:outline-none focus:ring-2 focus:ring-teal-700 leading-relaxed"
              />
            </div>
          ) : (
            <div className="p-6 rounded-xl bg-stone-50/50 dark:bg-stone-950/40 border border-stone-200/80 dark:border-stone-800">
              <MarkdownRenderer content={editableMarkdown} />
            </div>
          )}

          <div className="pt-2 text-[11px] text-stone-400 italic">
            * Note: Markdown export is enabled. PDF and DOCX exports will plug into this service layer without UI modification.
          </div>
        </div>
      )}

    </div>
  );
};
