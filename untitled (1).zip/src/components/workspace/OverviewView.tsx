import React, { useState, useMemo } from 'react';
import { useApp } from '../../store/AppContext';
import { StatusPill, ProvenanceBadge } from '../common/Badge';
import { aiClient, AiClientError } from '../../services/ai/aiClient';
import { 
  Calendar, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  AlertCircle, 
  FileText, 
  Sparkles, 
  Check, 
  Layers, 
  ArrowRight,
  TrendingUp,
  LayoutGrid,
  List,
  ShieldCheck,
  Bot,
  RotateCw
} from 'lucide-react';
import { PriorityBadge } from '../common/Badge';

export const OverviewView: React.FC<{ onNavigateTab: (tab: string) => void }> = ({ onNavigateTab }) => {
  const {
    currentProject,
    currentSprint,
    projectStories,
    projectTasks,
    currentSprintTasks,
    projectRisks,
    projectDecisions,
    addToast,
  } = useApp();

  const [workItemsView, setWorkItemsView] = useState<'board' | 'list'>('board');
  const [includeInReport, setIncludeInReport] = useState(true);
  const [isGeneratingSummary, setIsGeneratingSummary] = useState(false);
  const [summaryError, setSummaryError] = useState<string | null>(null);
  const [hasAiSummary, setHasAiSummary] = useState(true);

  // Dynamic AI Summary Data
  const [summaryData, setSummaryData] = useState<{
    goingWell: string[];
    delayed: string[];
    needsAttention: string[];
    nextActions: string[];
  }>({
    goingWell: [
      'Core registration and email OTP dispatch REST endpoints reached 100% test completion (T-101, T-102, T-103).',
      'Figma design tokens were seamlessly integrated without styling regression.',
      'Sprint velocity is maintaining a healthy 13 story points completed in the first week.',
    ],
    delayed: [
      'T-109 (Biometric Bridge): Past due since 2026-10-24 due to device fleet delay.',
      'DEC-01 (Mandatory OTP sign-off): Overdue by 3 days; blocks registration rule freeze.',
    ],
    needsAttention: [
      'Third-party SMS gateway carrier latency may trigger customer verification timeouts during peak hours (RSK-01).',
      'Hardware emulator fallback should be deployed immediately for iOS biometric testing to unblock T-109.',
    ],
    nextActions: [
      'Send follow-up message to Sarah Jenkins regarding DEC-01 using one-click draft in Decisions & Approvals.',
      'Reassign David Kim to assist Marcus with JWT sliding token invalidation (T-105).',
    ],
  });

  // AI Unconfirmed Items State
  const [confirmedItems, setConfirmedItems] = useState<Record<string, boolean>>({
    'ai-item-1': false,
    'ai-item-2': false,
  });

  // Auto-calculated statistics
  const stats = useMemo(() => {
    const totalStories = projectStories.length;
    const totalTasks = projectTasks.length;
    const completedTasks = projectTasks.filter((t) => t.status === 'Done').length;
    const sprintTotalTasks = currentSprintTasks.length;
    const sprintDoneTasks = currentSprintTasks.filter((t) => t.status === 'Done').length;
    const sprintProgress = sprintTotalTasks > 0 ? Math.round((sprintDoneTasks / sprintTotalTasks) * 100) : 0;
    const openRisks = projectRisks.filter((r) => r.status === 'Open').length;
    const blockedTasks = projectTasks.filter((t) => t.isBlocked).length;
    const pendingDecisions = projectDecisions.filter(
      (d) => d.status === 'Pending' || d.status === 'Overdue'
    ).length;

    // Remaining days in sprint
    let remainingDays = 0;
    if (currentSprint) {
      const end = new Date(currentSprint.endDate).getTime();
      const diff = end - Date.now();
      remainingDays = Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
    }

    return {
      totalStories,
      totalTasks,
      completedTasks,
      sprintProgress,
      openRisks,
      blockedTasks,
      pendingDecisions,
      remainingDays,
    };
  }, [projectStories, projectTasks, currentSprintTasks, projectRisks, projectDecisions, currentSprint]);

  if (!currentProject) return null;

  const handleGenerateSummary = async () => {
    if (!currentProject) return;
    setIsGeneratingSummary(true);
    setSummaryError(null);
    try {
      const result = await aiClient.generateProjectSummary({
        project: currentProject,
        sprint: currentSprint,
        tasks: projectTasks,
        stories: projectStories,
        risks: projectRisks,
        decisions: projectDecisions,
      });
      setSummaryData({
        goingWell: result.keyAccomplishments?.length ? result.keyAccomplishments : [result.executiveSummary || 'Core sprint deliverables are progressing.'],
        delayed: result.criticalRisks?.length ? result.criticalRisks : ['No overdue tasks flagged.'],
        needsAttention: (result.unconfirmedItems || []).map((u) => `${u.title}: ${u.description}`),
        nextActions: result.recommendedActions || [],
      });
      setHasAiSummary(true);
      setConfirmedItems({ 'ai-item-1': false, 'ai-item-2': false });
      addToast({ title: 'AI Summary Generated', message: 'Calculated with Gemini from live sprint tasks & risks.', type: 'success' });
    } catch (err) {
      const msg = err instanceof AiClientError ? err.message : (err instanceof Error ? err.message : 'Failed to generate project summary');
      setSummaryError(msg);
      addToast({ title: 'Summary Generation Failed', message: msg, type: 'error' });
    } finally {
      setIsGeneratingSummary(false);
    }
  };

  const handleConfirmItem = (id: string) => {
    setConfirmedItems((prev) => ({ ...prev, [id]: true }));
    addToast({ title: 'Item Confirmed', message: 'Item verified and cleared from unconfirmed state.', type: 'info' });
  };

  return (
    <div className="space-y-6">
      
      {/* Overview Header */}
      <div className="p-6 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-900 dark:text-stone-100">
                {currentProject.name}
              </h1>
              <StatusPill status={currentProject.status} />
              <ProvenanceBadge type="Automatic" />
            </div>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-1.5 max-w-2xl leading-relaxed">
              {currentProject.description}
            </p>
          </div>

          <div className="flex items-center gap-3">
            {currentSprint ? (
              <div className="px-3.5 py-2 rounded-xl bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 text-xs">
                <div className="flex items-center gap-1.5 font-bold text-teal-900 dark:text-teal-200">
                  <Clock className="w-3.5 h-3.5 text-teal-700 dark:text-teal-400" />
                  <span>{currentSprint.name}</span>
                </div>
                <p className="text-[11px] text-teal-700 dark:text-teal-300 mt-0.5 tabular-nums">
                  {stats.remainingDays} days remaining ({currentSprint.endDate})
                </p>
              </div>
            ) : (
              <div className="px-3.5 py-2 rounded-xl bg-stone-100 dark:bg-stone-800 text-xs text-stone-500">
                No active sprint
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 7 Metric Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 sm:gap-4">
        
        {/* Sprint Progress */}
        <div className="p-4 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs">
          <div className="flex items-center justify-between text-stone-400 text-xs">
            <span>Sprint Progress</span>
            <TrendingUp className="w-3.5 h-3.5 text-teal-600" />
          </div>
          <p className="text-xl font-bold text-stone-900 dark:text-stone-100 mt-1 tabular-nums">
            {stats.sprintProgress}%
          </p>
          <div className="h-1 w-full bg-stone-100 dark:bg-stone-800 rounded-full mt-2 overflow-hidden">
            <div className="h-full bg-teal-700 rounded-full" style={{ width: `${stats.sprintProgress}%` }} />
          </div>
        </div>

        {/* Total User Stories */}
        <div
          onClick={() => onNavigateTab('backlog')}
          className="p-4 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs cursor-pointer hover:border-teal-600 transition-colors"
        >
          <div className="flex items-center justify-between text-stone-400 text-xs">
            <span>User Stories</span>
            <Layers className="w-3.5 h-3.5" />
          </div>
          <p className="text-xl font-bold text-stone-900 dark:text-stone-100 mt-1 tabular-nums">
            {stats.totalStories}
          </p>
          <span className="text-[10px] text-stone-400">Backlog scope</span>
        </div>

        {/* Total Tasks */}
        <div
          onClick={() => onNavigateTab('board')}
          className="p-4 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs cursor-pointer hover:border-teal-600 transition-colors"
        >
          <div className="flex items-center justify-between text-stone-400 text-xs">
            <span>Total Tasks</span>
            <Clock className="w-3.5 h-3.5" />
          </div>
          <p className="text-xl font-bold text-stone-900 dark:text-stone-100 mt-1 tabular-nums">
            {stats.totalTasks}
          </p>
          <span className="text-[10px] text-stone-400">All work items</span>
        </div>

        {/* Completed Tasks */}
        <div className="p-4 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs">
          <div className="flex items-center justify-between text-stone-400 text-xs">
            <span>Completed</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />
          </div>
          <p className="text-xl font-bold text-stone-900 dark:text-stone-100 mt-1 tabular-nums">
            {stats.completedTasks}
          </p>
          <span className="text-[10px] text-teal-700 dark:text-teal-400">Verified done</span>
        </div>

        {/* Open Risks */}
        <div
          onClick={() => onNavigateTab('risks')}
          className="p-4 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs cursor-pointer hover:border-amber-600 transition-colors"
        >
          <div className="flex items-center justify-between text-stone-400 text-xs">
            <span>Open Risks</span>
            <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
          </div>
          <p className="text-xl font-bold text-amber-600 dark:text-amber-400 mt-1 tabular-nums">
            {stats.openRisks}
          </p>
          <span className="text-[10px] text-stone-400">Ledger items</span>
        </div>

        {/* Blocked Tasks */}
        <div
          onClick={() => onNavigateTab('board')}
          className="p-4 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs cursor-pointer hover:border-rose-600 transition-colors"
        >
          <div className="flex items-center justify-between text-stone-400 text-xs">
            <span>Blocked Tasks</span>
            <AlertCircle className="w-3.5 h-3.5 text-rose-500" />
          </div>
          <p className="text-xl font-bold text-rose-600 dark:text-rose-400 mt-1 tabular-nums">
            {stats.blockedTasks}
          </p>
          <span className="text-[10px] text-rose-500/80">Active bottlenecks</span>
        </div>

        {/* Pending Decisions */}
        <div
          onClick={() => onNavigateTab('decisions')}
          className="p-4 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs cursor-pointer hover:border-teal-600 transition-colors"
        >
          <div className="flex items-center justify-between text-stone-400 text-xs">
            <span>Decisions</span>
            <FileText className="w-3.5 h-3.5 text-indigo-500" />
          </div>
          <p className="text-xl font-bold text-stone-900 dark:text-stone-100 mt-1 tabular-nums">
            {stats.pendingDecisions}
          </p>
          <span className="text-[10px] text-stone-400">Awaiting sign-off</span>
        </div>

      </div>

      {/* AI Project Summary Card (4 Sections) */}
      <div className="p-6 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-100 dark:border-stone-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-teal-50 dark:bg-teal-950/80 text-teal-700 dark:text-teal-400">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-stone-900 dark:text-stone-100">
                  AI Project Intelligence Summary
                </h2>
                <ProvenanceBadge type="AI-generated" />
              </div>
              <p className="text-xs text-stone-500 dark:text-stone-400">
                Synthesized dynamically from live sprint completion, blocked items, and open decision deadlines.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 text-xs text-stone-600 dark:text-stone-400 cursor-pointer">
              <input
                type="checkbox"
                checked={includeInReport}
                onChange={(e) => setIncludeInReport(e.target.checked)}
                className="rounded border-stone-300 text-teal-700 focus:ring-teal-700"
              />
              <span>Include in status report</span>
            </label>

            <button
              onClick={handleGenerateSummary}
              disabled={isGeneratingSummary}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs transition-colors disabled:opacity-60"
            >
              {isGeneratingSummary ? (
                <RotateCw className="w-3.5 h-3.5 animate-spin text-teal-200" />
              ) : (
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              )}
              <span>{isGeneratingSummary ? 'Analyzing State...' : 'Generate Summary'}</span>
            </button>
          </div>
        </div>

        {/* AI Summary Error Banner */}
        {summaryError && (
          <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-800 dark:text-rose-200 flex items-center justify-between gap-3 animate-in fade-in">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{summaryError}</span>
            </div>
            <button
              type="button"
              onClick={handleGenerateSummary}
              disabled={isGeneratingSummary}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg bg-rose-100 dark:bg-rose-900/60 text-rose-800 dark:text-rose-200 hover:bg-rose-200 transition-colors shrink-0"
            >
              <RotateCw className="w-3 h-3" />
              <span>Retry</span>
            </button>
          </div>
        )}

        {/* 4 Structured Summary Sections */}
        {hasAiSummary && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* 1. What is going well? */}
            <div className="p-4 rounded-xl bg-stone-50/70 dark:bg-stone-950/40 border border-stone-200/80 dark:border-stone-800">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xs font-bold text-teal-800 dark:text-teal-300 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />
                  <span>1. What is going well?</span>
                </h3>
                <ProvenanceBadge type="Automatic" />
              </div>
              <ul className="space-y-1.5 text-xs text-stone-600 dark:text-stone-300 leading-relaxed list-disc pl-4">
                {summaryData.goingWell.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
            </div>

            {/* 2. What is delayed? */}
            <div className="p-4 rounded-xl bg-stone-50/70 dark:bg-stone-950/40 border border-stone-200/80 dark:border-stone-800">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xs font-bold text-rose-800 dark:text-rose-300 flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 text-rose-500" />
                  <span>2. What is delayed?</span>
                </h3>
                <ProvenanceBadge type="Automatic" />
              </div>
              <ul className="space-y-1.5 text-xs text-stone-600 dark:text-stone-300 leading-relaxed list-disc pl-4">
                {summaryData.delayed.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
            </div>

            {/* 3. What needs attention? */}
            <div className="p-4 rounded-xl bg-stone-50/70 dark:bg-stone-950/40 border border-stone-200/80 dark:border-stone-800">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xs font-bold text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                  <span>3. What needs attention?</span>
                </h3>
                {!confirmedItems['ai-item-1'] ? (
                  <button
                    onClick={() => handleConfirmItem('ai-item-1')}
                    className="cursor-pointer"
                    title="Click to confirm AI suggestion"
                  >
                    <ProvenanceBadge type="AI-suggested, unconfirmed" />
                  </button>
                ) : (
                  <span className="text-[10px] text-teal-700 font-semibold flex items-center gap-1">
                    <Check className="w-3 h-3" /> Confirmed
                  </span>
                )}
              </div>
              <ul className="space-y-1.5 text-xs text-stone-600 dark:text-stone-300 leading-relaxed list-disc pl-4">
                {summaryData.needsAttention.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
            </div>

            {/* 4. What should the project manager do next? */}
            <div className="p-4 rounded-xl bg-stone-50/70 dark:bg-stone-950/40 border border-stone-200/80 dark:border-stone-800">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xs font-bold text-teal-800 dark:text-teal-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-teal-600" />
                  <span>4. What should PM do next?</span>
                </h3>
                {!confirmedItems['ai-item-2'] ? (
                  <button
                    onClick={() => handleConfirmItem('ai-item-2')}
                    className="cursor-pointer"
                    title="Click to confirm AI suggestion"
                  >
                    <ProvenanceBadge type="AI-suggested, unconfirmed" />
                  </button>
                ) : (
                  <span className="text-[10px] text-teal-700 font-semibold flex items-center gap-1">
                    <Check className="w-3 h-3" /> Confirmed
                  </span>
                )}
              </div>
              <ul className="space-y-1.5 text-xs text-stone-600 dark:text-stone-300 leading-relaxed list-disc pl-4">
                {summaryData.nextActions.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
            </div>

          </div>
        )}
      </div>

      {/* Current Sprint Work Items Mini-Board / Table Toggle */}
      <div className="p-6 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-stone-100 dark:border-stone-800">
          <div>
            <h2 className="text-sm font-bold text-stone-900 dark:text-stone-100">
              Active Sprint Work Items: {currentSprint?.name || 'Current Cycle'}
            </h2>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              {currentSprintTasks.length} tasks scheduled in this sprint cycle.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center p-0.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800">
              <button
                type="button"
                onClick={() => setWorkItemsView('board')}
                className={`px-2.5 py-1 text-xs rounded-md transition-colors ${
                  workItemsView === 'board'
                    ? 'bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 font-medium shadow-2xs'
                    : 'text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
                }`}
              >
                Mini-Board
              </button>
              <button
                type="button"
                onClick={() => setWorkItemsView('list')}
                className={`px-2.5 py-1 text-xs rounded-md transition-colors ${
                  workItemsView === 'list'
                    ? 'bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 font-medium shadow-2xs'
                    : 'text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
                }`}
              >
                List Table
              </button>
            </div>

            <button
              onClick={() => onNavigateTab('board')}
              className="text-xs font-semibold text-teal-700 dark:text-teal-400 hover:underline flex items-center gap-1 ml-2"
            >
              <span>Full Scrum Board</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Work items preview */}
        {workItemsView === 'board' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {(['To Do', 'In Progress', 'Review', 'Done'] as const).map((column) => {
              const colTasks = currentSprintTasks.filter((t) => t.status === column);
              return (
                <div key={column} className="p-3 rounded-xl bg-stone-50/70 dark:bg-stone-950/40 border border-stone-200/80 dark:border-stone-800">
                  <div className="flex items-center justify-between text-xs font-semibold text-stone-700 dark:text-stone-300 mb-2">
                    <span>{column}</span>
                    <span className="w-5 h-5 rounded-full bg-stone-200 dark:bg-stone-800 text-[10px] flex items-center justify-center font-bold">
                      {colTasks.length}
                    </span>
                  </div>
                  <div className="space-y-2">
                    {colTasks.map((t) => (
                      <div
                        key={t.id}
                        onClick={() => onNavigateTab('board')}
                        className="p-2.5 rounded-lg bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-2xs cursor-pointer hover:border-teal-600 transition-colors"
                      >
                        <div className="flex items-center justify-between text-[10px] text-stone-400 mb-1">
                          <span className="font-mono font-semibold">{t.id}</span>
                          <PriorityBadge priority={t.priority} size="sm" />
                        </div>
                        <p className="text-xs font-medium text-stone-900 dark:text-stone-100 line-clamp-1">
                          {t.title}
                        </p>
                        <div className="mt-2 flex items-center justify-between text-[10px] text-stone-500">
                          <span>{t.assigneeName}</span>
                          {t.isBlocked && <span className="text-rose-500 font-bold">Blocked</span>}
                        </div>
                      </div>
                    ))}
                    {colTasks.length === 0 && (
                      <p className="text-[11px] text-stone-400 italic text-center py-4">No tasks</p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-stone-200 dark:border-stone-800">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-100 dark:bg-stone-800/70 text-stone-600 dark:text-stone-300">
                <tr>
                  <th className="py-2.5 px-3 font-semibold">ID</th>
                  <th className="py-2.5 px-3 font-semibold">Title</th>
                  <th className="py-2.5 px-3 font-semibold">Priority</th>
                  <th className="py-2.5 px-3 font-semibold">Status</th>
                  <th className="py-2.5 px-3 font-semibold">Assignee</th>
                  <th className="py-2.5 px-3 font-semibold">Due Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                {currentSprintTasks.map((task) => (
                  <tr key={task.id} className="hover:bg-stone-50/50 dark:hover:bg-stone-800/40">
                    <td className="py-2.5 px-3 font-mono font-semibold text-stone-700 dark:text-stone-300">
                      {task.displayNumber || task.id}
                    </td>
                    <td className="py-2.5 px-3 font-medium text-stone-900 dark:text-stone-100">
                      {task.title}
                      {task.isBlocked && (
                        <span className="ml-2 text-[10px] text-rose-600 font-bold">🛑 Blocked</span>
                      )}
                    </td>
                    <td className="py-2.5 px-3">
                      <PriorityBadge priority={task.priority} size="sm" />
                    </td>
                    <td className="py-2.5 px-3">
                      <StatusPill status={task.status} size="sm" />
                    </td>
                    <td className="py-2.5 px-3 text-stone-600 dark:text-stone-300">
                      {task.assigneeName}
                    </td>
                    <td className="py-2.5 px-3 tabular-nums text-stone-500">
                      {task.dueDate}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Reports Shortcut Card */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-teal-900 via-stone-900 to-stone-950 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm">
        <div>
          <h2 className="text-sm font-bold flex items-center gap-2">
            <FileText className="w-4 h-4 text-teal-400" />
            <span>Generate Comprehensive Stakeholder Status Report</span>
          </h2>
          <p className="text-xs text-stone-300 mt-1 max-w-xl">
            Export executive markdown summary with velocity metrics, blockers, overdue decisions, and client attention items.
          </p>
        </div>
        <button
          onClick={() => onNavigateTab('reports')}
          className="px-4 py-2 text-xs font-semibold text-stone-900 bg-white hover:bg-stone-100 rounded-xl transition-colors shadow-xs whitespace-nowrap"
        >
          Open Reports &rarr;
        </button>
      </div>

    </div>
  );
};
