import React, { useState, useMemo } from 'react';
import { useApp } from '../../store/AppContext';
import { Sprint, SprintStatus } from '../../types/sprint';
import { PriorityBadge, StatusPill } from '../common/Badge';
import { Modal } from '../common/Modal';
import { EmptyState } from '../common/EmptyState';
import { aiClient, AiClientError } from '../../services/ai/aiClient';
import { 
  Plus, 
  Sparkles, 
  Calendar, 
  Clock, 
  ArrowRight, 
  CheckCircle2, 
  Check, 
  X, 
  Layers, 
  Play,
  RotateCcw,
  Kanban,
  RotateCw,
  AlertCircle
} from 'lucide-react';

export const SprintPlanningView: React.FC<{ onNavigateToBoard: () => void }> = ({ onNavigateToBoard }) => {
  const {
    currentProject,
    projectSprints,
    projectStories,
    createSprint,
    updateSprint,
    startSprint,
    completeSprint,
    addStoriesToSprint,
    removeStoryFromSprint,
    addToast,
  } = useApp();

  // Selected sprint for the 2-panel planning view
  const [selectedSprintId, setSelectedSprintId] = useState<string>(() => {
    const active = projectSprints.find((s) => s.status === 'Active');
    return active ? active.id : projectSprints[0]?.id || '';
  });

  // Modal to create new sprint
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [sprintName, setSprintName] = useState('');
  const [sprintGoal, setSprintGoal] = useState('');
  const [sprintStartDate, setSprintStartDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [sprintEndDate, setSprintEndDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 14);
    return d.toISOString().split('T')[0];
  });

  // Checkbox selection in "Available backlog stories" panel
  const [selectedBacklogStoryIds, setSelectedBacklogStoryIds] = useState<string[]>([]);

  // AI Suggestion State
  const [isSuggestingWithAi, setIsSuggestingWithAi] = useState(false);
  const [planError, setPlanError] = useState<string | null>(null);
  const [aiPlanSuggestion, setAiPlanSuggestion] = useState<{
    recommendedStoryIds: string[];
    reasoning: string;
  } | null>(null);

  const activeSprint = useMemo(() => {
    return projectSprints.find((s) => s.id === selectedSprintId) || projectSprints[0];
  }, [projectSprints, selectedSprintId]);

  // Backlog stories available (not in any sprint or in Backlog status)
  const availableBacklogStories = useMemo(() => {
    return projectStories.filter((s) => !s.sprintId || s.status === 'Backlog');
  }, [projectStories]);

  // Stories currently in this selected sprint
  const sprintStories = useMemo(() => {
    if (!activeSprint) return [];
    return projectStories.filter((s) => s.sprintId === activeSprint.id);
  }, [projectStories, activeSprint]);

  // Total points in this sprint
  const sprintTotalPoints = useMemo(() => {
    return sprintStories.reduce((acc, s) => acc + s.storyPoints, 0);
  }, [sprintStories]);

  // Handle Add Selected Stories
  const handleAddSelectedToSprint = () => {
    if (!activeSprint || selectedBacklogStoryIds.length === 0) return;
    addStoriesToSprint(activeSprint.id, selectedBacklogStoryIds);
    setSelectedBacklogStoryIds([]);
  };

  // Handle Create Sprint Form
  const handleCreateSprint = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sprintName.trim() || !sprintGoal.trim()) {
      addToast({ title: 'Missing Information', message: 'Name and goal are mandatory.', type: 'warning' });
      return;
    }

    const created = createSprint({
      name: sprintName.trim(),
      goal: sprintGoal.trim(),
      startDate: sprintStartDate,
      endDate: sprintEndDate,
      status: 'Planned',
      projectId: currentProject?.id || '',
      storyIds: [],
      totalPoints: 0,
      completedPoints: 0,
    });

    setSelectedSprintId(created.id);
    setIsCreateModalOpen(false);
    setSprintName('');
    setSprintGoal('');
  };

  // Handle Start Sprint
  const handleStartSprint = () => {
    if (!activeSprint) return;
    const started = startSprint(activeSprint.id);
    if (started) {
      addToast({
        title: 'Sprint Activated',
        message: 'Sprint is live. Opening Scrum Board...',
        type: 'success',
      });
      setTimeout(() => {
        onNavigateToBoard();
      }, 700);
    }
  };

  // Handle AI Sprint Plan suggestion
  const handleSuggestSprintPlan = async () => {
    if (!activeSprint) return;
    setIsSuggestingWithAi(true);
    setPlanError(null);
    try {
      const result = await aiClient.suggestSprintPlan(
        availableBacklogStories,
        activeSprint.goal,
        22 // velocity
      );
      setAiPlanSuggestion(result);
      setSelectedBacklogStoryIds(result.recommendedStoryIds);
      addToast({ title: 'Sprint Plan Suggested', message: 'Review AI-selected stories below.', type: 'info' });
    } catch (err) {
      const msg = err instanceof AiClientError ? err.message : (err instanceof Error ? err.message : 'Failed to suggest sprint plan');
      setPlanError(msg);
      addToast({ title: 'AI Planning Failed', message: msg, type: 'error' });
    } finally {
      setIsSuggestingWithAi(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Title & Create Sprint Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200 dark:border-stone-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-stone-900 dark:text-stone-100 flex items-center gap-2">
            <span>Sprint Planning</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300">
              {projectSprints.length} Sprints Tracked
            </span>
          </h1>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
            Commit backlog user stories to sprint iterations based on team velocity and delivery objectives.
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="flex items-center gap-1.5 py-2 px-3.5 rounded-xl text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Create Sprint</span>
        </button>
      </div>

      {/* Sprints Horizontal Selector Strip */}
      <div className="flex items-center gap-2.5 overflow-x-auto pb-2">
        {projectSprints.map((sprint) => {
          const isSelected = sprint.id === selectedSprintId;
          return (
            <button
              key={sprint.id}
              onClick={() => setSelectedSprintId(sprint.id)}
              className={`p-3 rounded-xl border text-left shrink-0 min-w-[200px] transition-all ${
                isSelected
                  ? 'border-teal-600 bg-white dark:bg-stone-900 shadow-sm ring-1 ring-teal-600/30'
                  : 'border-stone-200 dark:border-stone-800 bg-white/60 dark:bg-stone-900/60 hover:border-stone-300'
              }`}
            >
              <div className="flex items-center justify-between gap-2 mb-1">
                <span className="text-xs font-bold text-stone-900 dark:text-stone-100 truncate">
                  {sprint.name}
                </span>
                <StatusPill status={sprint.status} size="sm" />
              </div>
              <p className="text-[11px] text-stone-500 truncate">{sprint.goal}</p>
              <div className="flex items-center gap-1 text-[10px] text-stone-400 mt-2 tabular-nums">
                <Calendar className="w-3 h-3" />
                <span>{sprint.startDate} ~ {sprint.endDate}</span>
              </div>
            </button>
          );
        })}
      </div>

      {activeSprint ? (
        /* Sprint Detail Workspace: Two-Panel Story Allocator */
        <div className="space-y-4">
          
          {/* Active Sprint Banner */}
          <div className="p-4 sm:p-5 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2.5">
                <h2 className="text-base font-bold text-stone-900 dark:text-stone-100">
                  {activeSprint.name}
                </h2>
                <StatusPill status={activeSprint.status} />
                <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300">
                  {sprintTotalPoints} Total Points
                </span>
              </div>
              <p className="text-xs text-stone-600 dark:text-stone-400 mt-1 max-w-2xl leading-relaxed">
                <strong>Sprint Goal:</strong> {activeSprint.goal}
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2.5 shrink-0">
              <button
                type="button"
                onClick={handleSuggestSprintPlan}
                disabled={isSuggestingWithAi}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-teal-800 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/80 border border-teal-200 dark:border-teal-800 rounded-xl hover:bg-teal-100 transition-colors shadow-2xs disabled:opacity-60"
              >
                {isSuggestingWithAi ? (
                  <RotateCw className="w-3.5 h-3.5 animate-spin text-teal-600" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                )}
                <span>{isSuggestingWithAi ? 'Analyzing Backlog...' : 'Suggest plan with AI'}</span>
              </button>

              {activeSprint.status === 'Active' ? (
                <button
                  type="button"
                  onClick={onNavigateToBoard}
                  className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs transition-colors"
                >
                  <Kanban className="w-3.5 h-3.5" />
                  <span>Open Scrum Board</span>
                </button>
              ) : activeSprint.status === 'Planned' ? (
                <button
                  type="button"
                  onClick={handleStartSprint}
                  className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs transition-colors"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Start Sprint</span>
                </button>
              ) : (
                <span className="text-xs font-semibold text-stone-500 px-3 py-1.5 bg-stone-100 dark:bg-stone-800 rounded-lg">
                  Sprint Completed
                </span>
              )}
            </div>
          </div>

          {/* AI Plan Error Box */}
          {planError && (
            <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-800 dark:text-rose-200 flex items-center justify-between gap-3 animate-in fade-in">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{planError}</span>
              </div>
              <button
                type="button"
                onClick={handleSuggestSprintPlan}
                disabled={isSuggestingWithAi}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg bg-rose-100 dark:bg-rose-900/60 text-rose-800 dark:text-rose-200 hover:bg-rose-200 transition-colors shrink-0"
              >
                <RotateCw className="w-3 h-3" />
                <span>Retry</span>
              </button>
            </div>
          )}

          {/* AI Plan Reasoning Box (if triggered) */}
          {aiPlanSuggestion && (
            <div className="p-3.5 rounded-xl bg-teal-50/70 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 text-xs text-stone-700 dark:text-stone-300 flex items-start justify-between gap-3 animate-in fade-in">
              <div className="flex items-start gap-2">
                <Sparkles className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-teal-950 dark:text-teal-200">AI Plan Assessment:</strong>{' '}
                  {aiPlanSuggestion.reasoning}
                </div>
              </div>
              <button
                onClick={() => setAiPlanSuggestion(null)}
                className="text-stone-400 hover:text-stone-600 p-0.5"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* TWO PANELS: Available Backlog vs Sprint Backlog */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Panel 1: Available Backlog Stories */}
            <div className="p-5 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 flex flex-col h-[520px]">
              <div className="flex items-center justify-between pb-3 border-b border-stone-100 dark:border-stone-800">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-stone-900 dark:text-stone-100">
                    Available Backlog Stories ({availableBacklogStories.length})
                  </h3>
                  <p className="text-[11px] text-stone-400">Select user stories to include in this sprint</p>
                </div>

                <button
                  type="button"
                  onClick={handleAddSelectedToSprint}
                  disabled={selectedBacklogStoryIds.length === 0}
                  className="px-3 py-1.5 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 disabled:opacity-30 rounded-lg transition-colors flex items-center gap-1.5 shadow-2xs"
                >
                  <span>Add Selected ({selectedBacklogStoryIds.length})</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Story Checkbox List */}
              <div className="flex-1 overflow-y-auto pt-3 space-y-2 pr-1">
                {availableBacklogStories.length === 0 ? (
                  <p className="text-xs text-stone-400 italic text-center py-12">
                    All user stories are assigned to active sprints.
                  </p>
                ) : (
                  availableBacklogStories.map((story) => {
                    const isChecked = selectedBacklogStoryIds.includes(story.id);
                    return (
                      <div
                        key={story.id}
                        className={`p-3 rounded-xl border transition-colors flex items-start gap-3 cursor-pointer ${
                          isChecked
                            ? 'border-teal-400 bg-teal-50/40 dark:bg-teal-950/30'
                            : 'border-stone-200/80 dark:border-stone-800 hover:border-stone-300 bg-stone-50/30 dark:bg-stone-950/30'
                        }`}
                        onClick={() => {
                          setSelectedBacklogStoryIds((prev) =>
                            prev.includes(story.id)
                              ? prev.filter((id) => id !== story.id)
                              : [...prev, story.id]
                          );
                        }}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}} // handled by parent div onClick
                          className="mt-0.5 rounded border-stone-300 text-teal-700 focus:ring-teal-700"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between text-xs mb-1">
                            <span className="font-mono font-bold text-teal-800 dark:text-teal-400">
                              {story.displayNumber || story.id}
                            </span>
                            <div className="flex items-center gap-2">
                              <span className="font-mono font-semibold text-[11px] text-stone-600 dark:text-stone-300 bg-stone-100 dark:bg-stone-800 px-1.5 py-0.5 rounded">
                                {story.storyPoints} pts
                              </span>
                              <PriorityBadge priority={story.priority} size="sm" />
                            </div>
                          </div>
                          <p className="text-xs font-semibold text-stone-900 dark:text-stone-100 truncate">
                            {story.title}
                          </p>
                          <p className="text-[11px] text-stone-500 line-clamp-1 mt-0.5">
                            {story.description}
                          </p>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Panel 2: Sprint Backlog */}
            <div className="p-5 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 flex flex-col h-[520px]">
              <div className="flex items-center justify-between pb-3 border-b border-stone-100 dark:border-stone-800">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-teal-800 dark:text-teal-400">
                    Sprint Backlog ({sprintStories.length} Stories · {sprintTotalPoints} pts)
                  </h3>
                  <p className="text-[11px] text-stone-400">Committed deliverables for {activeSprint.name}</p>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto pt-3 space-y-2 pr-1">
                {sprintStories.length === 0 ? (
                  <div className="py-12 flex flex-col items-center justify-center text-center">
                    <Layers className="w-8 h-8 text-stone-300 mb-2" />
                    <p className="text-xs font-semibold text-stone-700 dark:text-stone-300">
                      Sprint Backlog is Empty
                    </p>
                    <p className="text-[11px] text-stone-400 max-w-xs mt-1">
                      Check stories from the left panel or click &quot;Suggest plan with AI&quot; to populate.
                    </p>
                  </div>
                ) : (
                  sprintStories.map((story) => (
                    <div
                      key={story.id}
                      className="p-3 rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-950 flex items-start justify-between gap-3"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="font-mono font-bold text-teal-800 dark:text-teal-400">
                            {story.displayNumber || story.id}
                          </span>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-semibold text-[11px] text-stone-600 dark:text-stone-300 bg-stone-100 dark:bg-stone-800 px-1.5 py-0.5 rounded">
                              {story.storyPoints} pts
                            </span>
                            <PriorityBadge priority={story.priority} size="sm" />
                          </div>
                        </div>
                        <p className="text-xs font-semibold text-stone-900 dark:text-stone-100 truncate">
                          {story.title}
                        </p>
                        <p className="text-[11px] text-stone-500 line-clamp-1 mt-0.5">
                          {story.description}
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() => removeStoryFromSprint(story.id)}
                        className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-lg transition-colors shrink-0"
                        title="Remove from sprint"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>

          </div>

        </div>
      ) : (
        <EmptyState
          icon={Calendar}
          title="No Sprints Planned Yet"
          description="Create your first sprint to start allocating backlog user stories."
          actionLabel="Create Sprint"
          onAction={() => setIsCreateModalOpen(true)}
        />
      )}

      {/* CREATE SPRINT MODAL */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Create New Sprint"
        description="Schedule a 1-to-3 week agile cycle with explicit goals and dates."
        maxWidth="md"
      >
        <form onSubmit={handleCreateSprint} className="space-y-4 text-xs">
          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Sprint Name *
            </label>
            <input
              type="text"
              value={sprintName}
              onChange={(e) => setSprintName(e.target.value)}
              placeholder="e.g. Sprint 4 - Payment Gateway & Settlement"
              className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 focus:outline-none focus:ring-2 focus:ring-teal-700"
            />
          </div>

          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Sprint Goal *
            </label>
            <textarea
              rows={2}
              value={sprintGoal}
              onChange={(e) => setSprintGoal(e.target.value)}
              placeholder="What core business milestone or user value will this sprint achieve?"
              className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 focus:outline-none focus:ring-2 focus:ring-teal-700 leading-relaxed"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
                Start Date *
              </label>
              <input
                type="date"
                value={sprintStartDate}
                onChange={(e) => setSprintStartDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
              />
            </div>
            <div>
              <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
                End Date *
              </label>
              <input
                type="date"
                value={sprintEndDate}
                onChange={(e) => setSprintEndDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-stone-100 dark:border-stone-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsCreateModalOpen(false)}
              className="px-4 py-2 text-stone-600 dark:text-stone-400 hover:bg-stone-100 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs"
            >
              Create Sprint
            </button>
          </div>
        </form>
      </Modal>

    </div>
  );
};
