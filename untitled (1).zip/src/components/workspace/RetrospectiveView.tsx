import React, { useState, useMemo } from 'react';
import { useApp } from '../../store/AppContext';
import { RetroItem, SprintRetrospective } from '../../types/sprint';
import { Modal } from '../common/Modal';
import { aiClient, AiClientError } from '../../services/ai/aiClient';
import { 
  Smile, 
  Frown, 
  Sparkles, 
  Plus, 
  Trash2, 
  Save, 
  ThumbsUp, 
  ArrowRight, 
  History, 
  Check, 
  Calendar,
  Layers,
  Kanban,
  RotateCw,
  AlertCircle
} from 'lucide-react';

export const RetrospectiveView: React.FC<{ onNavigateToSprintPlanning: () => void }> = ({
  onNavigateToSprintPlanning,
}) => {
  const {
    currentProject,
    currentSprint,
    projectSprints,
    projectRetrospectives,
    saveRetrospective,
    addToast,
  } = useApp();

  const [selectedSprintId, setSelectedSprintId] = useState<string>(() => {
    return currentSprint?.id || projectSprints[0]?.id || '';
  });

  // Current retro state for active view
  const existingRetro = useMemo(() => {
    return projectRetrospectives.find((r) => r.sprintId === selectedSprintId);
  }, [projectRetrospectives, selectedSprintId]);

  const [whatWentWell, setWhatWentWell] = useState<RetroItem[]>(() => {
    return existingRetro?.whatWentWell || [
      { id: 'ww-1', text: 'Daily standups were crisp and stayed strictly under 15 minutes', votes: 4 },
      { id: 'ww-2', text: 'Clean separation of mock service layer enabled zero-friction testing', votes: 5 },
    ];
  });

  const [whatDidntGoWell, setWhatDidntGoWell] = useState<RetroItem[]>(() => {
    return existingRetro?.whatDidntGoWell || [
      { id: 'wd-1', text: 'External device procurement delayed biometric testing on physical hardware', votes: 4 },
      { id: 'wd-2', text: 'Client decision on mandatory phone OTP remained unconfirmed for 3 days', votes: 3 },
    ];
  });

  const [whatToImprove, setWhatToImprove] = useState<RetroItem[]>(() => {
    return existingRetro?.whatToImprove || [
      { id: 'wi-1', text: 'Deploy local mock emulators on Day 1 of sprint for all external dependencies', votes: 6 },
      { id: 'wi-2', text: 'Enforce automatic follow-up reminders 48 hours prior to decision cutoff', votes: 4 },
    ];
  });

  // Input fields for adding items
  const [newWellText, setNewWellText] = useState('');
  const [newDidntText, setNewDidntText] = useState('');
  const [newImproveText, setNewImproveText] = useState('');

  // AI Improvement State
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);
  const [retroError, setRetroError] = useState<string | null>(null);
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);

  // Add Item to a column
  const handleAddItem = (type: 'well' | 'didnt' | 'improve', text: string) => {
    if (!text.trim()) return;
    const newItem: RetroItem = {
      id: `retro-${Date.now()}-${Math.random().toString(36).substring(2, 4)}`,
      text: text.trim(),
      votes: 1,
    };

    if (type === 'well') {
      setWhatWentWell((prev) => [...prev, newItem]);
      setNewWellText('');
    } else if (type === 'didnt') {
      setWhatDidntGoWell((prev) => [...prev, newItem]);
      setNewDidntText('');
    } else {
      setWhatToImprove((prev) => [...prev, newItem]);
      setNewImproveText('');
    }
  };

  const handleVote = (type: 'well' | 'didnt' | 'improve', id: string) => {
    const updater = (list: RetroItem[]) =>
      list.map((item) => (item.id === id ? { ...item, votes: item.votes + 1 } : item));

    if (type === 'well') setWhatWentWell(updater);
    else if (type === 'didnt') setWhatDidntGoWell(updater);
    else setWhatToImprove(updater);
  };

  const handleRemoveItem = (type: 'well' | 'didnt' | 'improve', id: string) => {
    if (type === 'well') setWhatWentWell((prev) => prev.filter((i) => i.id !== id));
    else if (type === 'didnt') setWhatDidntGoWell((prev) => prev.filter((i) => i.id !== id));
    else setWhatToImprove((prev) => prev.filter((i) => i.id !== id));
  };

  // Save Retrospective
  const handleSave = () => {
    if (!currentProject) return;
    saveRetrospective({
      sprintId: selectedSprintId,
      projectId: currentProject.id,
      whatWentWell,
      whatDidntGoWell,
      whatToImprove,
      actionItems: whatToImprove.map((i) => i.text),
    });
  };

  // Generate Improvement Suggestions with AI
  const handleGenerateAiSuggestions = async () => {
    setIsGeneratingAi(true);
    setRetroError(null);
    try {
      const suggestions = await aiClient.generateRetroImprovements(
        whatWentWell,
        whatDidntGoWell
      );
      setAiSuggestions(suggestions);
      addToast({ title: 'Suggestions Generated', message: 'Click any suggestion to add it to your board.', type: 'info' });
    } catch (err) {
      const msg = err instanceof AiClientError ? err.message : (err instanceof Error ? err.message : 'Failed to generate improvement suggestions');
      setRetroError(msg);
      addToast({ title: 'AI Generation Failed', message: msg, type: 'error' });
    } finally {
      setIsGeneratingAi(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Title & Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200 dark:border-stone-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-stone-900 dark:text-stone-100 flex items-center gap-2">
            <span>Sprint Retrospective</span>
          </h1>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
            Reflect on team dynamics, celebrate wins, surface impediments, and define continuous improvements.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Sprint Selector */}
          <select
            value={selectedSprintId}
            onChange={(e) => setSelectedSprintId(e.target.value)}
            className="py-1.5 px-3 text-xs rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 text-stone-800 dark:text-stone-200 font-medium"
          >
            {projectSprints.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.status})
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={handleGenerateAiSuggestions}
            disabled={isGeneratingAi}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-teal-800 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/70 border border-teal-200 dark:border-teal-800 rounded-xl hover:bg-teal-100 transition-colors shadow-2xs disabled:opacity-60"
          >
            {isGeneratingAi ? (
              <RotateCw className="w-3.5 h-3.5 animate-spin text-teal-600" />
            ) : (
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            )}
            <span>{isGeneratingAi ? 'Analyzing...' : 'Generate AI Improvements'}</span>
          </button>

          <button
            type="button"
            onClick={handleSave}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>Save Retrospective</span>
          </button>

          <button
            type="button"
            onClick={onNavigateToSprintPlanning}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-stone-700 dark:text-stone-200 bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 rounded-xl transition-colors"
          >
            <span>Create Next Sprint &rarr;</span>
          </button>
        </div>
      </div>

      {/* AI Error Bar (if error) */}
      {retroError && (
        <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-800 dark:text-rose-200 flex items-center justify-between gap-3 animate-in fade-in">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{retroError}</span>
          </div>
          <button
            type="button"
            onClick={handleGenerateAiSuggestions}
            disabled={isGeneratingAi}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg bg-rose-100 dark:bg-rose-900/60 text-rose-800 dark:text-rose-200 hover:bg-rose-200 transition-colors shrink-0"
          >
            <RotateCw className="w-3 h-3" />
            <span>Retry</span>
          </button>
        </div>
      )}

      {/* AI Suggestions Bar (if generated) */}
      {aiSuggestions.length > 0 && (
        <div className="p-4 rounded-2xl bg-teal-50/70 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 space-y-2 animate-in fade-in">
          <div className="flex items-center justify-between text-xs font-bold text-teal-950 dark:text-teal-200">
            <span className="flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>AI Recommended Action Items:</span>
            </span>
            <button
              onClick={() => setAiSuggestions([])}
              className="text-stone-400 hover:text-stone-600 text-[11px]"
            >
              Dismiss
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {aiSuggestions.map((sug, idx) => (
              <button
                key={idx}
                onClick={() => {
                  handleAddItem('improve', sug);
                  setAiSuggestions((prev) => prev.filter((_, i) => i !== idx));
                }}
                className="text-left text-xs bg-white dark:bg-stone-900 border border-teal-200 dark:border-teal-800 hover:border-teal-600 p-2 rounded-xl flex items-center gap-2 text-stone-700 dark:text-stone-300 shadow-2xs group transition-colors"
              >
                <Plus className="w-3.5 h-3.5 text-teal-600 shrink-0 group-hover:scale-110 transition-transform" />
                <span>{sug}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* 3 RETROSPECTIVE COLUMNS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Column 1: What went well? */}
        <div className="p-5 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 flex flex-col h-[560px]">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100 dark:border-stone-800">
            <h3 className="text-xs font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-2">
              <Smile className="w-4 h-4" />
              <span>What went well? ({whatWentWell.length})</span>
            </h3>
          </div>

          <div className="flex-1 overflow-y-auto pt-3 space-y-2 pr-1">
            {whatWentWell.map((item) => (
              <div
                key={item.id}
                className="p-3 rounded-xl border border-emerald-100 dark:border-emerald-950/60 bg-emerald-50/40 dark:bg-emerald-950/20 text-xs text-stone-800 dark:text-stone-200 space-y-2"
              >
                <p className="leading-relaxed">{item.text}</p>
                <div className="flex items-center justify-between pt-1 border-t border-emerald-100/60 dark:border-emerald-900/60 text-[11px] text-stone-400">
                  <button
                    onClick={() => handleVote('well', item.id)}
                    className="flex items-center gap-1 text-emerald-700 dark:text-emerald-400 hover:opacity-80"
                  >
                    <ThumbsUp className="w-3 h-3" />
                    <span>{item.votes}</span>
                  </button>
                  <button
                    onClick={() => handleRemoveItem('well', item.id)}
                    className="text-stone-400 hover:text-rose-500"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-stone-100 dark:border-stone-800 flex gap-2">
            <input
              type="text"
              value={newWellText}
              onChange={(e) => setNewWellText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleAddItem('well', newWellText);
              }}
              placeholder="Add positive observation..."
              className="flex-1 px-3 py-1.5 text-xs rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-950"
            />
            <button
              onClick={() => handleAddItem('well', newWellText)}
              className="p-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Column 2: What didn't go well? */}
        <div className="p-5 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 flex flex-col h-[560px]">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100 dark:border-stone-800">
            <h3 className="text-xs font-bold text-rose-700 dark:text-rose-400 flex items-center gap-2">
              <Frown className="w-4 h-4" />
              <span>What didn&apos;t go well? ({whatDidntGoWell.length})</span>
            </h3>
          </div>

          <div className="flex-1 overflow-y-auto pt-3 space-y-2 pr-1">
            {whatDidntGoWell.map((item) => (
              <div
                key={item.id}
                className="p-3 rounded-xl border border-rose-100 dark:border-rose-950/60 bg-rose-50/40 dark:bg-rose-950/20 text-xs text-stone-800 dark:text-stone-200 space-y-2"
              >
                <p className="leading-relaxed">{item.text}</p>
                <div className="flex items-center justify-between pt-1 border-t border-rose-100/60 dark:border-rose-900/60 text-[11px] text-stone-400">
                  <button
                    onClick={() => handleVote('didnt', item.id)}
                    className="flex items-center gap-1 text-rose-700 dark:text-rose-400 hover:opacity-80"
                  >
                    <ThumbsUp className="w-3 h-3" />
                    <span>{item.votes}</span>
                  </button>
                  <button
                    onClick={() => handleRemoveItem('didnt', item.id)}
                    className="text-stone-400 hover:text-rose-500"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-stone-100 dark:border-stone-800 flex gap-2">
            <input
              type="text"
              value={newDidntText}
              onChange={(e) => setNewDidntText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleAddItem('didnt', newDidntText);
              }}
              placeholder="Add obstacle or issue..."
              className="flex-1 px-3 py-1.5 text-xs rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-950"
            />
            <button
              onClick={() => handleAddItem('didnt', newDidntText)}
              className="p-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Column 3: What should we improve? */}
        <div className="p-5 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 flex flex-col h-[560px]">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100 dark:border-stone-800">
            <h3 className="text-xs font-bold text-teal-800 dark:text-teal-300 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>What should we improve? ({whatToImprove.length})</span>
            </h3>
          </div>

          <div className="flex-1 overflow-y-auto pt-3 space-y-2 pr-1">
            {whatToImprove.map((item) => (
              <div
                key={item.id}
                className="p-3 rounded-xl border border-teal-200/80 dark:border-teal-900 bg-teal-50/40 dark:bg-teal-950/20 text-xs text-stone-800 dark:text-stone-200 space-y-2"
              >
                <p className="leading-relaxed">{item.text}</p>
                <div className="flex items-center justify-between pt-1 border-t border-teal-100/60 dark:border-teal-900/60 text-[11px] text-stone-400">
                  <button
                    onClick={() => handleVote('improve', item.id)}
                    className="flex items-center gap-1 text-teal-700 dark:text-teal-400 hover:opacity-80"
                  >
                    <ThumbsUp className="w-3 h-3" />
                    <span>{item.votes}</span>
                  </button>
                  <button
                    onClick={() => handleRemoveItem('improve', item.id)}
                    className="text-stone-400 hover:text-rose-500"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-stone-100 dark:border-stone-800 flex gap-2">
            <input
              type="text"
              value={newImproveText}
              onChange={(e) => setNewImproveText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleAddItem('improve', newImproveText);
              }}
              placeholder="Add actionable suggestion..."
              className="flex-1 px-3 py-1.5 text-xs rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-950"
            />
            <button
              onClick={() => handleAddItem('improve', newImproveText)}
              className="p-2 bg-teal-700 hover:bg-teal-800 text-white rounded-xl"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>

      {/* SPRINT RETROSPECTIVE HISTORY VIEW */}
      {projectRetrospectives.length > 0 && (
        <div className="p-5 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-stone-500 flex items-center gap-2">
            <History className="w-4 h-4 text-stone-400" />
            <span>Retrospective Archives ({projectRetrospectives.length})</span>
          </h3>

          <div className="divide-y divide-stone-100 dark:divide-stone-800 text-xs">
            {projectRetrospectives.map((retro) => {
              const sprint = projectSprints.find((s) => s.id === retro.sprintId);
              return (
                <div key={retro.id} className="py-3 flex items-center justify-between gap-4">
                  <div>
                    <p className="font-semibold text-stone-900 dark:text-stone-100">
                      {sprint?.name || retro.sprintId}
                    </p>
                    <p className="text-[11px] text-stone-400">
                      {retro.whatWentWell.length} wins · {retro.whatDidntGoWell.length} impediments · {retro.whatToImprove.length} action items
                    </p>
                  </div>
                  <button
                    onClick={() => {
                      setSelectedSprintId(retro.sprintId);
                      setWhatWentWell(retro.whatWentWell);
                      setWhatDidntGoWell(retro.whatDidntGoWell);
                      setWhatToImprove(retro.whatToImprove);
                      addToast({ title: 'Archive Loaded', type: 'info' });
                    }}
                    className="text-xs text-teal-700 dark:text-teal-400 font-semibold hover:underline"
                  >
                    View Board &rarr;
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

    </div>
  );
};
