import React, { useState, useMemo } from 'react';
import { useApp } from '../../store/AppContext';
import { StatusPill, PriorityBadge } from '../common/Badge';
import { Modal } from '../common/Modal';
import { MarkdownRenderer } from '../common/MarkdownRenderer';
import { aiClient, AiClientError } from '../../services/ai/aiClient';
import { 
  CheckCircle2, 
  Clock, 
  ArrowRight, 
  Sparkles, 
  Layers, 
  Share2, 
  Calendar,
  AlertTriangle,
  RotateCcw,
  Check,
  RotateCw,
  AlertCircle
} from 'lucide-react';

export const SprintReviewView: React.FC = () => {
  const {
    currentProject,
    projectSprints,
    projectStories,
    projectTasks,
    updateTask,
    updateStory,
    addToast,
  } = useApp();

  const [selectedSprintId, setSelectedSprintId] = useState<string>(() => {
    const active = projectSprints.find((s) => s.status === 'Active');
    return active ? active.id : projectSprints[0]?.id || '';
  });

  // Modal to Carry Forward
  const [isCarryForwardModalOpen, setIsCarryForwardModalOpen] = useState(false);
  const [targetSprintId, setTargetSprintId] = useState<string>('');
  const [selectedIncompleteTaskIds, setSelectedIncompleteTaskIds] = useState<string[]>([]);

  // AI Summary State
  const [isGeneratingAiSummary, setIsGeneratingAiSummary] = useState(false);
  const [summaryError, setSummaryError] = useState<string | null>(null);
  const [aiSprintSummary, setAiSprintSummary] = useState<string | null>(null);

  const selectedSprint = useMemo(() => {
    return projectSprints.find((s) => s.id === selectedSprintId) || projectSprints[0];
  }, [projectSprints, selectedSprintId]);

  // Tasks and stories in this sprint
  const sprintTasks = useMemo(() => {
    if (!selectedSprint) return [];
    return projectTasks.filter((t) => t.sprintId === selectedSprint.id);
  }, [projectTasks, selectedSprint]);

  const sprintStories = useMemo(() => {
    if (!selectedSprint) return [];
    return projectStories.filter((s) => s.sprintId === selectedSprint.id);
  }, [projectStories, selectedSprint]);

  const completedTasks = useMemo(() => sprintTasks.filter((t) => t.status === 'Done'), [sprintTasks]);
  const incompleteTasks = useMemo(() => sprintTasks.filter((t) => t.status !== 'Done'), [sprintTasks]);

  const completedStories = useMemo(() => sprintStories.filter((s) => s.status === 'Completed'), [sprintStories]);
  const incompleteStories = useMemo(() => sprintStories.filter((s) => s.status !== 'Completed'), [sprintStories]);

  // Handle AI Sprint Summary Generation via Real Gemini Stream
  const handleGenerateSummary = async () => {
    if (!selectedSprint) return;
    setIsGeneratingAiSummary(true);
    setAiSprintSummary('');
    setSummaryError(null);

    const projectContext = {
      project: currentProject,
      sprint: selectedSprint,
      tasks: sprintTasks,
      stories: sprintStories,
      completedTasks,
      incompleteTasks,
    };

    try {
      await aiClient.streamSprintSummary({
        projectData: {
          project: currentProject,
          sprint: selectedSprint,
          tasks: sprintTasks,
          stories: sprintStories,
        },
        onChunk: (chunk: string) => {
          setAiSprintSummary((prev) => (prev || '') + chunk);
        },
      });
      addToast({ title: 'Sprint Summary Generated', type: 'success' });
    } catch (err) {
      const msg = err instanceof AiClientError ? err.message : (err instanceof Error ? err.message : 'Failed to generate sprint summary');
      setSummaryError(msg);
      addToast({ title: 'Summary Generation Failed', message: msg, type: 'error' });
    } finally {
      setIsGeneratingAiSummary(false);
    }
  };

  // Handle Carry Forward Execution
  const handleExecuteCarryForward = () => {
    if (selectedIncompleteTaskIds.length === 0) {
      addToast({ title: 'No Tasks Selected', message: 'Select tasks to carry forward.', type: 'warning' });
      return;
    }

    selectedIncompleteTaskIds.forEach((taskId) => {
      updateTask(taskId, {
        sprintId: targetSprintId || undefined,
        status: 'To Do',
      });
    });

    setIsCarryForwardModalOpen(false);
    addToast({
      title: 'Items Carried Forward',
      message: `${selectedIncompleteTaskIds.length} tasks transferred to ${targetSprintId ? 'target sprint' : 'product backlog'}.`,
      type: 'success',
    });
  };

  if (!selectedSprint) return null;

  return (
    <div className="space-y-6">
      
      {/* Title & Sprint Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200 dark:border-stone-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-stone-900 dark:text-stone-100 flex items-center gap-2">
            <span>Sprint Review &amp; Demo</span>
            <StatusPill status={selectedSprint.status} />
          </h1>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
            Demonstrate finished deliverables to stakeholders, evaluate incomplete work, and execute rollover workflows.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <label className="text-xs text-stone-500 font-semibold">Sprint:</label>
          <select
            value={selectedSprintId}
            onChange={(e) => setSelectedSprintId(e.target.value)}
            className="py-1.5 px-3 text-xs rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 text-stone-800 dark:text-stone-200 font-medium"
          >
            {projectSprints.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.status})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Sprint Overview Strip */}
      <div className="p-5 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-stone-400 mb-1">
            <Calendar className="w-3.5 h-3.5" />
            <span>{selectedSprint.startDate} to {selectedSprint.endDate}</span>
          </div>
          <h2 className="text-sm font-bold text-stone-900 dark:text-stone-100">
            Sprint Goal: {selectedSprint.goal}
          </h2>
          <p className="text-xs text-stone-500 mt-1">
            {completedTasks.length} of {sprintTasks.length} tasks completed · {incompleteTasks.length} pending items
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={handleGenerateSummary}
            disabled={isGeneratingAiSummary}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-teal-800 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/70 border border-teal-200 dark:border-teal-800 rounded-xl hover:bg-teal-100 transition-colors shadow-2xs disabled:opacity-60"
          >
            {isGeneratingAiSummary ? (
              <RotateCw className="w-3.5 h-3.5 animate-spin text-teal-600" />
            ) : (
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            )}
            <span>{isGeneratingAiSummary ? 'Streaming Summary...' : 'Generate Sprint Summary'}</span>
          </button>

          {incompleteTasks.length > 0 && (
            <button
              type="button"
              onClick={() => {
                setSelectedIncompleteTaskIds(incompleteTasks.map((t) => t.id));
                setIsCarryForwardModalOpen(true);
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Carry Forward ({incompleteTasks.length})</span>
            </button>
          )}
        </div>
      </div>

      {/* AI Summary Error Banner */}
      {summaryError && (
        <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-800 dark:text-rose-200 flex items-center justify-between gap-3 animate-in fade-in">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{summaryError}</span>
          </div>
          <button
            type="button"
            onClick={handleGenerateSummary}
            disabled={isGeneratingAiSummary}
            className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg bg-rose-100 dark:bg-rose-900/60 text-rose-800 dark:text-rose-200 hover:bg-rose-200 transition-colors shrink-0"
          >
            <RotateCw className="w-3 h-3" />
            <span>Retry</span>
          </button>
        </div>
      )}

      {/* AI Generated Review Summary Box */}
      {aiSprintSummary !== null && (
        <div className="p-5 rounded-2xl bg-teal-50/50 dark:bg-teal-950/30 border border-teal-200 dark:border-teal-800 space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-teal-100 dark:border-teal-900">
            <span className="text-xs font-bold text-teal-900 dark:text-teal-200 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>AI-Generated Sprint Summary</span>
              {isGeneratingAiSummary && (
                <span className="text-[10px] font-semibold text-teal-600 animate-pulse flex items-center gap-1 ml-2">
                  <RotateCw className="w-2.5 h-2.5 animate-spin" />
                  Streaming live...
                </span>
              )}
            </span>
            <button
              onClick={() => setAiSprintSummary(null)}
              className="text-stone-400 hover:text-stone-600 text-xs"
            >
              Dismiss
            </button>
          </div>
          <MarkdownRenderer content={aiSprintSummary} />
        </div>
      )}

      {/* Deliverables Breakdown: Completed vs Incomplete */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Completed Deliverables */}
        <div className="p-5 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 space-y-3">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100 dark:border-stone-800">
            <h3 className="text-xs font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>Completed Work Items ({completedTasks.length})</span>
            </h3>
            <span className="text-[11px] text-stone-400 font-semibold">Ready for Demo</span>
          </div>

          <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
            {completedTasks.length === 0 ? (
              <p className="text-xs text-stone-400 italic py-8 text-center">No completed tasks yet.</p>
            ) : (
              completedTasks.map((task) => (
                <div
                  key={task.id}
                  className="p-3 rounded-xl border border-stone-200/80 dark:border-stone-800 bg-stone-50/40 dark:bg-stone-950/40 text-xs flex items-center justify-between"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-teal-800 dark:text-teal-400">{task.displayNumber || task.id}</span>
                      <span className="font-semibold text-stone-900 dark:text-stone-100">{task.title}</span>
                    </div>
                    <p className="text-[11px] text-stone-400 mt-0.5">{task.assigneeName} · Done</p>
                  </div>
                  <PriorityBadge priority={task.priority} size="sm" />
                </div>
              ))
            )}
          </div>
        </div>

        {/* Incomplete Deliverables */}
        <div className="p-5 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 space-y-3">
          <div className="flex items-center justify-between pb-3 border-b border-stone-100 dark:border-stone-800">
            <h3 className="text-xs font-bold text-amber-700 dark:text-amber-400 flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>Incomplete / Pending Work ({incompleteTasks.length})</span>
            </h3>
            <span className="text-[11px] text-stone-400 font-semibold">Eligible for Rollover</span>
          </div>

          <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
            {incompleteTasks.length === 0 ? (
              <p className="text-xs text-emerald-600 font-medium py-8 text-center">
                100% of sprint items completed! Zero incomplete tasks.
              </p>
            ) : (
              incompleteTasks.map((task) => (
                <div
                  key={task.id}
                  className="p-3 rounded-xl border border-stone-200/80 dark:border-stone-800 bg-white dark:bg-stone-950 text-xs flex items-center justify-between"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-teal-800 dark:text-teal-400">{task.displayNumber || task.id}</span>
                      <span className="font-semibold text-stone-900 dark:text-stone-100 truncate">{task.title}</span>
                    </div>
                    <p className="text-[11px] text-stone-400 mt-0.5">
                      {task.assigneeName} · Status: {task.status}
                      {task.isBlocked && <span className="text-rose-500 font-bold ml-1.5">🛑 Blocked</span>}
                    </p>
                  </div>
                  <PriorityBadge priority={task.priority} size="sm" />
                </div>
              ))
            )}
          </div>
        </div>

      </div>

      {/* CARRY FORWARD MODAL */}
      <Modal
        isOpen={isCarryForwardModalOpen}
        onClose={() => setIsCarryForwardModalOpen(false)}
        title="Carry Forward Incomplete Tasks"
        description="Select which unfinished deliverables to roll over into the next sprint cycle or return to the product backlog."
        maxWidth="lg"
      >
        <div className="space-y-4 text-xs">
          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Destination Sprint
            </label>
            <select
              value={targetSprintId}
              onChange={(e) => setTargetSprintId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-950"
            >
              <option value="">Product Backlog (Unassigned)</option>
              {projectSprints
                .filter((s) => s.id !== selectedSprint.id && s.status !== 'Completed')
                .map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.status})
                  </option>
                ))}
            </select>
          </div>

          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Select Tasks to Transfer:
            </label>
            <div className="space-y-1.5 max-h-52 overflow-y-auto pr-1">
              {incompleteTasks.map((t) => {
                const isSelected = selectedIncompleteTaskIds.includes(t.id);
                return (
                  <label
                    key={t.id}
                    className={`flex items-center gap-2.5 p-2 rounded-lg border cursor-pointer ${
                      isSelected
                        ? 'border-teal-400 bg-teal-50 dark:bg-teal-950/40'
                        : 'border-stone-200 dark:border-stone-800'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={(e) => {
                        const checked = e.target.checked;
                        setSelectedIncompleteTaskIds((prev) =>
                          checked ? [...prev, t.id] : prev.filter((id) => id !== t.id)
                        );
                      }}
                      className="rounded border-stone-300 text-teal-700 focus:ring-teal-700"
                    />
                    <span className="font-mono font-semibold">{t.id}</span>
                    <span className="truncate flex-1">{t.title}</span>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="pt-4 border-t border-stone-100 dark:border-stone-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsCarryForwardModalOpen(false)}
              className="px-4 py-2 text-stone-600 dark:text-stone-400 hover:bg-stone-100 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleExecuteCarryForward}
              className="px-4 py-2 font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs"
            >
              Transfer Tasks
            </button>
          </div>
        </div>
      </Modal>

    </div>
  );
};
