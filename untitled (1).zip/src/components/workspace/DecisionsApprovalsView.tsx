import React, { useState } from 'react';
import { useApp } from '../../store/AppContext';
import { DecisionItem, DecisionStatus } from '../../types/decision';
import { StatusPill } from '../common/Badge';
import { Modal } from '../common/Modal';
import { ConfirmDialog } from '../common/ConfirmDialog';
import { EmptyState } from '../common/EmptyState';
import { aiClient, AiClientError } from '../../services/ai/aiClient';
import { 
  Plus, 
  FileCheck2, 
  Sparkles, 
  Mail, 
  Clock, 
  AlertCircle, 
  Copy, 
  Check, 
  Trash2, 
  Calendar,
  Send,
  RotateCw
} from 'lucide-react';

export const DecisionsApprovalsView: React.FC = () => {
  const {
    currentProject,
    projectDecisions,
    createDecision,
    updateDecision,
    deleteDecision,
    addToast,
  } = useApp();

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedForImpact, setSelectedForImpact] = useState<DecisionItem | null>(null);
  const [selectedForDraft, setSelectedForDraft] = useState<DecisionItem | null>(null);
  const [decisionToDelete, setDecisionToDelete] = useState<DecisionItem | null>(null);

  // Form State
  const [itemTitle, setItemTitle] = useState('');
  const [itemDesc, setItemDesc] = useState('');
  const [itemRequestedFrom, setItemRequestedFrom] = useState('');
  const [itemDueDate, setItemDueDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [itemUrgency, setItemUrgency] = useState<'Low' | 'Medium' | 'High'>('High');
  const [itemOwner, setItemOwner] = useState(currentProject?.teamMembers[0]?.name || 'Alex Morgan');

  // AI assessment & follow-up message state
  const [impactResult, setImpactResult] = useState<{ days: number; impactText: string } | null>(null);
  const [impactError, setImpactError] = useState<string | null>(null);
  const [isAssessingImpact, setIsAssessingImpact] = useState(false);
  const [draftMessage, setDraftMessage] = useState('');
  const [draftError, setDraftError] = useState<string | null>(null);
  const [isDrafting, setIsDrafting] = useState(false);
  const [hasCopiedDraft, setHasCopiedDraft] = useState(false);

  // Add Decision Submit
  const handleCreateDecision = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemTitle.trim() || !itemRequestedFrom.trim() || !currentProject) {
      addToast({ title: 'Missing Information', message: 'Item and Requested From are mandatory.', type: 'warning' });
      return;
    }

    createDecision({
      projectId: currentProject.id,
      item: itemTitle.trim(),
      description: itemDesc.trim(),
      owner: itemOwner,
      requestedFrom: itemRequestedFrom.trim(),
      dueDate: itemDueDate,
      status: 'Pending',
      urgency: itemUrgency,
    });

    setIsAddModalOpen(false);
    setItemTitle('');
    setItemDesc('');
    setItemRequestedFrom('');
  };

  // Open Assess Schedule Impact
  const handleOpenAssessImpact = async (item: DecisionItem) => {
    setSelectedForImpact(item);
    setIsAssessingImpact(true);
    setImpactResult(null);
    setImpactError(null);
    try {
      const result = await aiClient.assessDecisionImpact(item, currentProject?.name || 'Project');
      setImpactResult(result);
    } catch (err) {
      const msg = err instanceof AiClientError ? err.message : (err instanceof Error ? err.message : 'Failed to assess schedule impact');
      setImpactError(msg);
      addToast({ title: 'Impact Assessment Failed', message: msg, type: 'error' });
    } finally {
      setIsAssessingImpact(false);
    }
  };

  // Open Draft Follow-Up Message
  const handleOpenDraftMessage = async (item: DecisionItem) => {
    setSelectedForDraft(item);
    setIsDrafting(true);
    setDraftError(null);
    setHasCopiedDraft(false);
    try {
      const message = await aiClient.draftFollowUpMessage(
        item,
        currentProject?.name || 'Project'
      );
      setDraftMessage(message);
    } catch (err) {
      const msg = err instanceof AiClientError ? err.message : (err instanceof Error ? err.message : 'Failed to draft message');
      setDraftError(msg);
      addToast({ title: 'Drafting Failed', message: msg, type: 'error' });
    } finally {
      setIsDrafting(false);
    }
  };

  const handleCopyDraft = () => {
    navigator.clipboard.writeText(draftMessage);
    setHasCopiedDraft(true);
    addToast({ title: 'Draft Copied to Clipboard', type: 'info' });
    setTimeout(() => setHasCopiedDraft(false), 2000);
  };

  return (
    <div className="space-y-6">
      
      {/* Title & Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200 dark:border-stone-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-stone-900 dark:text-stone-100 flex items-center gap-2">
            <span>Decisions &amp; Approvals</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300">
              {projectDecisions.length} Items Tracked
            </span>
          </h1>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
            Track business approvals, stakeholder clarifications, and simulate downstream schedule drift.
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center gap-1.5 py-2 px-3.5 rounded-xl text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Add Decision Item</span>
        </button>
      </div>

      {/* Decisions List Table */}
      {projectDecisions.length === 0 ? (
        <EmptyState
          icon={FileCheck2}
          title="No Decisions or Approvals Pending"
          description="Log approval requests, stakeholder sign-offs, or external dependency requests."
          actionLabel="Add Decision Item"
          onAction={() => setIsAddModalOpen(true)}
        />
      ) : (
        <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 dark:bg-stone-800/80 text-stone-600 dark:text-stone-300 border-b border-stone-200 dark:border-stone-800">
                <tr>
                  <th className="py-3 px-4 font-semibold">ID</th>
                  <th className="py-3 px-4 font-semibold">Item &amp; Description</th>
                  <th className="py-3 px-4 font-semibold">Requested From</th>
                  <th className="py-3 px-4 font-semibold">Owner</th>
                  <th className="py-3 px-4 font-semibold">Due Date</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold text-right">AI Tools &amp; Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                {projectDecisions.map((dec) => {
                  const isPastDue =
                    dec.status !== 'Approved' && new Date(dec.dueDate).getTime() < Date.now();
                  const computedStatus = isPastDue && dec.status === 'Pending' ? 'Overdue' : dec.status;

                  return (
                    <tr
                      key={dec.id}
                      className={`hover:bg-stone-50/60 dark:hover:bg-stone-800/40 transition-colors ${
                        computedStatus === 'Overdue' ? 'bg-rose-50/40 dark:bg-rose-950/20' : ''
                      }`}
                    >
                      <td className="py-3 px-4 font-mono font-bold text-teal-800 dark:text-teal-400 whitespace-nowrap">
                        {dec.id}
                      </td>

                      <td className="py-3 px-4 max-w-sm">
                        <p className="font-semibold text-stone-900 dark:text-stone-100">
                          {dec.item}
                        </p>
                        <p className="text-[11px] text-stone-500 line-clamp-2 mt-0.5 leading-relaxed">
                          {dec.description}
                        </p>
                      </td>

                      <td className="py-3 px-4 text-stone-700 dark:text-stone-300 font-medium whitespace-nowrap">
                        {dec.requestedFrom}
                      </td>

                      <td className="py-3 px-4 text-stone-600 dark:text-stone-400 whitespace-nowrap">
                        {dec.owner}
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap tabular-nums">
                        <span
                          className={`flex items-center gap-1 font-semibold ${
                            computedStatus === 'Overdue'
                              ? 'text-rose-600 dark:text-rose-400'
                              : 'text-stone-600 dark:text-stone-300'
                          }`}
                        >
                          <Calendar className="w-3.5 h-3.5" />
                          <span>{dec.dueDate}</span>
                        </span>
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap">
                        <select
                          value={computedStatus}
                          onChange={(e) => updateDecision(dec.id, { status: e.target.value as DecisionStatus })}
                          className={`py-1 px-2.5 rounded-lg border text-xs font-semibold ${
                            computedStatus === 'Overdue'
                              ? 'border-rose-300 bg-rose-50 text-rose-800 dark:bg-rose-950 dark:text-rose-300'
                              : computedStatus === 'Approved'
                              ? 'border-teal-300 bg-teal-50 text-teal-800 dark:bg-teal-950 dark:text-teal-300'
                              : 'border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900'
                          }`}
                        >
                          <option value="Pending">Pending</option>
                          <option value="Approved">Approved</option>
                          <option value="Rejected">Rejected</option>
                          <option value="Overdue">Overdue</option>
                        </select>
                      </td>

                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* AI Button 1: Assess Schedule Impact */}
                          <button
                            type="button"
                            onClick={() => handleOpenAssessImpact(dec)}
                            className="px-2.5 py-1 text-[11px] font-semibold text-teal-800 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/70 border border-teal-200 dark:border-teal-800 rounded-lg hover:bg-teal-100 transition-colors flex items-center gap-1 shadow-2xs"
                            title="Simulate schedule drift impact"
                          >
                            <Sparkles className="w-3 h-3 text-amber-500" />
                            <span>Assess Impact</span>
                          </button>

                          {/* AI Button 2: Draft Follow-up Message */}
                          <button
                            type="button"
                            onClick={() => handleOpenDraftMessage(dec)}
                            className="px-2.5 py-1 text-[11px] font-semibold text-stone-700 dark:text-stone-200 bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-700 transition-colors flex items-center gap-1 shadow-2xs"
                            title="Generate reminder message"
                          >
                            <Mail className="w-3 h-3 text-teal-600" />
                            <span>Draft Message</span>
                          </button>

                          <button
                            onClick={() => setDecisionToDelete(dec)}
                            className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ASSESS SCHEDULE IMPACT MODAL */}
      <Modal
        isOpen={Boolean(selectedForImpact)}
        onClose={() => setSelectedForImpact(null)}
        title="Schedule Impact Assessment"
        description={selectedForImpact ? `Evaluating downstream friction for: "${selectedForImpact.item}"` : ''}
        maxWidth="md"
      >
        {isAssessingImpact ? (
          <div className="py-10 flex flex-col items-center text-center space-y-3">
            <div className="w-8 h-8 rounded-full border-2 border-teal-700 border-t-transparent animate-spin" />
            <p className="text-xs text-stone-500">Calculating critical path dependency delays...</p>
          </div>
        ) : impactError ? (
          <div className="py-8 flex flex-col items-center text-center space-y-3">
            <div className="w-10 h-10 rounded-full bg-rose-50 dark:bg-rose-950/60 flex items-center justify-center text-rose-600">
              <AlertCircle className="w-5 h-5" />
            </div>
            <p className="text-xs text-rose-700 dark:text-rose-300 max-w-sm">{impactError}</p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setSelectedForImpact(null)}
                className="px-3.5 py-1.5 text-xs text-stone-600 dark:text-stone-400 hover:bg-stone-100 rounded-lg"
              >
                Cancel
              </button>
              {selectedForImpact && (
                <button
                  type="button"
                  onClick={() => handleOpenAssessImpact(selectedForImpact)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl bg-teal-700 text-white hover:bg-teal-800 shadow-xs"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                  <span>Retry Assessment</span>
                </button>
              )}
            </div>
          </div>
        ) : impactResult ? (
          <div className="space-y-4 text-xs">
            <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 space-y-2">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-amber-600" />
                <span className="font-bold text-amber-900 dark:text-amber-200">
                  Estimated Schedule Drift: +{impactResult.days} Business Days
                </span>
              </div>
              <p className="text-stone-700 dark:text-stone-300 leading-relaxed">
                {impactResult.impactText}
              </p>
            </div>

            <div className="p-3 bg-stone-50 dark:bg-stone-950 rounded-xl border border-stone-200 dark:border-stone-800 space-y-1 text-stone-600 dark:text-stone-400">
              <p className="font-semibold text-stone-900 dark:text-stone-100">Recommended Action:</p>
              <p>Escalate to the steering committee or send an automated follow-up reminder draft immediately.</p>
            </div>

            <div className="pt-3 border-t border-stone-100 dark:border-stone-800 flex justify-end">
              <button
                onClick={() => setSelectedForImpact(null)}
                className="px-4 py-2 font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs"
              >
                Close Assessment
              </button>
            </div>
          </div>
        ) : null}
      </Modal>

      {/* DRAFT FOLLOW-UP MESSAGE MODAL */}
      <Modal
        isOpen={Boolean(selectedForDraft)}
        onClose={() => setSelectedForDraft(null)}
        title="Draft Follow-up Message"
        description="Editable professional reminder ready to copy and send to the stakeholder."
        maxWidth="lg"
      >
        {isDrafting ? (
          <div className="py-10 flex flex-col items-center text-center space-y-3">
            <div className="w-8 h-8 rounded-full border-2 border-teal-700 border-t-transparent animate-spin" />
            <p className="text-xs text-stone-500">Composing contextual follow-up message...</p>
          </div>
        ) : draftError ? (
          <div className="py-8 flex flex-col items-center text-center space-y-3">
            <div className="w-10 h-10 rounded-full bg-rose-50 dark:bg-rose-950/60 flex items-center justify-center text-rose-600">
              <AlertCircle className="w-5 h-5" />
            </div>
            <p className="text-xs text-rose-700 dark:text-rose-300 max-w-sm">{draftError}</p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setSelectedForDraft(null)}
                className="px-3.5 py-1.5 text-xs text-stone-600 dark:text-stone-400 hover:bg-stone-100 rounded-lg"
              >
                Cancel
              </button>
              {selectedForDraft && (
                <button
                  type="button"
                  onClick={() => handleOpenDraftMessage(selectedForDraft)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl bg-teal-700 text-white hover:bg-teal-800 shadow-xs"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                  <span>Retry Drafting</span>
                </button>
              )}
            </div>
          </div>
        ) : (
          <div className="space-y-4 text-xs">
            <div className="space-y-1">
              <label className="block text-stone-500 font-semibold">
                Message Body (Editable)
              </label>
              <textarea
                rows={9}
                value={draftMessage}
                onChange={(e) => setDraftMessage(e.target.value)}
                className="w-full p-3 font-mono text-[11px] rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-950 text-stone-900 dark:text-stone-100 focus:outline-none focus:ring-2 focus:ring-teal-700 leading-relaxed"
              />
            </div>

            <div className="pt-3 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between">
              <span className="text-[11px] text-stone-400">
                You can edit text freely before copying.
              </span>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedForDraft(null)}
                  className="px-3 py-1.5 text-stone-600 dark:text-stone-400 hover:bg-stone-100 rounded-lg"
                >
                  Close
                </button>
                <button
                  type="button"
                  onClick={handleCopyDraft}
                  className="px-4 py-2 font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs flex items-center gap-1.5"
                >
                  {hasCopiedDraft ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-300" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copy Message</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* ADD DECISION MODAL */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Add Decision &amp; Approval Item"
        description="Track external blockers and client clarification requests."
        maxWidth="md"
      >
        <form onSubmit={handleCreateDecision} className="space-y-4 text-xs">
          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Decision Item Summary *
            </label>
            <input
              type="text"
              value={itemTitle}
              onChange={(e) => setItemTitle(e.target.value)}
              placeholder="e.g. Client has not approved requirement for mandatory phone OTP"
              className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 focus:outline-none focus:ring-2 focus:ring-teal-700"
            />
          </div>

          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Requested From (Stakeholder / Partner) *
            </label>
            <input
              type="text"
              value={itemRequestedFrom}
              onChange={(e) => setItemRequestedFrom(e.target.value)}
              placeholder="e.g. Sarah Jenkins (Client CDO)"
              className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 focus:outline-none focus:ring-2 focus:ring-teal-700"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
                Target Due Date
              </label>
              <input
                type="date"
                value={itemDueDate}
                onChange={(e) => setItemDueDate(e.target.value)}
                className="w-full px-2.5 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
              />
            </div>
            <div>
              <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
                Urgency
              </label>
              <select
                value={itemUrgency}
                onChange={(e) => setItemUrgency(e.target.value as any)}
                className="w-full px-2.5 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
              >
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Owner
            </label>
            <select
              value={itemOwner}
              onChange={(e) => setItemOwner(e.target.value)}
              className="w-full px-2.5 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
            >
              {currentProject?.teamMembers.map((tm) => (
                <option key={tm.id} value={tm.name}>
                  {tm.name} ({tm.role})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Description &amp; Context
            </label>
            <textarea
              rows={3}
              value={itemDesc}
              onChange={(e) => setItemDesc(e.target.value)}
              placeholder="Why is this approval critical? What happens if unresolved?"
              className="w-full p-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 leading-relaxed"
            />
          </div>

          <div className="pt-4 border-t border-stone-100 dark:border-stone-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 text-stone-600 dark:text-stone-400 hover:bg-stone-100 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs"
            >
              Save Decision Item
            </button>
          </div>
        </form>
      </Modal>

      {/* CONFIRM DELETE DIALOG */}
      <ConfirmDialog
        isOpen={Boolean(decisionToDelete)}
        title="Delete Decision Item"
        message={`Are you sure you want to remove "${decisionToDelete?.item}" from the tracking ledger?`}
        onConfirm={() => {
          if (decisionToDelete) deleteDecision(decisionToDelete.id);
          setDecisionToDelete(null);
        }}
        onCancel={() => setDecisionToDelete(null)}
      />

    </div>
  );
};
