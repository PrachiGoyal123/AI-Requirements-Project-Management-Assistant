import React, { useState, useMemo } from 'react';
import { useApp } from '../../store/AppContext';
import { Task, TaskStatus, PriorityLevel } from '../../types/task';
import { PriorityBadge, StatusPill } from '../common/Badge';
import { Drawer } from '../common/Drawer';
import { Modal } from '../common/Modal';
import { EmptyState } from '../common/EmptyState';
import { 
  Plus, 
  Kanban, 
  Filter, 
  TrendingDown, 
  AlertCircle, 
  Calendar, 
  User as UserIcon, 
  Trash2, 
  Check, 
  X,
  Layers,
  ArrowRight
} from 'lucide-react';

const COLUMNS: TaskStatus[] = ['To Do', 'In Progress', 'Review', 'Done'];

export const ScrumBoardView: React.FC<{ onNavigateToSprintPlanning: () => void }> = ({
  onNavigateToSprintPlanning,
}) => {
  const {
    currentProject,
    currentSprint,
    currentSprintTasks,
    projectStories,
    createTask,
    updateTask,
    moveTask,
    deleteTask,
    addToast,
  } = useApp();

  const [assigneeFilter, setAssigneeFilter] = useState<string>('All');
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isAddTaskModalOpen, setIsAddTaskModalOpen] = useState(false);
  const [isBurndownModalOpen, setIsBurndownModalOpen] = useState(false);
  const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);

  // New Task Form State
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskDesc, setNewTaskDesc] = useState('');
  const [newTaskPriority, setNewTaskPriority] = useState<PriorityLevel>('High');
  const [newTaskAssignee, setNewTaskAssignee] = useState(
    currentProject?.teamMembers[0]?.name || 'Alex Morgan'
  );
  const [newTaskStoryId, setNewTaskStoryId] = useState(
    projectStories[0]?.id || ''
  );
  const [newTaskDueDate, setNewTaskDueDate] = useState(
    currentSprint?.endDate || new Date().toISOString().split('T')[0]
  );
  const [newTaskHours, setNewTaskHours] = useState(6);

  // Assignees list for filtering
  const allAssignees = useMemo(() => {
    return Array.from(new Set(currentSprintTasks.map((t) => t.assigneeName)));
  }, [currentSprintTasks]);

  // Filtered tasks
  const filteredTasks = useMemo(() => {
    if (assigneeFilter === 'All') return currentSprintTasks;
    return currentSprintTasks.filter((t) => t.assigneeName === assigneeFilter);
  }, [currentSprintTasks, assigneeFilter]);

  // Drag and Drop handlers (HTML5 native Drag & Drop for smooth reliability across all browsers)
  const handleDragStart = (e: React.DragEvent, taskId: string) => {
    e.dataTransfer.setData('text/plain', taskId);
    setDraggedTaskId(taskId);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, newStatus: TaskStatus) => {
    e.preventDefault();
    const taskId = e.dataTransfer.getData('text/plain') || draggedTaskId;
    if (taskId) {
      moveTask(taskId, newStatus);
      setDraggedTaskId(null);
      addToast({ title: 'Task Moved', message: `Card moved to ${newStatus}.`, type: 'info' });
    }
  };

  // Add Task submit
  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim() || !currentSprint || !currentProject) return;

    const member = currentProject.teamMembers.find((m) => m.name === newTaskAssignee);
    const initials = member?.avatarInitials || newTaskAssignee.slice(0, 2).toUpperCase();

    createTask({
      title: newTaskTitle.trim(),
      description: newTaskDesc.trim(),
      status: 'To Do',
      priority: newTaskPriority,
      assigneeName: newTaskAssignee,
      assigneeInitials: initials,
      dueDate: newTaskDueDate,
      storyId: newTaskStoryId || undefined,
      projectId: currentProject.id,
      sprintId: currentSprint.id,
      estimatedHours: newTaskHours,
      completedHours: 0,
      isBlocked: false,
    });

    setIsAddTaskModalOpen(false);
    setNewTaskTitle('');
    setNewTaskDesc('');
  };

  if (!currentSprint || currentSprint.status !== 'Active') {
    return (
      <EmptyState
        icon={Kanban}
        title="No Active Sprint in Progress"
        description="The Scrum Board requires an active sprint. Visit Sprint Planning to plan and activate an iteration."
        actionLabel="Go to Sprint Planning"
        onAction={onNavigateToSprintPlanning}
      />
    );
  }

  return (
    <div className="space-y-6">
      
      {/* Board Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200 dark:border-stone-800">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-xl font-bold tracking-tight text-stone-900 dark:text-stone-100">
              Scrum Board: {currentSprint.name}
            </h1>
            <StatusPill status="Active" size="sm" />
          </div>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-1 max-w-xl">
            Drag cards between columns or click any card to inspect blockers, adjust status, and edit task parameters.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Assignee Filter */}
          <div className="flex items-center gap-1.5 text-xs text-stone-500">
            <Filter className="w-3.5 h-3.5" />
            <select
              value={assigneeFilter}
              onChange={(e) => setAssigneeFilter(e.target.value)}
              className="py-1.5 px-3 text-xs rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 text-stone-700 dark:text-stone-300 focus:outline-none focus:ring-2 focus:ring-teal-700"
            >
              <option value="All">All Assignees</option>
              {allAssignees.map((name) => (
                <option key={name} value={name}>
                  {name}
                </option>
              ))}
            </select>
          </div>

          {/* Burndown Chart Button */}
          <button
            type="button"
            onClick={() => setIsBurndownModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-stone-700 dark:text-stone-200 bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 hover:bg-stone-50 dark:hover:bg-stone-800 rounded-xl transition-colors shadow-2xs"
          >
            <TrendingDown className="w-3.5 h-3.5 text-teal-600" />
            <span>Burndown Chart</span>
          </button>

          {/* + Add Task */}
          <button
            type="button"
            onClick={() => setIsAddTaskModalOpen(true)}
            className="flex items-center gap-1.5 py-1.5 px-3.5 rounded-xl text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 shadow-xs transition-colors shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Add Task</span>
          </button>
        </div>
      </div>

      {/* 4 Scrum Columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-start">
        {COLUMNS.map((col) => {
          const colTasks = filteredTasks.filter((t) => t.status === col);

          const colHeaderStyles = {
            'To Do': 'border-t-2 border-t-stone-400 bg-stone-100/60 dark:bg-stone-900/60',
            'In Progress': 'border-t-2 border-t-teal-600 bg-teal-50/40 dark:bg-teal-950/20',
            Review: 'border-t-2 border-t-indigo-500 bg-indigo-50/40 dark:bg-indigo-950/20',
            Done: 'border-t-2 border-t-emerald-600 bg-emerald-50/40 dark:bg-emerald-950/20',
          };

          return (
            <div
              key={col}
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, col)}
              className={`rounded-2xl p-3.5 border border-stone-200/90 dark:border-stone-800/90 min-h-[560px] flex flex-col transition-colors ${colHeaderStyles[col]}`}
            >
              {/* Column Header */}
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-stone-200/60 dark:border-stone-800/60">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-stone-900 dark:text-stone-100">
                    {col}
                  </span>
                  <span className="w-5 h-5 rounded-full bg-stone-200/80 dark:bg-stone-800 text-[10px] font-bold text-stone-700 dark:text-stone-300 flex items-center justify-center">
                    {colTasks.length}
                  </span>
                </div>
              </div>

              {/* Tasks List in Column */}
              <div className="flex-1 space-y-2.5 overflow-y-auto pr-0.5">
                {colTasks.map((task) => {
                  const relatedStory = projectStories.find((s) => s.id === task.storyId);
                  const isDelayed =
                    task.status !== 'Done' && new Date(task.dueDate).getTime() < Date.now();

                  return (
                    <div
                      key={task.id}
                      draggable
                      onDragStart={(e) => handleDragStart(e, task.id)}
                      onClick={() => setSelectedTask(task)}
                      className={`group p-3.5 rounded-xl bg-white dark:bg-stone-900 border transition-all cursor-grab active:cursor-grabbing hover:shadow-md ${
                        task.isBlocked
                          ? 'border-rose-400 dark:border-rose-700 ring-1 ring-rose-400/20'
                          : 'border-stone-200 dark:border-stone-800 hover:border-teal-600'
                      }`}
                    >
                      {/* Priority left color stripe or header */}
                      <div className="flex items-center justify-between text-[11px] mb-1.5">
                        <span className="font-mono font-bold text-teal-800 dark:text-teal-400">
                          {task.displayNumber || task.id}
                        </span>
                        <PriorityBadge priority={task.priority} size="sm" />
                      </div>

                      {/* Title */}
                      <h4 className="text-xs font-semibold text-stone-900 dark:text-stone-100 line-clamp-2 leading-relaxed">
                        {task.title}
                      </h4>

                      {/* Related Story Pill */}
                      {relatedStory && (
                        <div className="mt-2 text-[10px] text-stone-500 bg-stone-100 dark:bg-stone-800/80 px-2 py-0.5 rounded truncate max-w-full">
                          Story: {relatedStory.displayNumber || relatedStory.id} · {relatedStory.title}
                        </div>
                      )}

                      {/* Blocked Alert Banner if Flagged */}
                      {task.isBlocked && (
                        <div className="mt-2 p-1.5 rounded-md bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800 text-[10px] text-rose-800 dark:text-rose-300 flex items-start gap-1">
                          <AlertCircle className="w-3 h-3 text-rose-600 shrink-0 mt-0.5" />
                          <span className="line-clamp-2 leading-tight">
                            {task.blockedReason || 'Blocked'}
                          </span>
                        </div>
                      )}

                      {/* Footer: Due Date & Assignee Initials */}
                      <div className="mt-3 pt-2.5 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between text-[11px]">
                        <div className="flex items-center gap-1 tabular-nums text-stone-400">
                          <Calendar className="w-3 h-3" />
                          <span className={isDelayed ? 'text-rose-600 font-semibold' : ''}>
                            {task.dueDate}
                          </span>
                        </div>

                        <div
                          title={task.assigneeName}
                          className="w-6 h-6 rounded-full bg-teal-700 text-white font-bold text-[10px] flex items-center justify-center ring-1 ring-white dark:ring-stone-800"
                        >
                          {task.assigneeInitials}
                        </div>
                      </div>
                    </div>
                  );
                })}

                {colTasks.length === 0 && (
                  <div className="h-32 flex items-center justify-center text-center border-2 border-dashed border-stone-200/50 dark:border-stone-800 rounded-xl text-stone-400 text-[11px] italic">
                    Drop tasks here
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* TASK DETAILS SIDE DRAWER */}
      <Drawer
        isOpen={Boolean(selectedTask)}
        onClose={() => setSelectedTask(null)}
        title={selectedTask ? `${selectedTask.displayNumber || selectedTask.id}: ${selectedTask.title}` : 'Task Details'}
        subtitle="Manage task parameters, status, and blockage flags"
        width="lg"
      >
        {selectedTask && (
          <div className="space-y-5 text-xs">
            
            {/* Status Dropdown inside Drawer */}
            <div>
              <label className="block text-stone-500 font-semibold mb-1">Status Column</label>
              <select
                value={selectedTask.status}
                onChange={(e) => {
                  const status = e.target.value as TaskStatus;
                  setSelectedTask({ ...selectedTask, status });
                  updateTask(selectedTask.id, { status });
                }}
                className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 font-medium"
              >
                <option value="To Do">To Do</option>
                <option value="In Progress">In Progress</option>
                <option value="Review">Review</option>
                <option value="Done">Done</option>
              </select>
            </div>

            {/* Priority & Assignee Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-stone-500 font-semibold mb-1">Priority</label>
                <select
                  value={selectedTask.priority}
                  onChange={(e) => {
                    const priority = e.target.value as PriorityLevel;
                    setSelectedTask({ ...selectedTask, priority });
                    updateTask(selectedTask.id, { priority });
                  }}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900"
                >
                  <option value="Critical">Critical</option>
                  <option value="High">High</option>
                  <option value="Medium">Medium</option>
                  <option value="Low">Low</option>
                </select>
              </div>

              <div>
                <label className="block text-stone-500 font-semibold mb-1">Assignee</label>
                <select
                  value={selectedTask.assigneeName}
                  onChange={(e) => {
                    const assigneeName = e.target.value;
                    const member = currentProject?.teamMembers.find((m) => m.name === assigneeName);
                    const assigneeInitials = member?.avatarInitials || assigneeName.slice(0, 2).toUpperCase();
                    setSelectedTask({ ...selectedTask, assigneeName, assigneeInitials });
                    updateTask(selectedTask.id, { assigneeName, assigneeInitials });
                  }}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900"
                >
                  {currentProject?.teamMembers.map((tm) => (
                    <option key={tm.id} value={tm.name}>
                      {tm.name} ({tm.role})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-stone-500 font-semibold mb-1">Due Date</label>
                <input
                  type="date"
                  value={selectedTask.dueDate}
                  onChange={(e) => {
                    setSelectedTask({ ...selectedTask, dueDate: e.target.value });
                    updateTask(selectedTask.id, { dueDate: e.target.value });
                  }}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900"
                />
              </div>

              <div>
                <label className="block text-stone-500 font-semibold mb-1">Estimated Hours</label>
                <input
                  type="number"
                  min="1"
                  max="80"
                  value={selectedTask.estimatedHours || 6}
                  onChange={(e) => {
                    const estimatedHours = parseInt(e.target.value, 10) || 1;
                    setSelectedTask({ ...selectedTask, estimatedHours });
                    updateTask(selectedTask.id, { estimatedHours });
                  }}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 tabular-nums font-mono"
                />
              </div>
            </div>

            {/* Blocked Flag with Reason */}
            <div className="p-3.5 rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-950/40 space-y-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(selectedTask.isBlocked)}
                  onChange={(e) => {
                    const isBlocked = e.target.checked;
                    setSelectedTask({ ...selectedTask, isBlocked });
                    updateTask(selectedTask.id, { isBlocked });
                  }}
                  className="rounded border-stone-300 text-rose-600 focus:ring-rose-600"
                />
                <span className="font-semibold text-rose-700 dark:text-rose-400">
                  Flag task as Blocked
                </span>
              </label>

              {selectedTask.isBlocked && (
                <div>
                  <label className="block text-[11px] text-stone-500 mb-1">
                    Blocker Explanation / Impediment
                  </label>
                  <textarea
                    rows={2}
                    value={selectedTask.blockedReason || ''}
                    onChange={(e) => setSelectedTask({ ...selectedTask, blockedReason: e.target.value })}
                    onBlur={() => updateTask(selectedTask.id, { blockedReason: selectedTask.blockedReason })}
                    placeholder="Specify the reason (e.g. pending third-party API keys, device procurement delay)..."
                    className="w-full p-2 text-xs rounded-lg border border-rose-300 dark:border-rose-800 bg-white dark:bg-stone-900 focus:outline-none focus:ring-1 focus:ring-rose-500"
                  />
                </div>
              )}
            </div>

            {/* Description */}
            <div>
              <label className="block text-stone-500 font-semibold mb-1">Task Description</label>
              <textarea
                rows={4}
                value={selectedTask.description}
                onChange={(e) => setSelectedTask({ ...selectedTask, description: e.target.value })}
                onBlur={() => updateTask(selectedTask.id, { description: selectedTask.description })}
                className="w-full p-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 leading-relaxed"
              />
            </div>

            {/* Delete button in drawer */}
            <div className="pt-4 border-t border-stone-100 dark:border-stone-800 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  deleteTask(selectedTask.id);
                  setSelectedTask(null);
                }}
                className="px-3 py-1.5 text-xs text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg flex items-center gap-1.5 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Task</span>
              </button>
            </div>

          </div>
        )}
      </Drawer>

      {/* ADD TASK MODAL */}
      <Modal
        isOpen={isAddTaskModalOpen}
        onClose={() => setIsAddTaskModalOpen(false)}
        title="Add Sprint Task"
        description="Create an engineering work item for the active sprint."
        maxWidth="md"
      >
        <form onSubmit={handleCreateTask} className="space-y-4 text-xs">
          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Task Title *
            </label>
            <input
              type="text"
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              placeholder="e.g. Implement refresh token rotation service"
              className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 focus:outline-none focus:ring-2 focus:ring-teal-700"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
                Priority
              </label>
              <select
                value={newTaskPriority}
                onChange={(e) => setNewTaskPriority(e.target.value as PriorityLevel)}
                className="w-full px-2.5 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
              >
                <option value="Critical">Critical</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>

            <div>
              <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
                Assignee
              </label>
              <select
                value={newTaskAssignee}
                onChange={(e) => setNewTaskAssignee(e.target.value)}
                className="w-full px-2.5 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
              >
                {currentProject?.teamMembers.map((tm) => (
                  <option key={tm.id} value={tm.name}>
                    {tm.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
                Related Story
              </label>
              <select
                value={newTaskStoryId}
                onChange={(e) => setNewTaskStoryId(e.target.value)}
                className="w-full px-2.5 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
              >
                <option value="">None (Independent task)</option>
                {projectStories.map((st) => (
                  <option key={st.id} value={st.id}>
                    {st.id}: {st.title}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
                Due Date
              </label>
              <input
                type="date"
                value={newTaskDueDate}
                onChange={(e) => setNewTaskDueDate(e.target.value)}
                className="w-full px-2.5 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
              />
            </div>
          </div>

          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Description
            </label>
            <textarea
              rows={3}
              value={newTaskDesc}
              onChange={(e) => setNewTaskDesc(e.target.value)}
              placeholder="Provide implementation guidelines or acceptance details..."
              className="w-full p-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 leading-relaxed"
            />
          </div>

          <div className="pt-4 border-t border-stone-100 dark:border-stone-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsAddTaskModalOpen(false)}
              className="px-4 py-2 text-stone-600 dark:text-stone-400 hover:bg-stone-100 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs"
            >
              Create Task
            </button>
          </div>
        </form>
      </Modal>

      {/* BURNDOWN CHART MODAL */}
      <Modal
        isOpen={isBurndownModalOpen}
        onClose={() => setIsBurndownModalOpen(false)}
        title="Sprint Burndown Telemetry"
        description={`Remaining hours over sprint timeline (${currentSprint.startDate} to ${currentSprint.endDate})`}
        maxWidth="lg"
      >
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800">
            {/* SVG Burndown Chart Visual */}
            <div className="h-48 w-full flex items-end">
              <svg viewBox="0 0 400 160" className="w-full h-full text-stone-400 overflow-visible">
                {/* Horizontal gridlines */}
                <line x1="0" y1="20" x2="400" y2="20" stroke="currentColor" strokeDasharray="3 3" opacity="0.2" />
                <line x1="0" y1="60" x2="400" y2="60" stroke="currentColor" strokeDasharray="3 3" opacity="0.2" />
                <line x1="0" y1="100" x2="400" y2="100" stroke="currentColor" strokeDasharray="3 3" opacity="0.2" />
                <line x1="0" y1="140" x2="400" y2="140" stroke="currentColor" opacity="0.4" />

                {/* Ideal burn line (diagonal) */}
                <line x1="20" y1="25" x2="380" y2="140" stroke="#94a3b8" strokeWidth="2" strokeDasharray="4 4" />

                {/* Actual burn curve (Teal) */}
                <polyline
                  points="20,25 90,35 160,50 230,85 300,95 380,110"
                  fill="none"
                  stroke="#0f766e"
                  strokeWidth="3"
                  strokeLinecap="round"
                />

                {/* Data points */}
                <circle cx="20" cy="25" r="4" fill="#0f766e" />
                <circle cx="90" cy="35" r="4" fill="#0f766e" />
                <circle cx="160" cy="50" r="4" fill="#0f766e" />
                <circle cx="230" cy="85" r="4" fill="#0f766e" />
                <circle cx="300" cy="95" r="4" fill="#0f766e" />
                <circle cx="380" cy="110" r="4" fill="#0f766e" />
              </svg>
            </div>

            <div className="flex items-center justify-between text-[11px] text-stone-400 mt-2 px-1">
              <span>Day 1 (Kickoff)</span>
              <span>Day 5 (Mid-sprint)</span>
              <span>Day 10 (Review)</span>
              <span>Day 14 (Closure)</span>
            </div>
          </div>

          <div className="flex items-center justify-center gap-6 text-xs text-stone-600 dark:text-stone-300">
            <div className="flex items-center gap-2">
              <span className="w-3 h-0.5 bg-stone-400 border-b border-dashed" />
              <span>Ideal Burn Rate</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-1 bg-teal-700 rounded-full" />
              <span className="font-semibold text-teal-800 dark:text-teal-300">Actual Remaining Hours</span>
            </div>
          </div>

          <div className="p-3 bg-stone-100 dark:bg-stone-800/60 rounded-xl text-xs text-stone-600 dark:text-stone-400 leading-relaxed">
            <strong>Trajectory Assessment:</strong> Sprint completion is closely tracking the ideal burndown. 
            Resolution of task T-109 will accelerate the slope towards zero remaining hours before the Friday cutoff.
          </div>
        </div>
      </Modal>

    </div>
  );
};
