import React, { useState, useMemo } from 'react';
import { useApp } from '../../store/AppContext';
import { UserStory, StoryStatus } from '../../types/backlog';
import { PriorityLevel, Task } from '../../types/task';
import { PriorityBadge, StatusPill } from '../common/Badge';
import { Modal } from '../common/Modal';
import { Drawer } from '../common/Drawer';
import { ConfirmDialog } from '../common/ConfirmDialog';
import { EmptyState } from '../common/EmptyState';
import { aiClient, AiClientError, SuggestedTaskItem } from '../../services/ai/aiClient';
import { 
  Plus, 
  Search, 
  Filter, 
  Layers, 
  Sparkles, 
  Trash2, 
  Edit3, 
  CheckSquare, 
  ChevronRight, 
  ArrowRight, 
  Check, 
  X,
  Clock,
  CheckCircle2,
  ListTodo,
  RotateCw,
  AlertCircle
} from 'lucide-react';

export const BacklogView: React.FC = () => {
  const {
    currentProject,
    projectStories,
    projectSprints,
    projectTasks,
    createStory,
    updateStory,
    deleteStory,
    createTask,
    addToast,
  } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'id' | 'priority' | 'points'>('id');

  // Modals & Drawers
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedStory, setSelectedStory] = useState<UserStory | null>(null);
  const [storyToDelete, setStoryToDelete] = useState<UserStory | null>(null);

  // New story form state
  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newPriority, setNewPriority] = useState<PriorityLevel>('High');
  const [newPoints, setNewPoints] = useState<number>(5);
  const [newCriteria, setNewCriteria] = useState<string[]>([
    'Input validation enforces strict formatting rules',
    'Response returns within 250ms under typical network conditions',
  ]);
  const [newCriterionText, setNewCriterionText] = useState('');

  // AI Task Generation State
  const [isAiTaskModalOpen, setIsAiTaskModalOpen] = useState(false);
  const [isGeneratingTasks, setIsGeneratingTasks] = useState(false);
  const [suggestedTasks, setSuggestedTasks] = useState<SuggestedTaskItem[]>([]);

  // Filtered & Sorted stories
  const filteredStories = useMemo(() => {
    return projectStories
      .filter((story) => {
        const matchesSearch =
          story.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          story.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
          story.id.toLowerCase().includes(searchQuery.toLowerCase());
        const matchesPriority = priorityFilter === 'All' || story.priority === priorityFilter;
        const matchesStatus = statusFilter === 'All' || story.status === statusFilter;
        return matchesSearch && matchesPriority && matchesStatus;
      })
      .sort((a, b) => {
        if (sortBy === 'priority') {
          const rank = { Critical: 4, High: 3, Medium: 2, Low: 1 };
          return rank[b.priority] - rank[a.priority];
        }
        if (sortBy === 'points') {
          return b.storyPoints - a.storyPoints;
        }
        return a.id.localeCompare(b.id);
      });
  }, [projectStories, searchQuery, priorityFilter, statusFilter, sortBy]);

  // Handle Create Story
  const handleCreateStory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDescription.trim()) {
      addToast({ title: 'Missing required fields', message: 'Title and description are required.', type: 'warning' });
      return;
    }

    createStory({
      title: newTitle.trim(),
      description: newDescription.trim(),
      priority: newPriority,
      storyPoints: newPoints,
      status: 'Backlog',
      acceptanceCriteria: newCriteria.map((c, i) => ({ id: `ac-${Date.now()}-${i}`, text: c, completed: false })),
      projectId: currentProject?.id || '',
    });

    setIsCreateModalOpen(false);
    setNewTitle('');
    setNewDescription('');
    setNewCriteria(['Input validation enforces strict formatting rules']);
  };

  // Add criterion in create form
  const handleAddCriterion = () => {
    if (!newCriterionText.trim()) return;
    setNewCriteria((prev) => [...prev, newCriterionText.trim()]);
    setNewCriterionText('');
  };

  const [activeGeneratingStory, setActiveGeneratingStory] = useState<UserStory | null>(null);
  const [taskGenError, setTaskGenError] = useState<string | null>(null);

  // Trigger AI Task generation for selected story
  const handleOpenAiTaskGeneration = async (story: UserStory) => {
    setActiveGeneratingStory(story);
    setIsAiTaskModalOpen(true);
    setIsGeneratingTasks(true);
    setTaskGenError(null);
    try {
      const tasks = await aiClient.generateTasksForStory(story.title, story.description);
      setSuggestedTasks(tasks);
    } catch (err: any) {
      const msg = err instanceof AiClientError ? err.message : (err?.message || 'Failed to generate tasks.');
      setTaskGenError(msg);
      addToast({ title: 'Task Generation Failed', message: msg, type: 'error' });
    } finally {
      setIsGeneratingTasks(false);
    }
  };

  // Save selected AI tasks into actual tasks linked to this story
  const handleSaveSelectedTasks = () => {
    if (!selectedStory || !currentProject) return;
    const selected = suggestedTasks.filter((t) => t.selected);
    if (selected.length === 0) {
      addToast({ title: 'No Tasks Selected', message: 'Please check at least one task to create.', type: 'warning' });
      return;
    }

    selected.forEach((st) => {
      createTask({
        title: st.title,
        description: st.description,
        status: 'To Do',
        priority: st.priority,
        assigneeName: currentProject.teamMembers[0]?.name || 'Alex Morgan',
        assigneeInitials: currentProject.teamMembers[0]?.avatarInitials || 'AM',
        dueDate: currentProject.endDate,
        storyId: selectedStory.id,
        projectId: currentProject.id,
        sprintId: selectedStory.sprintId,
        estimatedHours: st.estimatedHours,
        completedHours: 0,
        isAiSuggested: true,
        confirmed: true,
      });
    });

    setIsAiTaskModalOpen(false);
    addToast({
      title: 'Tasks Created & Linked',
      message: `${selected.length} tasks added to ${selectedStory.id}.`,
      type: 'success',
    });
  };

  // Toggle acceptance criterion in detail drawer
  const handleToggleCriterion = (criterionId: string) => {
    if (!selectedStory) return;
    const updated = {
      ...selectedStory,
      acceptanceCriteria: selectedStory.acceptanceCriteria.map((ac) =>
        ac.id === criterionId ? { ...ac, completed: !ac.completed } : ac
      ),
    };
    setSelectedStory(updated);
    updateStory(selectedStory.id, { acceptanceCriteria: updated.acceptanceCriteria });
  };

  // Add new criterion in detail drawer
  const handleAddDrawerCriterion = (text: string) => {
    if (!selectedStory || !text.trim()) return;
    const newAc = { id: `ac-${Date.now()}`, text: text.trim(), completed: false };
    const updatedCriteria = [...selectedStory.acceptanceCriteria, newAc];
    setSelectedStory({ ...selectedStory, acceptanceCriteria: updatedCriteria });
    updateStory(selectedStory.id, { acceptanceCriteria: updatedCriteria });
  };

  // Remove criterion in detail drawer
  const handleRemoveDrawerCriterion = (id: string) => {
    if (!selectedStory) return;
    const updatedCriteria = selectedStory.acceptanceCriteria.filter((ac) => ac.id !== id);
    setSelectedStory({ ...selectedStory, acceptanceCriteria: updatedCriteria });
    updateStory(selectedStory.id, { acceptanceCriteria: updatedCriteria });
  };

  // Tasks linked to the currently selected story
  const linkedTasks = useMemo(() => {
    if (!selectedStory) return [];
    return projectTasks.filter((t) => t.storyId === selectedStory.id);
  }, [projectTasks, selectedStory]);

  return (
    <div className="space-y-6">
      
      {/* Title & Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200 dark:border-stone-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-stone-900 dark:text-stone-100 flex items-center gap-2">
            <span>Product Backlog</span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-teal-50 dark:bg-teal-950/60 text-teal-800 dark:text-teal-300">
              {projectStories.length} User Stories
            </span>
          </h1>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
            Prioritize user requirements, assign story points, and break down requirements into actionable engineering tasks.
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="flex items-center gap-1.5 py-2 px-3.5 rounded-xl text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Create User Story</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center gap-3">
        {/* Search */}
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search stories by ID, title, or criteria..."
            className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 focus:outline-none focus:ring-2 focus:ring-teal-700"
          />
        </div>

        {/* Priority Filter */}
        <select
          value={priorityFilter}
          onChange={(e) => setPriorityFilter(e.target.value)}
          className="py-1.5 px-3 text-xs rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 text-stone-700 dark:text-stone-300 focus:outline-none focus:ring-2 focus:ring-teal-700"
        >
          <option value="All">All Priorities</option>
          <option value="Critical">Critical</option>
          <option value="High">High</option>
          <option value="Medium">Medium</option>
          <option value="Low">Low</option>
        </select>

        {/* Status Filter */}
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="py-1.5 px-3 text-xs rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 text-stone-700 dark:text-stone-300 focus:outline-none focus:ring-2 focus:ring-teal-700"
        >
          <option value="All">All Statuses</option>
          <option value="Backlog">Backlog</option>
          <option value="In Sprint">In Sprint</option>
          <option value="Completed">Completed</option>
        </select>

        {/* Sort By */}
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as any)}
          className="py-1.5 px-3 text-xs rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 text-stone-700 dark:text-stone-300 focus:outline-none focus:ring-2 focus:ring-teal-700"
        >
          <option value="id">Sort by ID</option>
          <option value="priority">Sort by Priority</option>
          <option value="points">Sort by Story Points</option>
        </select>
      </div>

      {/* Stories Table */}
      {filteredStories.length === 0 ? (
        <EmptyState
          icon={Layers}
          title="No user stories found"
          description="Create your first user story or clear search filters."
          actionLabel="Create User Story"
          onAction={() => setIsCreateModalOpen(true)}
        />
      ) : (
        <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-stone-50 dark:bg-stone-800/80 text-stone-600 dark:text-stone-300 border-b border-stone-200 dark:border-stone-800">
                <tr>
                  <th className="py-3 px-4 font-semibold">Story ID</th>
                  <th className="py-3 px-4 font-semibold">Title &amp; Scope</th>
                  <th className="py-3 px-4 font-semibold">Priority</th>
                  <th className="py-3 px-4 font-semibold text-center">Points</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold">Acceptance Criteria Preview</th>
                  <th className="py-3 px-4 font-semibold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                {filteredStories.map((story) => {
                  const completedCriteria = story.acceptanceCriteria.filter((c) => c.completed).length;
                  const totalCriteria = story.acceptanceCriteria.length;
                  const sprintName = projectSprints.find((s) => s.id === story.sprintId)?.name;

                  return (
                    <tr
                      key={story.id}
                      onClick={() => setSelectedStory(story)}
                      className="hover:bg-stone-50/70 dark:hover:bg-stone-800/40 cursor-pointer transition-colors group"
                    >
                      <td className="py-3 px-4 font-mono font-bold text-teal-800 dark:text-teal-400 whitespace-nowrap">
                        {story.displayNumber || story.id}
                      </td>

                      <td className="py-3 px-4 max-w-sm">
                        <p className="font-semibold text-stone-900 dark:text-stone-100 group-hover:text-teal-700 transition-colors">
                          {story.title}
                        </p>
                        <p className="text-[11px] text-stone-500 line-clamp-1 mt-0.5">
                          {story.description}
                        </p>
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap">
                        <PriorityBadge priority={story.priority} size="sm" />
                      </td>

                      <td className="py-3 px-4 text-center whitespace-nowrap">
                        <span className="font-bold text-stone-700 dark:text-stone-300 font-mono tabular-nums bg-stone-100 dark:bg-stone-800 px-2 py-0.5 rounded">
                          {story.storyPoints} pts
                        </span>
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap">
                        <div>
                          <StatusPill status={story.status} size="sm" />
                          {sprintName && (
                            <p className="text-[10px] text-stone-400 mt-0.5 truncate max-w-[100px]">
                              {sprintName}
                            </p>
                          )}
                        </div>
                      </td>

                      <td className="py-3 px-4 max-w-xs">
                        <div className="flex items-center gap-1.5 text-[11px] text-stone-500">
                          <CheckCircle2 className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                          <span>
                            {completedCriteria}/{totalCriteria} verified
                          </span>
                        </div>
                        {story.acceptanceCriteria[0] && (
                          <p className="text-[10px] text-stone-400 truncate mt-0.5">
                            &quot;{story.acceptanceCriteria[0].text}&quot;
                          </p>
                        )}
                      </td>

                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1" onClick={(e) => e.stopPropagation()}>
                          <button
                            onClick={() => setSelectedStory(story)}
                            className="p-1.5 text-stone-400 hover:text-teal-700 dark:hover:text-teal-400 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
                            title="View details & generate tasks"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setStoryToDelete(story)}
                            className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
                            title="Delete story"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* STORY DETAIL DRAWER */}
      <Drawer
        isOpen={Boolean(selectedStory)}
        onClose={() => setSelectedStory(null)}
        title={selectedStory ? `${selectedStory.displayNumber || selectedStory.id}: ${selectedStory.title}` : 'User Story'}
        subtitle="Agile User Story Specification & Task Breakdown"
        width="lg"
      >
        {selectedStory && (
          <div className="space-y-6 text-xs">
            
            {/* Top Action Bar */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span className="font-semibold text-teal-950 dark:text-teal-200">
                  AI Task Generation Available
                </span>
              </div>
              <button
                type="button"
                onClick={() => handleOpenAiTaskGeneration(selectedStory)}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors shadow-2xs flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Generate Tasks with AI</span>
              </button>
            </div>

            {/* Editable Story Meta */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-stone-500 mb-1 font-semibold">Priority</label>
                <select
                  value={selectedStory.priority}
                  onChange={(e) => {
                    const priority = e.target.value as PriorityLevel;
                    setSelectedStory({ ...selectedStory, priority });
                    updateStory(selectedStory.id, { priority });
                  }}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900"
                >
                  <option value="Critical">Critical</option>
                  <option value="High">High</option>
                  <option value="Medium">Medium</option>
                  <option value="Low">Low</option>
                </select>
              </div>

              <div>
                <label className="block text-stone-500 mb-1 font-semibold">Story Points</label>
                <input
                  type="number"
                  min="1"
                  max="40"
                  value={selectedStory.storyPoints}
                  onChange={(e) => {
                    const points = parseInt(e.target.value, 10) || 1;
                    setSelectedStory({ ...selectedStory, storyPoints: points });
                    updateStory(selectedStory.id, { storyPoints: points });
                  }}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 tabular-nums font-mono"
                >
                </input>
              </div>

              <div>
                <label className="block text-stone-500 mb-1 font-semibold">Sprint Assignment</label>
                <select
                  value={selectedStory.sprintId || ''}
                  onChange={(e) => {
                    const sprintId = e.target.value || undefined;
                    const status: StoryStatus = sprintId ? 'In Sprint' : 'Backlog';
                    setSelectedStory({ ...selectedStory, sprintId, status });
                    updateStory(selectedStory.id, { sprintId, status });
                  }}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900"
                >
                  <option value="">Product Backlog (Unassigned)</option>
                  {projectSprints.map((sp) => (
                    <option key={sp.id} value={sp.id}>
                      {sp.name} ({sp.status})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-stone-500 mb-1 font-semibold">Related Requirement</label>
                <input
                  type="text"
                  value={selectedStory.relatedRequirement || ''}
                  onChange={(e) => {
                    setSelectedStory({ ...selectedStory, relatedRequirement: e.target.value });
                    updateStory(selectedStory.id, { relatedRequirement: e.target.value });
                  }}
                  placeholder="e.g. REQ-SEC-01"
                  className="w-full px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 font-mono"
                />
              </div>
            </div>

            {/* Description */}
            <div>
              <label className="block text-stone-500 mb-1 font-semibold">User Story Narrative</label>
              <textarea
                rows={3}
                value={selectedStory.description}
                onChange={(e) => setSelectedStory({ ...selectedStory, description: e.target.value })}
                onBlur={() => updateStory(selectedStory.id, { description: selectedStory.description })}
                className="w-full p-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 leading-relaxed"
              />
            </div>

            {/* Acceptance Criteria (Editable Checklist) */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-stone-700 dark:text-stone-300">
                  Acceptance Criteria ({selectedStory.acceptanceCriteria.filter((c) => c.completed).length}/
                  {selectedStory.acceptanceCriteria.length})
                </span>
              </div>

              <div className="space-y-1.5">
                {selectedStory.acceptanceCriteria.map((ac) => (
                  <div
                    key={ac.id}
                    className="flex items-start justify-between gap-2 p-2 rounded-lg bg-stone-50 dark:bg-stone-800/60 border border-stone-200/80 dark:border-stone-700/80"
                  >
                    <label className="flex items-start gap-2 flex-1 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={ac.completed}
                        onChange={() => handleToggleCriterion(ac.id)}
                        className="mt-0.5 rounded border-stone-300 text-teal-700 focus:ring-teal-700"
                      />
                      <span className={`text-xs ${ac.completed ? 'line-through text-stone-400' : 'text-stone-700 dark:text-stone-200'}`}>
                        {ac.text}
                      </span>
                    </label>
                    <button
                      type="button"
                      onClick={() => handleRemoveDrawerCriterion(ac.id)}
                      className="text-stone-400 hover:text-rose-600 p-0.5"
                      title="Remove criterion"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Add Criterion Input */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="text"
                  placeholder="Add acceptance criterion..."
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddDrawerCriterion((e.target as HTMLInputElement).value);
                      (e.target as HTMLInputElement).value = '';
                    }
                  }}
                  className="flex-1 px-2.5 py-1.5 text-xs rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900"
                />
              </div>
            </div>

            {/* Related Tasks Linked to this Story */}
            <div className="space-y-2 pt-4 border-t border-stone-100 dark:border-stone-800">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-stone-700 dark:text-stone-300 flex items-center gap-1.5">
                  <ListTodo className="w-4 h-4 text-teal-700 dark:text-teal-400" />
                  <span>Linked Tasks ({linkedTasks.length})</span>
                </span>
              </div>

              {linkedTasks.length === 0 ? (
                <p className="text-xs text-stone-400 italic p-3 bg-stone-50 dark:bg-stone-800/40 rounded-xl">
                  No tasks linked yet. Click &quot;Generate Tasks with AI&quot; above to break down this story automatically.
                </p>
              ) : (
                <div className="space-y-1.5">
                  {linkedTasks.map((task) => (
                    <div
                      key={task.id}
                      className="p-2.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 flex items-center justify-between"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-semibold text-stone-500">{task.displayNumber || task.id}</span>
                          <span className="font-medium text-stone-900 dark:text-stone-100 truncate">
                            {task.title}
                          </span>
                        </div>
                        <p className="text-[11px] text-stone-400 mt-0.5">
                          {task.assigneeName} · {task.status}
                        </p>
                      </div>
                      <PriorityBadge priority={task.priority} size="sm" />
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>
        )}
      </Drawer>

      {/* AI TASK BREAKDOWN REVIEW MODAL */}
      <Modal
        isOpen={isAiTaskModalOpen}
        onClose={() => setIsAiTaskModalOpen(false)}
        title="AI Task Breakdown &amp; Estimation"
        description="Review recommended task breakdowns derived from this user story. Customize titles or uncheck items before saving."
        maxWidth="2xl"
      >
        {isGeneratingTasks ? (
          <div className="py-12 flex flex-col items-center text-center space-y-3">
            <div className="w-8 h-8 rounded-full border-2 border-teal-700 border-t-transparent animate-spin" />
            <p className="text-xs text-stone-500">Synthesizing engineering tasks and test suites...</p>
          </div>
        ) : taskGenError ? (
          <div className="py-8 flex flex-col items-center text-center space-y-3">
            <AlertCircle className="w-8 h-8 text-rose-500" />
            <p className="text-xs font-semibold text-rose-700 dark:text-rose-300 max-w-md">{taskGenError}</p>
            <button
              type="button"
              onClick={() => activeGeneratingStory && handleOpenAiTaskGeneration(activeGeneratingStory)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>Retry Task Generation</span>
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2 max-h-[55vh] overflow-y-auto pr-1">
              {suggestedTasks.map((st, index) => (
                <div
                  key={st.id}
                  className={`p-3 rounded-xl border transition-colors ${
                    st.selected
                      ? 'border-teal-300 dark:border-teal-800 bg-teal-50/50 dark:bg-teal-950/30'
                      : 'border-stone-200 dark:border-stone-800 opacity-60'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <input
                      type="checkbox"
                      checked={st.selected}
                      onChange={(e) => {
                        const checked = e.target.checked;
                        setSuggestedTasks((prev) =>
                          prev.map((t, i) => (i === index ? { ...t, selected: checked } : t))
                        );
                      }}
                      className="mt-1 rounded border-stone-300 text-teal-700 focus:ring-teal-700"
                    />
                    <div className="flex-1 space-y-1">
                      <input
                        type="text"
                        value={st.title}
                        onChange={(e) => {
                          const val = e.target.value;
                          setSuggestedTasks((prev) =>
                            prev.map((t, i) => (i === index ? { ...t, title: val } : t))
                          );
                        }}
                        className="w-full text-xs font-semibold bg-transparent border-b border-transparent hover:border-stone-300 focus:border-teal-600 outline-none"
                      />
                      <p className="text-[11px] text-stone-500 dark:text-stone-400">
                        {st.description}
                      </p>
                      <div className="flex items-center gap-3 pt-1 text-[11px] text-stone-400">
                        <span>Estimate: ~{st.estimatedHours}h</span>
                        <span>·</span>
                        <PriorityBadge priority={st.priority} size="sm" />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-4 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between">
              <span className="text-xs text-stone-500">
                {suggestedTasks.filter((t) => t.selected).length} of {suggestedTasks.length} tasks selected
              </span>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsAiTaskModalOpen(false)}
                  className="px-3.5 py-1.5 text-xs text-stone-600 dark:text-stone-400 hover:bg-stone-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveSelectedTasks}
                  className="px-4 py-2 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Save Selected Tasks</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* CREATE USER STORY MODAL */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Create User Story"
        description="Draft a user story using agile persona formatting (As a..., I want..., So that...)."
        maxWidth="lg"
      >
        <form onSubmit={handleCreateStory} className="space-y-4 text-xs">
          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Story Title *
            </label>
            <input
              type="text"
              value={newTitle}
              onChange={(e) => setNewTitle(e.target.value)}
              placeholder="e.g. User Registration with Email and Phone"
              className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 focus:outline-none focus:ring-2 focus:ring-teal-700"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
                Priority
              </label>
              <select
                value={newPriority}
                onChange={(e) => setNewPriority(e.target.value as PriorityLevel)}
                className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
              >
                <option value="Critical">Critical</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>

            <div>
              <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
                Story Points (Fibonacci)
              </label>
              <select
                value={newPoints}
                onChange={(e) => setNewPoints(parseInt(e.target.value, 10))}
                className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 font-mono"
              >
                <option value={1}>1 pt</option>
                <option value={2}>2 pts</option>
                <option value={3}>3 pts</option>
                <option value={5}>5 pts</option>
                <option value={8}>8 pts</option>
                <option value={13}>13 pts</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Description (Narrative) *
            </label>
            <textarea
              rows={3}
              value={newDescription}
              onChange={(e) => setNewDescription(e.target.value)}
              placeholder="As a prospective user, I want to create an account so that I can access personalized features..."
              className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 focus:outline-none focus:ring-2 focus:ring-teal-700 leading-relaxed"
            />
          </div>

          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Initial Acceptance Criteria
            </label>
            <div className="space-y-1.5 mb-2">
              {newCriteria.map((crit, idx) => (
                <div key={idx} className="flex items-center justify-between p-1.5 px-2 rounded-lg bg-stone-50 dark:bg-stone-800 text-stone-700 dark:text-stone-200 text-xs">
                  <span>{crit}</span>
                  <button
                    type="button"
                    onClick={() => setNewCriteria((prev) => prev.filter((_, i) => i !== idx))}
                    className="text-stone-400 hover:text-rose-500"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={newCriterionText}
                onChange={(e) => setNewCriterionText(e.target.value)}
                placeholder="Add validation criterion..."
                className="flex-1 px-2.5 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-950"
              />
              <button
                type="button"
                onClick={handleAddCriterion}
                className="px-3 py-1.5 bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 rounded-lg hover:bg-stone-200"
              >
                Add
              </button>
            </div>
          </div>

          <div className="pt-4 border-t border-stone-100 dark:border-stone-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsCreateModalOpen(false)}
              className="px-4 py-2 text-stone-600 dark:text-stone-400 hover:bg-stone-100 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs"
            >
              Create Story
            </button>
          </div>
        </form>
      </Modal>

      {/* CONFIRM DELETE MODAL */}
      <ConfirmDialog
        isOpen={Boolean(storyToDelete)}
        title="Delete User Story"
        message={`Are you sure you want to permanently delete "${storyToDelete?.id}: ${storyToDelete?.title}"? All linked tasks will also be decoupled.`}
        confirmLabel="Delete Story"
        onConfirm={() => {
          if (storyToDelete) deleteStory(storyToDelete.id);
        }}
        onCancel={() => setStoryToDelete(null)}
      />

    </div>
  );
};
