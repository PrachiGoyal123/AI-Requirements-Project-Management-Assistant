import React, { useState } from 'react';
import { useApp } from '../../store/AppContext';
import { Risk, RiskImpact, RiskProbability, RiskStatus, Dependency, DependencyStatus } from '../../types/risk';
import { PriorityBadge, StatusPill, ProvenanceBadge } from '../common/Badge';
import { Modal } from '../common/Modal';
import { ConfirmDialog } from '../common/ConfirmDialog';
import { EmptyState } from '../common/EmptyState';
import { aiClient, AiClientError, SuggestedRiskItem } from '../../services/ai/aiClient';
import { 
  Plus, 
  AlertTriangle, 
  Sparkles, 
  ShieldAlert, 
  Link2, 
  Trash2, 
  Check, 
  CheckCircle2, 
  X,
  FileText,
  RotateCw,
  AlertCircle
} from 'lucide-react';

export const RisksDependenciesView: React.FC = () => {
  const {
    currentProject,
    projectRisks,
    projectDependencies,
    projectStories,
    projectTasks,
    projectSprints,
    createRisk,
    updateRisk,
    confirmRisk,
    deleteRisk,
    createDependency,
    updateDependency,
    deleteDependency,
    addToast,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'risks' | 'dependencies'>('risks');

  // Modals
  const [isAddRiskModalOpen, setIsAddRiskModalOpen] = useState(false);
  const [isAnalyzeRisksModalOpen, setIsAnalyzeRisksModalOpen] = useState(false);
  const [isAddDepModalOpen, setIsAddDepModalOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<{ type: 'risk' | 'dep'; id: string; title: string } | null>(null);

  // Add Risk Form State
  const [riskTitle, setRiskTitle] = useState('');
  const [riskDesc, setRiskDesc] = useState('');
  const [riskImpact, setRiskImpact] = useState<RiskImpact>('High');
  const [riskProb, setRiskProb] = useState<RiskProbability>('Medium');
  const [riskMitigation, setRiskMitigation] = useState('');
  const [riskOwner, setRiskOwner] = useState(currentProject?.teamMembers[0]?.name || 'Alex Morgan');

  // Add Dependency Form State
  const [depTitle, setDepTitle] = useState('');
  const [depSource, setDepSource] = useState('');
  const [depDependent, setDepDependent] = useState('');
  const [depOwner, setDepOwner] = useState(currentProject?.teamMembers[0]?.name || 'Alex Morgan');
  const [depDueDate, setDepDueDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [depStatus, setDepStatus] = useState<DependencyStatus>('Pending');

  // AI Risk Analysis State
  const [isAnalyzingAi, setIsAnalyzingAi] = useState(false);
  const [riskAnalysisError, setRiskAnalysisError] = useState<string | null>(null);
  const [suggestedRisks, setSuggestedRisks] = useState<SuggestedRiskItem[]>([]);

  // Trigger AI Risk Analysis
  const handleOpenAiAnalysis = async () => {
    setIsAnalyzeRisksModalOpen(true);
    setIsAnalyzingAi(true);
    setRiskAnalysisError(null);
    try {
      const suggestions = await aiClient.analyzeRisks({
        project: currentProject,
        tasks: projectTasks,
        stories: projectStories,
        risks: projectRisks,
        dependencies: projectDependencies,
        sprint: projectSprints[0],
      });
      setSuggestedRisks(suggestions);
    } catch (err) {
      const msg = err instanceof AiClientError ? err.message : (err instanceof Error ? err.message : 'Failed to analyze risks with AI');
      setRiskAnalysisError(msg);
      addToast({ title: 'AI Risk Analysis Failed', message: msg, type: 'error' });
    } finally {
      setIsAnalyzingAi(false);
    }
  };

  // Save selected AI suggested risks
  const handleSaveSelectedRisks = () => {
    if (!currentProject) return;
    const selected = suggestedRisks.filter((r) => r.selected);
    if (selected.length === 0) {
      addToast({ title: 'No Risks Selected', message: 'Check at least one risk to save.', type: 'warning' });
      return;
    }

    selected.forEach((sr) => {
      createRisk({
        projectId: currentProject.id,
        title: sr.title,
        description: sr.description,
        impact: sr.impact,
        probability: sr.probability,
        status: 'Open',
        mitigationPlan: sr.mitigationPlan,
        owner: sr.owner,
        isAiSuggested: true,
        confirmed: false, // Carries unconfirmed tag until confirmed
      });
    });

    setIsAnalyzeRisksModalOpen(false);
    addToast({
      title: 'AI Risks Added to Ledger',
      message: `${selected.length} risks added with "AI-suggested" status.`,
      type: 'success',
    });
  };

  const handleCreateRisk = (e: React.FormEvent) => {
    e.preventDefault();
    if (!riskTitle.trim() || !currentProject) return;

    createRisk({
      projectId: currentProject.id,
      title: riskTitle.trim(),
      description: riskDesc.trim(),
      impact: riskImpact,
      probability: riskProb,
      status: 'Open',
      mitigationPlan: riskMitigation.trim(),
      owner: riskOwner,
      isAiSuggested: false,
      confirmed: true,
    });

    setIsAddRiskModalOpen(false);
    setRiskTitle('');
    setRiskDesc('');
    setRiskMitigation('');
  };

  const handleCreateDependency = (e: React.FormEvent) => {
    e.preventDefault();
    if (!depTitle.trim() || !currentProject) return;

    createDependency({
      projectId: currentProject.id,
      title: depTitle.trim(),
      sourceItem: depSource.trim() || 'Internal sprint milestone',
      dependentItem: depDependent.trim() || 'Downstream release',
      owner: depOwner,
      dueDate: depDueDate,
      status: depStatus,
    });

    setIsAddDepModalOpen(false);
    setDepTitle('');
    setDepSource('');
    setDepDependent('');
  };

  return (
    <div className="space-y-6">
      
      {/* Title & Tabs Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-200 dark:border-stone-800">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-stone-900 dark:text-stone-100 flex items-center gap-2">
            <span>Risks &amp; Dependencies</span>
          </h1>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
            Mitigate delivery threats, track cross-team commitments, and analyze vulnerability with AI intelligence.
          </p>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-3">
          <div className="flex items-center p-1 rounded-xl bg-stone-100 dark:bg-stone-800 border border-stone-200 dark:border-stone-700">
            <button
              onClick={() => setActiveTab('risks')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                activeTab === 'risks'
                  ? 'bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-2xs'
                  : 'text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
              <span>Project Risks ({projectRisks.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('dependencies')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                activeTab === 'dependencies'
                  ? 'bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-2xs'
                  : 'text-stone-500 hover:text-stone-800 dark:hover:text-stone-200'
              }`}
            >
              <Link2 className="w-3.5 h-3.5 text-teal-600" />
              <span>Dependencies ({projectDependencies.length})</span>
            </button>
          </div>

          {activeTab === 'risks' ? (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleOpenAiAnalysis}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-teal-800 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/70 border border-teal-200 dark:border-teal-800 rounded-xl hover:bg-teal-100 transition-colors shadow-2xs"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Analyze Risks with AI</span>
              </button>
              <button
                type="button"
                onClick={() => setIsAddRiskModalOpen(true)}
                className="flex items-center gap-1.5 py-2 px-3 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Add Risk</span>
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setIsAddDepModalOpen(true)}
              className="flex items-center gap-1.5 py-2 px-3.5 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Add Dependency</span>
            </button>
          )}
        </div>
      </div>

      {/* TAB 1: RISKS */}
      {activeTab === 'risks' && (
        <div className="space-y-4">
          {projectRisks.length === 0 ? (
            <EmptyState
              icon={ShieldAlert}
              title="No Risks Logged in Ledger"
              description="Log potential bottlenecks or run 'Analyze Risks with AI' to detect architectural dependencies."
              actionLabel="Add Risk"
              onAction={() => setIsAddRiskModalOpen(true)}
            />
          ) : (
            <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-stone-50 dark:bg-stone-800/80 text-stone-600 dark:text-stone-300 border-b border-stone-200 dark:border-stone-800">
                    <tr>
                      <th className="py-3 px-4 font-semibold">ID</th>
                      <th className="py-3 px-4 font-semibold">Risk Title &amp; Description</th>
                      <th className="py-3 px-4 font-semibold">Impact</th>
                      <th className="py-3 px-4 font-semibold">Probability</th>
                      <th className="py-3 px-4 font-semibold">Status</th>
                      <th className="py-3 px-4 font-semibold">Mitigation Strategy</th>
                      <th className="py-3 px-4 font-semibold">Owner</th>
                      <th className="py-3 px-4 font-semibold text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
                    {projectRisks.map((risk) => (
                      <tr key={risk.id} className="hover:bg-stone-50/60 dark:hover:bg-stone-800/40 transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-teal-800 dark:text-teal-400 whitespace-nowrap">
                          {risk.id}
                        </td>

                        <td className="py-3 px-4 max-w-xs">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-semibold text-stone-900 dark:text-stone-100">
                              {risk.title}
                            </span>
                            {risk.isAiSuggested && !risk.confirmed && (
                              <button
                                onClick={() => confirmRisk(risk.id)}
                                className="cursor-pointer"
                                title="Click to verify and confirm AI suggestion"
                              >
                                <ProvenanceBadge type="AI-suggested, unconfirmed" />
                              </button>
                            )}
                          </div>
                          <p className="text-[11px] text-stone-500 line-clamp-2 mt-0.5 leading-relaxed">
                            {risk.description}
                          </p>
                        </td>

                        <td className="py-3 px-4 whitespace-nowrap">
                          <PriorityBadge priority={risk.impact} size="sm" />
                        </td>

                        <td className="py-3 px-4 whitespace-nowrap font-medium text-stone-600 dark:text-stone-300">
                          {risk.probability}
                        </td>

                        <td className="py-3 px-4 whitespace-nowrap">
                          <select
                            value={risk.status}
                            onChange={(e) => updateRisk(risk.id, { status: e.target.value as RiskStatus })}
                            className="py-1 px-2 rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-xs font-medium"
                          >
                            <option value="Open">Open</option>
                            <option value="Mitigated">Mitigated</option>
                            <option value="Closed">Closed</option>
                            <option value="Accepted">Accepted</option>
                          </select>
                        </td>

                        <td className="py-3 px-4 max-w-xs text-[11px] text-stone-600 dark:text-stone-300 leading-relaxed">
                          {risk.mitigationPlan}
                        </td>

                        <td className="py-3 px-4 whitespace-nowrap text-stone-700 dark:text-stone-300">
                          {risk.owner}
                        </td>

                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1">
                            {risk.isAiSuggested && !risk.confirmed && (
                              <button
                                onClick={() => confirmRisk(risk.id)}
                                className="p-1 text-teal-700 hover:text-teal-900 dark:text-teal-400"
                                title="Confirm risk"
                              >
                                <CheckCircle2 className="w-4 h-4" />
                              </button>
                            )}
                            <button
                              onClick={() => setItemToDelete({ type: 'risk', id: risk.id, title: risk.title })}
                              className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
                              title="Delete risk"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: DEPENDENCIES */}
      {activeTab === 'dependencies' && (
        <div className="space-y-4">
          {projectDependencies.length === 0 ? (
            <EmptyState
              icon={Link2}
              title="No Dependencies Tracked"
              description="Track critical path dependencies such as 'UAT depends on Development Completion'."
              actionLabel="Add Dependency"
              onAction={() => setIsAddDepModalOpen(true)}
            />
          ) : (
            <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200 dark:border-stone-800 overflow-hidden shadow-xs">
              <div className="divide-y divide-stone-100 dark:divide-stone-800">
                {projectDependencies.map((dep) => (
                  <div
                    key={dep.id}
                    className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-stone-50/50 dark:hover:bg-stone-800/40 transition-colors"
                  >
                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono text-[11px] font-bold text-teal-800 dark:text-teal-400">
                          {dep.id}
                        </span>
                        <h4 className="text-xs font-bold text-stone-900 dark:text-stone-100">
                          {dep.title}
                        </h4>
                        <StatusPill status={dep.status} size="sm" />
                      </div>

                      <div className="flex items-center gap-2 text-xs text-stone-500 pt-0.5">
                        <span className="font-semibold text-stone-700 dark:text-stone-300">
                          {dep.sourceItem}
                        </span>
                        <span className="text-teal-600 font-bold">&rarr;</span>
                        <span className="font-semibold text-stone-700 dark:text-stone-300">
                          {dep.dependentItem}
                        </span>
                      </div>

                      {dep.impactNote && (
                        <p className="text-[11px] text-stone-400 italic mt-0.5">
                          Note: {dep.impactNote}
                        </p>
                      )}
                    </div>

                    <div className="flex items-center gap-4 shrink-0 text-xs">
                      <div className="text-right">
                        <p className="text-stone-600 dark:text-stone-300 font-medium">{dep.owner}</p>
                        <p className="text-[11px] text-stone-400 tabular-nums">Due {dep.dueDate}</p>
                      </div>

                      <select
                        value={dep.status}
                        onChange={(e) => updateDependency(dep.id, { status: e.target.value as DependencyStatus })}
                        className="py-1 px-2.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-900 text-xs font-medium"
                      >
                        <option value="Pending">Pending</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Resolved">Resolved</option>
                        <option value="Blocked">Blocked</option>
                      </select>

                      <button
                        onClick={() => setItemToDelete({ type: 'dep', id: dep.id, title: dep.title })}
                        className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors"
                        title="Remove dependency"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* AI RISK ANALYSIS MODAL */}
      <Modal
        isOpen={isAnalyzeRisksModalOpen}
        onClose={() => setIsAnalyzeRisksModalOpen(false)}
        title="Analyze Risks with AI"
        description="AI scan of architecture specifications, rate limits, and regulatory constraints. Select items to add to your ledger with 'AI-suggested' tags."
        maxWidth="2xl"
      >
        {isAnalyzingAi ? (
          <div className="py-12 flex flex-col items-center text-center space-y-3">
            <div className="w-8 h-8 rounded-full border-2 border-teal-700 border-t-transparent animate-spin" />
            <p className="text-xs text-stone-500">Scanning integration contracts and delivery dependencies...</p>
          </div>
        ) : riskAnalysisError ? (
          <div className="py-8 flex flex-col items-center text-center space-y-3">
            <div className="w-10 h-10 rounded-full bg-rose-50 dark:bg-rose-950/60 flex items-center justify-center text-rose-600">
              <AlertCircle className="w-5 h-5" />
            </div>
            <p className="text-xs text-rose-700 dark:text-rose-300 max-w-sm">{riskAnalysisError}</p>
            <button
              type="button"
              onClick={handleOpenAiAnalysis}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl bg-teal-700 text-white hover:bg-teal-800 shadow-xs"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span>Retry Analysis</span>
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2.5 max-h-[55vh] overflow-y-auto pr-1">
              {suggestedRisks.map((sr, idx) => (
                <div
                  key={sr.id}
                  className={`p-3.5 rounded-xl border transition-colors ${
                    sr.selected
                      ? 'border-teal-400 bg-teal-50/40 dark:bg-teal-950/30'
                      : 'border-stone-200 dark:border-stone-800 opacity-60'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    <input
                      type="checkbox"
                      checked={sr.selected}
                      onChange={(e) => {
                        const checked = e.target.checked;
                        setSuggestedRisks((prev) =>
                          prev.map((r, i) => (i === idx ? { ...r, selected: checked } : r))
                        );
                      }}
                      className="mt-1 rounded border-stone-300 text-teal-700 focus:ring-teal-700"
                    />
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-stone-900 dark:text-stone-100">
                          {sr.title}
                        </span>
                        <PriorityBadge priority={sr.impact} size="sm" />
                      </div>
                      <p className="text-[11px] text-stone-600 dark:text-stone-300 leading-relaxed">
                        {sr.description}
                      </p>
                      <p className="text-[11px] text-teal-800 dark:text-teal-300 bg-white/70 dark:bg-stone-900/60 p-2 rounded-lg border border-teal-100 dark:border-teal-900 mt-1">
                        <strong>Mitigation Plan:</strong> {sr.mitigationPlan}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-4 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between">
              <span className="text-xs text-stone-500">
                {suggestedRisks.filter((r) => r.selected).length} of {suggestedRisks.length} selected
              </span>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsAnalyzeRisksModalOpen(false)}
                  className="px-3.5 py-1.5 text-xs text-stone-600 dark:text-stone-400 hover:bg-stone-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSaveSelectedRisks}
                  className="px-4 py-2 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Save to Risk Ledger</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* ADD RISK MODAL */}
      <Modal
        isOpen={isAddRiskModalOpen}
        onClose={() => setIsAddRiskModalOpen(false)}
        title="Add Project Risk"
        description="Log an identified impediment or vulnerability to active risk mitigation ledger."
        maxWidth="md"
      >
        <form onSubmit={handleCreateRisk} className="space-y-4 text-xs">
          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Risk Title *
            </label>
            <input
              type="text"
              value={riskTitle}
              onChange={(e) => setRiskTitle(e.target.value)}
              placeholder="e.g. Third-party SMS gateway carrier latency"
              className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 focus:outline-none focus:ring-2 focus:ring-teal-700"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
                Impact
              </label>
              <select
                value={riskImpact}
                onChange={(e) => setRiskImpact(e.target.value as RiskImpact)}
                className="w-full px-2.5 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
              >
                <option value="Critical">Critical</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>
            <div>
              <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
                Probability
              </label>
              <select
                value={riskProb}
                onChange={(e) => setRiskProb(e.target.value as RiskProbability)}
                className="w-full px-2.5 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
              >
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Owner
            </label>
            <select
              value={riskOwner}
              onChange={(e) => setRiskOwner(e.target.value)}
              className="w-full px-2.5 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
            >
              {currentProject?.teamMembers.map((tm) => (
                <option key={tm.id} value={tm.name}>
                  {tm.name} ({tm.role})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Mitigation Plan
            </label>
            <textarea
              rows={3}
              value={riskMitigation}
              onChange={(e) => setRiskMitigation(e.target.value)}
              placeholder="Action plan to eliminate or reduce probability/impact..."
              className="w-full p-2.5 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 leading-relaxed"
            />
          </div>

          <div className="pt-4 border-t border-stone-100 dark:border-stone-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsAddRiskModalOpen(false)}
              className="px-4 py-2 text-stone-600 dark:text-stone-400 hover:bg-stone-100 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs"
            >
              Save Risk
            </button>
          </div>
        </form>
      </Modal>

      {/* ADD DEPENDENCY MODAL */}
      <Modal
        isOpen={isAddDepModalOpen}
        onClose={() => setIsAddDepModalOpen(false)}
        title="Add Dependency"
        description="Establish explicit dependency linkage between tasks or teams."
        maxWidth="md"
      >
        <form onSubmit={handleCreateDependency} className="space-y-4 text-xs">
          <div>
            <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
              Dependency Summary *
            </label>
            <input
              type="text"
              value={depTitle}
              onChange={(e) => setDepTitle(e.target.value)}
              placeholder="e.g. UAT depends on Development Completion"
              className="w-full px-3 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 focus:outline-none focus:ring-2 focus:ring-teal-700"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
                Source Milestone / Work
              </label>
              <input
                type="text"
                value={depSource}
                onChange={(e) => setDepSource(e.target.value)}
                placeholder="e.g. Sprint 3 Backend API"
                className="w-full px-2.5 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
              />
            </div>
            <div>
              <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
                Dependent Item
              </label>
              <input
                type="text"
                value={depDependent}
                onChange={(e) => setDepDependent(e.target.value)}
                placeholder="e.g. Client QA Sign-off"
                className="w-full px-2.5 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
                Due Date
              </label>
              <input
                type="date"
                value={depDueDate}
                onChange={(e) => setDepDueDate(e.target.value)}
                className="w-full px-2.5 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
              />
            </div>
            <div>
              <label className="block text-stone-700 dark:text-stone-300 font-semibold mb-1">
                Status
              </label>
              <select
                value={depStatus}
                onChange={(e) => setDepStatus(e.target.value as DependencyStatus)}
                className="w-full px-2.5 py-2 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950"
              >
                <option value="Pending">Pending</option>
                <option value="In Progress">In Progress</option>
                <option value="Resolved">Resolved</option>
                <option value="Blocked">Blocked</option>
              </select>
            </div>
          </div>

          <div className="pt-4 border-t border-stone-100 dark:border-stone-800 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsAddDepModalOpen(false)}
              className="px-4 py-2 text-stone-600 dark:text-stone-400 hover:bg-stone-100 rounded-xl"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2 font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs"
            >
              Save Dependency
            </button>
          </div>
        </form>
      </Modal>

      {/* CONFIRM DELETE DIALOG */}
      <ConfirmDialog
        isOpen={Boolean(itemToDelete)}
        title="Delete Item"
        message={`Are you sure you want to permanently delete "${itemToDelete?.title}"?`}
        onConfirm={() => {
          if (itemToDelete?.type === 'risk') {
            deleteRisk(itemToDelete.id);
          } else if (itemToDelete?.type === 'dep') {
            deleteDependency(itemToDelete.id);
          }
          setItemToDelete(null);
        }}
        onCancel={() => setItemToDelete(null)}
      />

    </div>
  );
};
