import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../../store/AppContext';
import { MarkdownRenderer } from '../common/MarkdownRenderer';
import { aiClient, AiClientError } from '../../services/ai/aiClient';
import { supabaseService } from '../../services/supabaseService';
import { 
  Bot, 
  Send, 
  Sparkles, 
  Copy, 
  Check, 
  RotateCw,
  HelpCircle,
  Clock,
  ShieldAlert,
  Layers,
  AlertCircle,
  Square
} from 'lucide-react';

interface ProjectMessage {
  id: string;
  sender: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export const ProjectAssistantView: React.FC = () => {
  const {
    user,
    isGuest,
    currentProject,
    currentSprint,
    projectTasks,
    projectStories,
    projectRisks,
    projectDecisions,
    projectDependencies,
    addToast,
  } = useApp();

  const [inputQuery, setInputQuery] = useState('');
  const [messages, setMessages] = useState<ProjectMessage[]>([
    {
      id: 'init-msg-1',
      sender: 'assistant',
      content: `Hello! I am your **Project Assistant** for **${currentProject?.name}**. 

I have access to your live sprint backlog, task schedules, impediment flags, cross-team dependencies, and client approval deadlines. 

You can ask me questions about delivery velocity, delayed deliverables, or what to discuss in your next stakeholder sync.`,
      timestamp: 'Just now',
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [assistantError, setAssistantError] = useState<string | null>(null);
  const [lastUserQuery, setLastUserQuery] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Load persisted project chat messages for authenticated users
  useEffect(() => {
    if (!currentProject || !user || isGuest) return;
    let isCancelled = false;
    supabaseService.fetchProjectChatMessages(currentProject.id).then((savedMsgs) => {
      if (isCancelled) return;
      if (savedMsgs.length > 0) {
        setMessages(savedMsgs);
      }
    }).catch((err) => {
      console.warn('Could not load project chat messages:', err);
    });
    return () => {
      isCancelled = true;
    };
  }, [currentProject?.id, user?.id, isGuest]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleStopGenerating = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
      setIsLoading(false);
    }
  };

  const handleSend = async (textToSend?: string) => {
    const query = textToSend !== undefined ? textToSend : inputQuery;
    if (!query.trim() || !currentProject || isLoading) return;

    setLastUserQuery(query.trim());
    setAssistantError(null);

    const userMsg: ProjectMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      content: query.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    const asstId = `asst-${Date.now()}`;
    const initialAsstMsg: ProjectMessage = {
      id: asstId,
      sender: 'assistant',
      content: '',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg, initialAsstMsg]);
    setInputQuery('');
    setIsLoading(true);

    const abortController = new AbortController();
    abortControllerRef.current = abortController;

    const projectContext = {
      project: currentProject,
      sprint: currentSprint,
      tasks: projectTasks,
      stories: projectStories,
      risks: projectRisks,
      decisions: projectDecisions,
      dependencies: projectDependencies,
    };

    const historyPayload = messages
      .filter((m) => m.id !== 'init-msg-1' && m.content.trim())
      .map((m) => ({
        role: m.sender,
        content: m.content,
      }));

    let fullAnswer = '';

    try {
      await aiClient.streamProjectAssistant({
        query: query.trim(),
        projectData: projectContext,
        onChunk: (chunk: string) => {
          fullAnswer += chunk;
          setMessages((prev) =>
            prev.map((m) => (m.id === asstId ? { ...m, content: m.content + chunk } : m))
          );
        },
        signal: abortController.signal,
      });

      // Persist to Supabase if authenticated
      if (user && !isGuest && currentProject && fullAnswer.trim()) {
        supabaseService.addProjectChatMessage(currentProject.id, 'user', query.trim()).catch((err) => {
          console.warn('Failed to persist user message to Supabase:', err);
        });
        supabaseService.addProjectChatMessage(currentProject.id, 'assistant', fullAnswer).catch((err) => {
          console.warn('Failed to persist assistant message to Supabase:', err);
        });
      }
    } catch (err: any) {
      if (err.name === 'AbortError') {
        // User aborted cleanly
      } else {
        const msg = err instanceof AiClientError ? err.message : (err instanceof Error ? err.message : 'Failed to query assistant');
        setAssistantError(msg);
        addToast({ title: 'Assistant Response Failed', message: msg, type: 'error' });
      }
    } finally {
      setIsLoading(false);
      abortControllerRef.current = null;
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    addToast({ title: 'Copied to clipboard', type: 'info' });
    setTimeout(() => setCopiedId(null), 2000);
  };

  const questionChips = [
    'Which tasks are delayed?',
    'What are the current sprint blockers?',
    'What should I discuss with the client?',
    'Summarize the current project status.',
    'Which dependencies may affect delivery?',
    'What should I focus on this week?',
  ];

  if (!currentProject) return null;

  return (
    <div className="flex flex-col h-[750px] bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl shadow-xs overflow-hidden">
      
      {/* Header */}
      <div className="px-6 py-4 border-b border-stone-200/80 dark:border-stone-800/80 bg-stone-50/50 dark:bg-stone-950/40 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-xl bg-teal-50 dark:bg-teal-950/80 text-teal-700 dark:text-teal-400 border border-teal-200/60 dark:border-teal-800/60 flex items-center justify-center">
            <Bot className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
              <span>AI Project Assistant</span>
              <span className="text-[10px] font-semibold text-teal-800 dark:text-teal-300 bg-teal-50 dark:bg-teal-950 px-2 py-0.5 rounded-full">
                Connected to {currentProject.name} state
              </span>
            </h2>
            <p className="text-[11px] text-stone-500 dark:text-stone-400">
              Answers are computed strictly from real tasks, risks, and decision records.
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            setMessages([
              {
                id: `reset-${Date.now()}`,
                sender: 'assistant',
                content: `Chat cleared. Ask me anything regarding current sprint velocity or blockers for **${currentProject.name}**.`,
                timestamp: 'Just now',
              },
            ]);
            addToast({ title: 'Conversation Reset', type: 'info' });
          }}
          className="text-xs text-stone-500 hover:text-stone-800 dark:hover:text-stone-200 p-1.5"
          title="Reset chat"
        >
          <RotateCw className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Message History */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
        {messages.map((msg) => {
          const isUser = msg.sender === 'user';
          return (
            <div
              key={msg.id}
              className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <div
                className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 ${
                  isUser
                    ? 'bg-teal-700 text-white'
                    : 'bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 ring-1 ring-stone-200 dark:ring-stone-700'
                }`}
              >
                {isUser ? 'You' : <Bot className="w-3.5 h-3.5 text-teal-700 dark:text-teal-400" />}
              </div>

              <div className={`max-w-[85%] sm:max-w-[78%] flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
                <div
                  className={`p-3.5 sm:p-4 rounded-2xl text-xs ${
                    isUser
                      ? 'bg-teal-700 text-white rounded-tr-xs'
                      : 'bg-stone-50 dark:bg-stone-950 border border-stone-200/80 dark:border-stone-800 rounded-tl-xs shadow-2xs'
                  }`}
                >
                  {isUser ? (
                    <p className="whitespace-pre-wrap leading-relaxed">{msg.content}</p>
                  ) : (
                    <MarkdownRenderer content={msg.content} />
                  )}
                </div>

                <div className="flex items-center gap-2 mt-1 px-1 text-[10px] text-stone-400">
                  <span>{msg.timestamp}</span>
                  {!isUser && (
                    <>
                      <span>·</span>
                      <button
                        onClick={() => handleCopy(msg.content, msg.id)}
                        className="hover:text-stone-600 dark:hover:text-stone-200 flex items-center gap-1"
                      >
                        {copiedId === msg.id ? (
                          <>
                            <Check className="w-3 h-3 text-teal-600" />
                            <span className="text-teal-600">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy</span>
                          </>
                        )}
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {isLoading && (
          <div className="flex items-center justify-between p-3 rounded-2xl bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 text-xs text-stone-500">
            <div className="flex items-center gap-2">
              <div className="w-3.5 h-3.5 rounded-full border-2 border-teal-700 border-t-transparent animate-spin" />
              <span>Synthesizing live project metrics with Gemini...</span>
            </div>
            <button
              type="button"
              onClick={handleStopGenerating}
              className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg bg-stone-200 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-300 transition-colors"
            >
              <Square className="w-3 h-3 fill-current text-rose-500" />
              <span>Stop</span>
            </button>
          </div>
        )}

        {assistantError && (
          <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-800 dark:text-rose-200 flex items-center justify-between gap-3 animate-in fade-in">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{assistantError}</span>
            </div>
            {lastUserQuery && (
              <button
                type="button"
                onClick={() => handleSend(lastUserQuery)}
                disabled={isLoading}
                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-lg bg-rose-100 dark:bg-rose-900/60 text-rose-800 dark:text-rose-200 hover:bg-rose-200 transition-colors shrink-0"
              >
                <RotateCw className="w-3 h-3" />
                <span>Retry</span>
              </button>
            )}
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Question Chips */}
      <div className="px-4 py-2 border-t border-stone-100 dark:border-stone-800 bg-stone-50/40 dark:bg-stone-950/40">
        <p className="text-[10px] uppercase font-semibold tracking-wider text-stone-400 mb-1.5 flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-amber-500" />
          <span>Suggested Questions:</span>
        </p>
        <div className="flex flex-wrap gap-1.5 overflow-x-auto max-h-20">
          {questionChips.map((chip, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(chip)}
              className="text-[11px] px-2.5 py-1 rounded-lg bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-300 hover:border-teal-600 dark:hover:border-teal-500 hover:text-teal-800 dark:hover:text-teal-300 transition-colors shrink-0 shadow-2xs"
            >
              {chip}
            </button>
          ))}
        </div>
      </div>

      {/* Input Box */}
      <div className="p-3 sm:p-4 border-t border-stone-200/80 dark:border-stone-800/80 bg-white dark:bg-stone-900">
        <div className="relative rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 focus-within:ring-2 focus-within:ring-teal-700/20 focus-within:border-teal-700 flex items-center">
          <input
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Ask anything about your project..."
            className="w-full py-2.5 pl-3.5 pr-10 text-xs bg-transparent border-0 outline-none text-stone-900 dark:text-stone-100 placeholder:text-stone-400"
          />
          <button
            type="button"
            onClick={() => handleSend()}
            disabled={!inputQuery.trim() || isLoading}
            className="absolute right-2 p-1.5 rounded-lg bg-teal-700 hover:bg-teal-800 disabled:opacity-30 text-white transition-colors"
          >
            <Send className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

    </div>
  );
};
