import React from 'react';
import { useApp } from '../../store/AppContext';
import { Link } from 'react-router-dom';
import { Info, X } from 'lucide-react';

export const GuestBanner: React.FC = () => {
  const { isGuest, guestBannerDismissed, dismissGuestBanner } = useApp();

  if (!isGuest || guestBannerDismissed) return null;

  return (
    <div className="bg-amber-50 dark:bg-amber-950/70 border-b border-amber-200/80 dark:border-amber-800/80 text-amber-900 dark:text-amber-200 px-4 py-2.5 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <Info className="w-4 h-4 text-amber-700 dark:text-amber-400 shrink-0" />
          <span>
            <strong>You&apos;re in Guest mode.</strong> Your data will be cleared when you refresh.
          </span>
          <Link
            to="/welcome"
            className="underline font-semibold hover:text-amber-950 dark:hover:text-amber-100 ml-1 whitespace-nowrap"
          >
            Sign in to save your work &rarr;
          </Link>
        </div>
        <button
          onClick={dismissGuestBanner}
          className="p-1 text-amber-700 dark:text-amber-400 hover:text-amber-900 dark:hover:text-amber-200 transition-colors"
          aria-label="Dismiss guest notice"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
