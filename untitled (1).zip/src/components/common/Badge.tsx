import React from 'react';
import { PriorityLevel, TaskStatus } from '../../types/task';
import { ProjectHealthStatus } from '../../types/project';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'teal' | 'amber' | 'rose' | 'slate' | 'violet';
  size?: 'sm' | 'md';
  className?: string;
  dot?: boolean;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'default',
  size = 'md',
  className = '',
  dot = false,
}) => {
  const sizeClasses = {
    sm: 'text-[11px] px-2 py-0.5',
    md: 'text-xs px-2.5 py-1',
  };

  const variantClasses = {
    default: 'bg-stone-100 text-stone-700 dark:bg-stone-800 dark:text-stone-300 border border-stone-200 dark:border-stone-700',
    teal: 'bg-teal-50 text-teal-800 dark:bg-teal-950/60 dark:text-teal-300 border border-teal-200/60 dark:border-teal-800/60',
    amber: 'bg-amber-50 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200/60 dark:border-amber-800/60',
    rose: 'bg-rose-50 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-200/60 dark:border-rose-800/60',
    slate: 'bg-stone-100 text-stone-700 dark:bg-stone-800/80 dark:text-stone-300 border border-stone-200 dark:border-stone-700',
    violet: 'bg-indigo-50 text-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300 border border-indigo-200/60 dark:border-indigo-800/60',
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-medium rounded-md whitespace-nowrap shrink-0 transition-colors ${sizeClasses[size]} ${variantClasses[variant]} ${className}`}
    >
      {dot && (
        <span
          className={`w-1.5 h-1.5 rounded-full ${
            variant === 'teal'
              ? 'bg-teal-600 dark:bg-teal-400'
              : variant === 'amber'
              ? 'bg-amber-500 dark:bg-amber-400'
              : variant === 'rose'
              ? 'bg-rose-500 dark:bg-rose-400'
              : 'bg-stone-400'
          }`}
        />
      )}
      {children}
    </span>
  );
};

export const PriorityBadge: React.FC<{ priority: PriorityLevel; size?: 'sm' | 'md' }> = ({
  priority,
  size = 'sm',
}) => {
  switch (priority) {
    case 'Critical':
      return <Badge variant="rose" size={size} dot>{priority}</Badge>;
    case 'High':
      return <Badge variant="amber" size={size} dot>{priority}</Badge>;
    case 'Medium':
      return <Badge variant="teal" size={size}>{priority}</Badge>;
    case 'Low':
    default:
      return <Badge variant="slate" size={size}>{priority}</Badge>;
  }
};

export const StatusPill: React.FC<{ status: ProjectHealthStatus | TaskStatus | string; size?: 'sm' | 'md' }> = ({
  status,
  size = 'sm',
}) => {
  switch (status) {
    case 'On Track':
    case 'Done':
    case 'Resolved':
    case 'Approved':
      return <Badge variant="teal" size={size} dot>{status}</Badge>;
    case 'In Progress':
    case 'Review':
      return <Badge variant="violet" size={size} dot>{status}</Badge>;
    case 'At Risk':
    case 'Pending':
      return <Badge variant="amber" size={size} dot>{status}</Badge>;
    case 'Delayed':
    case 'Blocked':
    case 'Overdue':
    case 'Rejected':
      return <Badge variant="rose" size={size} dot>{status}</Badge>;
    case 'To Do':
    case 'Backlog':
    default:
      return <Badge variant="slate" size={size}>{status}</Badge>;
  }
};

export const ProvenanceBadge: React.FC<{ type: 'Manual' | 'Automatic' | 'AI-generated' | 'AI-suggested, unconfirmed' }> = ({
  type,
}) => {
  if (type === 'AI-suggested, unconfirmed') {
    return (
      <Badge variant="amber" size="sm" className="font-semibold text-[10px] tracking-wide uppercase">
        AI-suggested · unconfirmed
      </Badge>
    );
  }
  if (type === 'AI-generated') {
    return (
      <Badge variant="teal" size="sm" className="font-semibold text-[10px] tracking-wide uppercase">
        AI-generated
      </Badge>
    );
  }
  if (type === 'Automatic') {
    return (
      <Badge variant="default" size="sm" className="font-semibold text-[10px] tracking-wide uppercase">
        Auto-calculated
      </Badge>
    );
  }
  return (
    <Badge variant="slate" size="sm" className="font-semibold text-[10px] tracking-wide uppercase">
      Manual
    </Badge>
  );
};
