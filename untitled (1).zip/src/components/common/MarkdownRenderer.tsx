import React from 'react';

export const MarkdownRenderer: React.FC<{ content: string }> = ({ content }) => {
  // Simple, robust client-side markdown renderer for tables, headers, lists, bold, italics
  const lines = content.split('\n');
  const elements: React.ReactNode[] = [];
  let tableRows: string[][] = [];
  let inTable = false;

  const flushTable = (key: string) => {
    if (tableRows.length === 0) return null;
    const headerRow = tableRows[0];
    const bodyRows = tableRows.slice(1).filter((r) => !r.every((c) => c.match(/^[:\-\s]+$/)));

    const tableElement = (
      <div key={key} className="overflow-x-auto my-3 rounded-lg border border-stone-200 dark:border-stone-800">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-stone-100 dark:bg-stone-800/80 text-stone-700 dark:text-stone-200">
            <tr>
              {headerRow.map((cell, idx) => (
                <th key={idx} className="py-2 px-3 font-semibold border-b border-stone-200 dark:border-stone-700">
                  {renderInlineFormatting(cell.trim())}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100 dark:divide-stone-800">
            {bodyRows.map((row, rowIdx) => (
              <tr key={rowIdx} className="hover:bg-stone-50/50 dark:hover:bg-stone-800/40 transition-colors">
                {row.map((cell, colIdx) => (
                  <td key={colIdx} className="py-2 px-3 text-stone-600 dark:text-stone-300 align-top">
                    {renderInlineFormatting(cell.trim())}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
    tableRows = [];
    inTable = false;
    return tableElement;
  };

  const renderInlineFormatting = (text: string): React.ReactNode => {
    // Replace **bold**
    const parts = text.split(/(\*\*.*?\*\*|\*.*?\*|`.*?`)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-semibold text-stone-900 dark:text-stone-100">{part.slice(2, -2)}</strong>;
      }
      if (part.startsWith('*') && part.endsWith('*')) {
        return <em key={i} className="italic text-stone-700 dark:text-stone-300">{part.slice(1, -1)}</em>;
      }
      if (part.startsWith('`') && part.endsWith('`')) {
        return (
          <code key={i} className="px-1 py-0.5 rounded font-mono text-[11px] bg-stone-100 dark:bg-stone-800 text-teal-700 dark:text-teal-400">
            {part.slice(1, -1)}
          </code>
        );
      }
      return part;
    });
  };

  lines.forEach((line, index) => {
    const trimmed = line.trim();

    if (trimmed.startsWith('|') && trimmed.endsWith('|')) {
      inTable = true;
      const cells = trimmed
        .slice(1, -1)
        .split('|')
        .map((c) => c.trim());
      tableRows.push(cells);
      return;
    } else if (inTable) {
      const tableElem = flushTable(`table-${index}`);
      if (tableElem) elements.push(tableElem);
    }

    if (trimmed.startsWith('#### ')) {
      elements.push(
        <h4 key={index} className="text-xs font-bold text-stone-900 dark:text-stone-100 uppercase tracking-wider mt-4 mb-2">
          {renderInlineFormatting(trimmed.slice(5))}
        </h4>
      );
    } else if (trimmed.startsWith('### ')) {
      elements.push(
        <h3 key={index} className="text-sm font-bold text-teal-800 dark:text-teal-300 mt-4 mb-2">
          {renderInlineFormatting(trimmed.slice(4))}
        </h3>
      );
    } else if (trimmed.startsWith('## ')) {
      elements.push(
        <h2 key={index} className="text-base font-bold text-stone-900 dark:text-stone-50 mt-5 mb-2.5">
          {renderInlineFormatting(trimmed.slice(3))}
        </h2>
      );
    } else if (trimmed.startsWith('# ')) {
      elements.push(
        <h1 key={index} className="text-lg font-extrabold text-stone-900 dark:text-stone-50 mt-6 mb-3">
          {renderInlineFormatting(trimmed.slice(2))}
        </h1>
      );
    } else if (trimmed.startsWith('* ') || trimmed.startsWith('- ')) {
      elements.push(
        <li key={index} className="ml-4 list-disc text-xs text-stone-600 dark:text-stone-300 my-1 leading-relaxed">
          {renderInlineFormatting(trimmed.slice(2))}
        </li>
      );
    } else if (/^\d+\.\s/.test(trimmed)) {
      const match = trimmed.match(/^(\d+)\.\s(.*)$/);
      if (match) {
        elements.push(
          <div key={index} className="flex items-start gap-2 text-xs text-stone-600 dark:text-stone-300 my-1 leading-relaxed">
            <span className="font-semibold text-stone-800 dark:text-stone-200 shrink-0">{match[1]}.</span>
            <span>{renderInlineFormatting(match[2])}</span>
          </div>
        );
      }
    } else if (trimmed === '---') {
      elements.push(<hr key={index} className="my-4 border-stone-200 dark:border-stone-800" />);
    } else if (trimmed.length > 0) {
      elements.push(
        <p key={index} className="text-xs text-stone-600 dark:text-stone-300 my-2 leading-relaxed">
          {renderInlineFormatting(trimmed)}
        </p>
      );
    }
  });

  if (inTable) {
    const tableElem = flushTable('table-end');
    if (tableElem) elements.push(tableElem);
  }

  return <div className="space-y-0.5 text-xs">{elements}</div>;
};
