import React from 'react';

interface LogoProps {
  className?: string;
  iconOnly?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export const Logo: React.FC<LogoProps> = ({ className = '', iconOnly = false, size = 'md' }) => {
  const sizeMap = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-11 h-11',
  };

  const textMap = {
    sm: 'text-base font-bold',
    md: 'text-lg font-bold tracking-tight',
    lg: 'text-2xl font-extrabold tracking-tight',
  };

  return (
    <div className={`flex items-center gap-2.5 select-none ${className}`}>
      {/* Original Geometric SVG Mark */}
      <div className={`relative ${sizeMap[size]} shrink-0 rounded-xl bg-gradient-to-br from-teal-700 via-teal-800 to-stone-900 p-1.5 shadow-sm ring-1 ring-white/20 dark:ring-stone-700 flex items-center justify-center`}>
        <svg
          viewBox="0 0 32 32"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full text-white"
        >
          {/* Hexagon/Diamond lattice representing Agile iterations & Intelligence */}
          <path
            d="M16 3L27 9.5V22.5L16 29L5 22.5V9.5L16 3Z"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="opacity-40"
          />
          <path
            d="M16 8L23 12V20L16 24L9 20V12L16 8Z"
            fill="currentColor"
            fillOpacity="0.15"
            stroke="currentColor"
            strokeWidth="2"
          />
          {/* Dynamic Amber node indicating active sprint focus */}
          <circle cx="16" cy="16" r="3.2" className="fill-amber-400" />
          <path
            d="M16 12.8V10M16 22V19.2M13.2 14.4L11 13M21 19L18.8 17.6"
            stroke="#fbbf24"
            strokeWidth="1.5"
            strokeLinecap="round"
          />
        </svg>
      </div>

      {!iconOnly && (
        <div className="flex flex-col">
          <span className={`text-stone-900 dark:text-stone-100 ${textMap[size]} font-sans leading-tight`}>
            Agile<span className="text-teal-700 dark:text-teal-400">Mind</span>
          </span>
          <span className="text-[10px] uppercase font-semibold tracking-wider text-stone-500 dark:text-stone-400">
            Requirements &amp; PM
          </span>
        </div>
      )}
    </div>
  );
};
