export interface StatusReportData {
  generatedAt: string;
  projectName: string;
  projectManager: string;
  activeSprintName: string;
  overallHealth: string;
  completionRate: number;
  completedTasksCount: number;
  inProgressTasksCount: number;
  delayedTasksCount: number;
  blockedTasksCount: number;
  openRisksCount: number;
  pendingDecisionsCount: number;
  keyAchievements: string[];
  inProgressHighlights: string[];
  delayedItems: string[];
  topRisks: string[];
  criticalBlockers: string[];
  keyDependencies: string[];
  clientAttentionItems: string[];
  recommendedNextSteps: string[];
  markdownContent: string;
}

export type ReportType = 
  | 'Project Status Report' 
  | 'Sprint Summary' 
  | 'Task Progress Report' 
  | 'Risks & Dependencies Report';
