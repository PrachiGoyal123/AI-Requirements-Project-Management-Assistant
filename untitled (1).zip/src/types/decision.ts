export type DecisionStatus = 'Pending' | 'Approved' | 'Rejected' | 'Overdue';

export interface DecisionItem {
  id: string; // e.g. "DEC-01"
  projectId: string;
  item: string; // Title / brief summary
  description: string;
  owner: string;
  requestedFrom: string; // e.g. "Client Product Owner" or "Security Compliance Team"
  dueDate: string;
  status: DecisionStatus;
  urgency: 'Low' | 'Medium' | 'High';
  scheduleImpactDays?: number;
  aiImpactAssessment?: string;
  draftFollowUpMessage?: string;
  createdAt: string;
}
