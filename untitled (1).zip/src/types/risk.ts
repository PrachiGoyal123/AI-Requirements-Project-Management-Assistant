export type RiskImpact = 'Low' | 'Medium' | 'High' | 'Critical';
export type RiskProbability = 'Low' | 'Medium' | 'High';
export type RiskStatus = 'Open' | 'Mitigated' | 'Closed' | 'Accepted';

export interface Risk {
  id: string; // e.g. "RSK-01"
  projectId: string;
  title: string;
  description: string;
  impact: RiskImpact;
  probability: RiskProbability;
  status: RiskStatus;
  mitigationPlan: string;
  owner: string;
  isAiSuggested?: boolean;
  confirmed?: boolean;
  createdAt: string;
}

export type DependencyStatus = 'Pending' | 'In Progress' | 'Resolved' | 'Blocked';

export interface Dependency {
  id: string;
  projectId: string;
  title: string; // e.g. "UAT depends on Development Completion"
  sourceItem: string;
  dependentItem: string;
  owner: string;
  dueDate: string;
  status: DependencyStatus;
  impactNote?: string;
  createdAt: string;
}
