export type SprintStatus = 'Planned' | 'Active' | 'Completed';

export interface RetroItem {
  id: string;
  text: string;
  author?: string;
  votes: number;
}

export interface SprintRetrospective {
  id: string;
  sprintId: string;
  projectId: string;
  whatWentWell: RetroItem[];
  whatDidntGoWell: RetroItem[];
  whatToImprove: RetroItem[];
  actionItems: string[];
  savedAt?: string;
}

export interface Sprint {
  id: string;
  name: string;
  goal: string;
  startDate: string;
  endDate: string;
  status: SprintStatus;
  projectId: string;
  storyIds: string[];
  totalPoints?: number;
  completedPoints?: number;
  outcomeNotes?: string;
  createdAt: string;
}
