export type TaskStatus = 'To Do' | 'In Progress' | 'Review' | 'Done';
export type PriorityLevel = 'Low' | 'Medium' | 'High' | 'Critical';

export interface Task {
  id: string; // e.g. T-101
  title: string;
  description: string;
  status: TaskStatus;
  priority: PriorityLevel;
  assigneeName: string;
  assigneeInitials: string;
  assigneeEmail?: string;
  dueDate: string;
  storyId?: string; // links to UserStory id, e.g. "US-001"
  projectId: string;
  sprintId?: string; // links to Sprint id
  isBlocked?: boolean;
  blockedReason?: string;
  estimatedHours?: number;
  completedHours?: number;
  taskNumber?: number;
  displayNumber?: string;
  order: number;
  isAiSuggested?: boolean;
  confirmed?: boolean;
  createdAt: string;
}
