export type ProjectType = 
  | 'Agile Scrum'
  | 'Kanban Delivery'
  | 'Product Discovery'
  | 'Enterprise Migration'
  | 'MVP Launch';

export type ProjectHealthStatus = 'On Track' | 'At Risk' | 'Delayed';

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: string;
  avatarInitials: string;
}

export interface ProjectDocument {
  id: string;
  name: string;
  size: string;
  uploadedAt: string;
  type: string;
  filePath?: string;
  fileSize?: number;
  mimeType?: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  goal: string;
  startDate: string;
  endDate: string;
  projectType: ProjectType;
  projectManager: string;
  teamMembers: TeamMember[];
  documents: ProjectDocument[];
  status: ProjectHealthStatus; // auto-calculated or manual override
  createdAt: string;
  updatedAt: string;
  isArchived?: boolean;
}
