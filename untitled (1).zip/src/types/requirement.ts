export interface FileAttachment {
  id: string;
  name: string;
  size: number;
  type: string;
  path?: string; // Supabase storage path: {user_id}/chat/{chat_id}/{timestamp}-{sanitized_file_name}
  previewUrl?: string;
  extractedTextSnippet?: string;
  uploading?: boolean;
  uploadError?: string;
  file?: File;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  content: string;
  timestamp: string;
  attachments?: FileAttachment[];
  isStreaming?: boolean;
  error?: string;
  failedPrompt?: string;
  metadata?: {
    type?: 'summary' | 'analysis' | 'task_generation' | 'general';
    requirementsCount?: number;
    openQuestionsCount?: number;
  };
}

export interface ChatSession {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  messages: ChatMessage[];
  projectId?: string;
}
