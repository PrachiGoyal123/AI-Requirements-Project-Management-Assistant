import { PriorityLevel } from './task';

export type StoryStatus = 'Backlog' | 'In Sprint' | 'Completed' | 'Deferred';

export interface AcceptanceCriterion {
  id: string;
  text: string;
  completed: boolean;
}

export interface UserStory {
  id: string; // e.g. "US-001"
  title: string;
  description: string;
  priority: PriorityLevel;
  storyPoints: number;
  status: StoryStatus;
  acceptanceCriteria: AcceptanceCriterion[];
  projectId: string;
  sprintId?: string;
  relatedRequirement?: string;
  storyNumber?: number;
  displayNumber?: string;
  isAiGenerated?: boolean;
  createdAt: string;
  updatedAt: string;
}
