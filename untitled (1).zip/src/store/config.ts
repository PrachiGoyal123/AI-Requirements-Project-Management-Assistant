/**
 * Single Configuration Flag
 * 
 * When false: all project data, chat history, and changes reset on page refresh.
 * When true: client mock state is stored and retrieved from browser localStorage.
 */
export const PERSIST_MOCK_DATA = false;

export const APP_NAME = "AI Requirements & Project Management Assistant";
export const APP_SHORT_NAME = "AgileMind";
export const APP_VERSION = "1.0.0-frontend";
