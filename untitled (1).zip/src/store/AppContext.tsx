import React, { createContext, useContext, useState, useEffect, ReactNode, useMemo, useRef } from 'react';
import { User } from '../types/auth';
import { Project, ProjectHealthStatus, ProjectDocument } from '../types/project';
import { Sprint, SprintRetrospective } from '../types/sprint';
import { validateFile, formatFileSize } from '../lib/fileValidation';
import { UserStory, StoryStatus } from '../types/backlog';
import { Task, TaskStatus } from '../types/task';
import { Risk, Dependency } from '../types/risk';
import { DecisionItem } from '../types/decision';
import { ChatSession, ChatMessage } from '../types/requirement';
import {
  INITIAL_PROJECTS,
  INITIAL_SPRINTS,
  INITIAL_USER_STORIES,
  INITIAL_TASKS,
  INITIAL_RISKS,
  INITIAL_DEPENDENCIES,
  INITIAL_DECISIONS,
  INITIAL_RETROSPECTIVES,
  INITIAL_REQUIREMENT_CHATS,
} from './initialData';
import { authService } from '../services/authService';
import { supabaseService, formatStoryNumber, formatTaskNumber } from '../services/supabaseService';
import { isSupabaseConfigured } from '../lib/supabaseClient';

export interface Toast {
  id: string;
  title: string;
  message?: string;
  type: 'success' | 'error' | 'info' | 'warning';
}

interface AppContextType {
  // Auth & Session
  user: User | null;
  isGuest: boolean;
  isLoadingAuth: boolean;
  isLoadingData: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, name?: string) => Promise<{ requiresEmailConfirmation: boolean }>;
  signInWithGoogle: () => Promise<void>;
  continueAsGuest: () => void;
  logout: () => void;
  guestBannerDismissed: boolean;
  dismissGuestBanner: () => void;

  // Theme
  theme: 'light' | 'dark';
  toggleTheme: () => void;

  // Toast
  toasts: Toast[];
  addToast: (toast: Omit<Toast, 'id'>) => void;
  removeToast: (id: string) => void;

  // Projects
  projects: Project[];
  currentProjectId: string;
  currentProject: Project | undefined;
  setCurrentProjectId: (id: string) => void;
  createProject: (project: Omit<Project, 'id' | 'createdAt' | 'updatedAt' | 'status'>) => Project;
  updateProject: (id: string, updates: Partial<Project>) => void;
  archiveProject: (id: string) => void;
  deleteProject: (id: string) => void;
  addProjectDocument: (projectId: string, file: File) => Promise<ProjectDocument>;
  deleteProjectDocument: (projectId: string, docId: string, filePath?: string) => Promise<void>;

  // Sprints
  sprints: Sprint[];
  currentSprint: Sprint | undefined;
  projectSprints: Sprint[];
  createSprint: (sprint: Omit<Sprint, 'id' | 'createdAt'>) => Sprint;
  updateSprint: (id: string, updates: Partial<Sprint>) => void;
  startSprint: (sprintId: string) => boolean;
  completeSprint: (sprintId: string, outcomeNotes?: string) => void;
  addStoriesToSprint: (sprintId: string, storyIds: string[]) => void;
  removeStoryFromSprint: (storyId: string) => void;

  // Stories
  stories: UserStory[];
  projectStories: UserStory[];
  createStory: (story: Omit<UserStory, 'id' | 'createdAt' | 'updatedAt'>) => UserStory;
  updateStory: (id: string, updates: Partial<UserStory>) => void;
  deleteStory: (id: string) => void;

  // Tasks
  tasks: Task[];
  projectTasks: Task[];
  currentSprintTasks: Task[];
  createTask: (task: Omit<Task, 'id' | 'createdAt' | 'order'>) => Task;
  updateTask: (id: string, updates: Partial<Task>) => void;
  moveTask: (taskId: string, newStatus: TaskStatus, newIndex?: number) => void;
  deleteTask: (id: string) => void;

  // Risks & Dependencies
  risks: Risk[];
  projectRisks: Risk[];
  createRisk: (risk: Omit<Risk, 'id' | 'createdAt'>) => Risk;
  updateRisk: (id: string, updates: Partial<Risk>) => void;
  confirmRisk: (id: string) => void;
  deleteRisk: (id: string) => void;

  dependencies: Dependency[];
  projectDependencies: Dependency[];
  createDependency: (dep: Omit<Dependency, 'id' | 'createdAt'>) => Dependency;
  updateDependency: (id: string, updates: Partial<Dependency>) => void;
  deleteDependency: (id: string) => void;

  // Decisions
  decisions: DecisionItem[];
  projectDecisions: DecisionItem[];
  createDecision: (dec: Omit<DecisionItem, 'id' | 'createdAt'>) => DecisionItem;
  updateDecision: (id: string, updates: Partial<DecisionItem>) => void;
  deleteDecision: (id: string) => void;

  // Retrospectives
  retrospectives: SprintRetrospective[];
  projectRetrospectives: SprintRetrospective[];
  saveRetrospective: (retro: Omit<SprintRetrospective, 'id' | 'savedAt'>) => SprintRetrospective;

  // Requirement Chats
  requirementChats: ChatSession[];
  activeChatId: string | null;
  activeChat: ChatSession | undefined;
  setActiveChatId: (id: string | null) => void;
  createRequirementChat: (initialTitle?: string) => ChatSession;
  renameRequirementChat: (id: string, newTitle: string) => void;
  deleteRequirementChat: (id: string) => void;
  addMessageToChat: (chatId: string, message: Omit<ChatMessage, 'id'>) => string;
  updateChatMessage: (
    chatId: string,
    messageId: string,
    content: string,
    isStreaming?: boolean,
    error?: string,
    failedPrompt?: string
  ) => void;
  deleteChatMessage: (chatId: string, messageId: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Theme state
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('agilemind_theme');
      if (saved === 'dark' || saved === 'light') return saved;
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    }
    return 'light';
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('agilemind_theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  // Auth state
  const [user, setUser] = useState<User | null>(null);
  const [isLoadingAuth, setIsLoadingAuth] = useState<boolean>(true);
  const [isLoadingData, setIsLoadingData] = useState<boolean>(false);
  const [guestBannerDismissed, setGuestBannerDismissed] = useState<boolean>(false);

  // Entities state
  const [projects, setProjects] = useState<Project[]>([]);
  const [currentProjectId, setCurrentProjectId] = useState<string>('');
  const [sprints, setSprints] = useState<Sprint[]>([]);
  const [stories, setStories] = useState<UserStory[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [risks, setRisks] = useState<Risk[]>([]);
  const [dependencies, setDependencies] = useState<Dependency[]>([]);
  const [decisions, setDecisions] = useState<DecisionItem[]>([]);
  const [retrospectives, setRetrospectives] = useState<SprintRetrospective[]>([]);
  const [requirementChats, setRequirementChats] = useState<ChatSession[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);

  // Ref to track latest state for optimistic rollback
  const tasksRef = useRef(tasks);
  tasksRef.current = tasks;
  const sprintsRef = useRef(sprints);
  sprintsRef.current = sprints;

  // Toasts
  const [toasts, setToasts] = useState<Toast[]>([]);

  const addToast = (toast: Omit<Toast, 'id'>) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newToast: Toast = { ...toast, id };
    setToasts((prev) => [...prev, newToast]);
    setTimeout(() => {
      removeToast(id);
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Check Supabase configuration on mount
  useEffect(() => {
    if (!isSupabaseConfigured) {
      addToast({
        title: 'Supabase Not Configured',
        message: 'VITE_SUPABASE_URL and VITE_SUPABASE_PUBLISHABLE_KEY are required.',
        type: 'error',
      });
    }
  }, []);

  // Initialize Auth Session
  useEffect(() => {
    let mounted = true;

    async function initSession() {
      try {
        const sessionUser = await authService.getSession();
        if (mounted && sessionUser) {
          setUser(sessionUser);
        }
      } catch (err) {
        console.warn('Error reading initial auth session:', err);
      } finally {
        if (mounted) {
          setIsLoadingAuth(false);
        }
      }
    }

    initSession();

    const subscription = authService.onAuthStateChange((sbUser) => {
      if (mounted) {
        setUser((prev) => {
          // Keep guest user if continuing as guest
          if (prev?.isGuest && !sbUser) return prev;
          return sbUser;
        });
      }
    });

    return () => {
      mounted = false;
      subscription?.unsubscribe();
    };
  }, []);

  // Load Data: Supabase (when logged in) vs In-Memory (Guest)
  useEffect(() => {
    if (!user) {
      // Clear data when logged out
      setProjects([]);
      setSprints([]);
      setStories([]);
      setTasks([]);
      setRisks([]);
      setDependencies([]);
      setDecisions([]);
      setRetrospectives([]);
      setRequirementChats([]);
      setCurrentProjectId('');
      setActiveChatId(null);
      return;
    }

    if (user.isGuest) {
      // Guest mode: load in-memory mock data (clears on page refresh)
      setProjects(INITIAL_PROJECTS);
      setCurrentProjectId(INITIAL_PROJECTS[0]?.id || '');
      setSprints(INITIAL_SPRINTS);
      setStories(INITIAL_USER_STORIES);
      setTasks(INITIAL_TASKS);
      setRisks(INITIAL_RISKS);
      setDependencies(INITIAL_DEPENDENCIES);
      setDecisions(INITIAL_DECISIONS);
      setRetrospectives(INITIAL_RETROSPECTIVES);
      setRequirementChats(INITIAL_REQUIREMENT_CHATS);
      setActiveChatId(INITIAL_REQUIREMENT_CHATS[0]?.id || null);
      return;
    }

    // Authenticated user: fetch from Supabase
    let isCancelled = false;
    async function loadSupabaseData() {
      setIsLoadingData(true);
      try {
        const [
          dbProjects,
          dbSprints,
          dbStories,
          dbTasks,
          dbRisks,
          dbDeps,
          dbDecisions,
          dbRetros,
          dbChats,
        ] = await Promise.all([
          supabaseService.fetchProjects(),
          supabaseService.fetchSprints(),
          supabaseService.fetchUserStories(),
          supabaseService.fetchTasks(),
          supabaseService.fetchRisks(),
          supabaseService.fetchDependencies(),
          supabaseService.fetchDecisions(),
          supabaseService.fetchRetrospectives(),
          supabaseService.fetchChats(),
        ]);

        if (isCancelled) return;

        setProjects(dbProjects);
        setSprints(dbSprints);
        setStories(dbStories);
        setTasks(dbTasks);
        setRisks(dbRisks);
        setDependencies(dbDeps);
        setDecisions(dbDecisions);
        setRetrospectives(dbRetros);
        setRequirementChats(dbChats);

        if (dbProjects.length > 0) {
          setCurrentProjectId(dbProjects[0].id);
        }
        if (dbChats.length > 0) {
          setActiveChatId(dbChats[0].id);
        }
      } catch (err: any) {
        console.error('Failed to load Supabase workspace data:', err);
        addToast({
          title: 'Database Sync Error',
          message: err.message || 'Could not load your workspace data from Supabase.',
          type: 'error',
        });
      } finally {
        if (!isCancelled) {
          setIsLoadingData(false);
        }
      }
    }

    loadSupabaseData();

    return () => {
      isCancelled = true;
    };
  }, [user?.id, user?.isGuest]);

  // Derived filtered items for the current project
  const currentProject = useMemo(() => {
    return projects.find((p) => p.id === currentProjectId) || projects[0];
  }, [projects, currentProjectId]);

  const projectSprints = useMemo(() => {
    return sprints.filter((s) => s.projectId === currentProjectId);
  }, [sprints, currentProjectId]);

  const currentSprint = useMemo(() => {
    return projectSprints.find((s) => s.status === 'Active') || projectSprints[0];
  }, [projectSprints]);

  const projectStories = useMemo(() => {
    return stories.filter((s) => s.projectId === currentProjectId);
  }, [stories, currentProjectId]);

  const projectTasks = useMemo(() => {
    return tasks.filter((t) => t.projectId === currentProjectId);
  }, [tasks, currentProjectId]);

  const currentSprintTasks = useMemo(() => {
    if (!currentSprint) return [];
    return projectTasks.filter((t) => t.sprintId === currentSprint.id);
  }, [projectTasks, currentSprint]);

  const projectRisks = useMemo(() => {
    return risks.filter((r) => r.projectId === currentProjectId);
  }, [risks, currentProjectId]);

  const projectDependencies = useMemo(() => {
    return dependencies.filter((d) => d.projectId === currentProjectId);
  }, [dependencies, currentProjectId]);

  const projectDecisions = useMemo(() => {
    return decisions.filter((d) => d.projectId === currentProjectId);
  }, [decisions, currentProjectId]);

  const projectRetrospectives = useMemo(() => {
    return retrospectives.filter((r) => r.projectId === currentProjectId);
  }, [retrospectives, currentProjectId]);

  const activeChat = useMemo(() => {
    return requirementChats.find((c) => c.id === activeChatId) || requirementChats[0];
  }, [requirementChats, activeChatId]);

  // Dynamic project health calculation based on actual tasks & risks
  useEffect(() => {
    if (!currentProjectId) return;
    const projectTs = tasks.filter((t) => t.projectId === currentProjectId);
    const projectRs = risks.filter((r) => r.projectId === currentProjectId);
    const now = Date.now();

    const delayedCount = projectTs.filter(
      (t) => t.status !== 'Done' && new Date(t.dueDate).getTime() < now
    ).length;
    const blockedCount = projectTs.filter((t) => t.isBlocked).length;
    const hasCriticalRisk = projectRs.some((r) => r.status === 'Open' && r.impact === 'Critical');

    let calculatedStatus: ProjectHealthStatus = 'On Track';
    if (delayedCount > 2 || blockedCount > 1 || hasCriticalRisk) {
      calculatedStatus = 'At Risk';
    }
    if (delayedCount > 4 || blockedCount >= 3) {
      calculatedStatus = 'Delayed';
    }

    setProjects((prev) =>
      prev.map((p) => (p.id === currentProjectId && p.status !== calculatedStatus ? { ...p, status: calculatedStatus } : p))
    );
  }, [tasks, risks, currentProjectId]);

  // ==========================================
  // AUTH HANDLERS
  // ==========================================
  const signIn = async (email: string, pass: string) => {
    const loggedIn = await authService.signInWithEmail(email, pass);
    setUser(loggedIn);
    addToast({ title: 'Welcome back!', message: `Signed in as ${loggedIn.name}`, type: 'success' });
  };

  const register = async (email: string, pass: string, name?: string) => {
    const { user: newUser, requiresEmailConfirmation } = await authService.registerWithEmail(email, pass, name);
    if (newUser) {
      setUser(newUser);
      addToast({ title: 'Account created!', message: `Welcome to AgileMind, ${newUser.name}`, type: 'success' });
    }
    return { requiresEmailConfirmation };
  };

  const signInWithGoogle = async () => {
    await authService.signInWithGoogle();
  };

  const continueAsGuest = () => {
    const guest = authService.createGuestUser();
    setUser(guest);
    addToast({
      title: 'Continuing as Guest',
      message: 'Workspace data will reset on page reload.',
      type: 'info',
    });
  };

  const logout = async () => {
    await authService.signOut();
    setUser(null);
    addToast({ title: 'Logged out', message: 'You have returned to the welcome screen.', type: 'info' });
  };

  const dismissGuestBanner = () => {
    setGuestBannerDismissed(true);
  };

  // ==========================================
  // PROJECT CRUD
  // ==========================================
  const createProject = (data: Omit<Project, 'id' | 'createdAt' | 'updatedAt' | 'status'>): Project => {
    const newId = crypto.randomUUID();
    const newProj: Project = {
      ...data,
      id: newId,
      status: 'On Track',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setProjects((prev) => [newProj, ...prev]);
    setCurrentProjectId(newProj.id);
    addToast({ title: 'Project Created', message: `${newProj.name} is ready.`, type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.createProject(data).then((saved) => {
        setProjects((prev) => prev.map((p) => (p.id === newId ? saved : p)));
        setCurrentProjectId(saved.id);
      }).catch((err) => {
        console.error('Failed to save project to Supabase:', err);
        setProjects((prev) => prev.filter((p) => p.id !== newId));
        addToast({ title: 'Failed to create project', message: err.message, type: 'error' });
      });
    }

    return newProj;
  };

  const updateProject = (id: string, updates: Partial<Project>) => {
    setProjects((prev) =>
      prev.map((p) => (p.id === id ? { ...p, ...updates, updatedAt: new Date().toISOString() } : p))
    );
    addToast({ title: 'Project Updated', type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.updateProject(id, updates).catch((err) => {
        console.error('Failed to update project in Supabase:', err);
        addToast({ title: 'Sync Error', message: err.message, type: 'error' });
      });
    }
  };

  const archiveProject = (id: string) => {
    const target = projects.find((p) => p.id === id);
    const newArchived = !target?.isArchived;

    setProjects((prev) =>
      prev.map((p) => (p.id === id ? { ...p, isArchived: newArchived } : p))
    );
    addToast({ title: 'Project Archive State Changed', type: 'info' });

    if (user && !user.isGuest) {
      supabaseService.updateProject(id, { isArchived: newArchived }).catch((err) => {
        console.error('Failed to archive project in Supabase:', err);
        setProjects((prev) => prev.map((p) => (p.id === id ? { ...p, isArchived: !newArchived } : p)));
        addToast({ title: 'Sync Error', message: err.message, type: 'error' });
      });
    }
  };

  const deleteProject = (id: string) => {
    const prevProjects = projects;
    setProjects((prev) => prev.filter((p) => p.id !== id));
    if (currentProjectId === id) {
      const remaining = projects.filter((p) => p.id !== id);
      if (remaining.length > 0) {
        setCurrentProjectId(remaining[0].id);
      }
    }
    addToast({ title: 'Project Deleted', type: 'info' });

    if (user && !user.isGuest) {
      supabaseService.deleteProject(id).catch((err) => {
        console.error('Failed to delete project in Supabase:', err);
        setProjects(prevProjects);
        addToast({ title: 'Failed to delete project', message: err.message, type: 'error' });
      });
    }
  };

  const addProjectDocument = async (projectId: string, file: File): Promise<ProjectDocument> => {
    if (user && !user.isGuest) {
      const savedDoc = await supabaseService.uploadProjectDocument(projectId, file);
      setProjects((prev) =>
        prev.map((p) =>
          p.id === projectId
            ? { ...p, documents: [savedDoc, ...p.documents] }
            : p
        )
      );
      addToast({ title: 'Document Uploaded', message: savedDoc.name, type: 'success' });
      return savedDoc;
    } else {
      // Guest mode: in-memory only, no Supabase calls
      const validation = validateFile(file);
      if (!validation.valid) {
        throw new Error(validation.error);
      }
      const localDoc: ProjectDocument = {
        id: `doc-${Date.now().toString(36)}`,
        name: file.name,
        size: formatFileSize(file.size),
        uploadedAt: new Date().toISOString().split('T')[0],
        type: file.type || 'document',
        fileSize: file.size,
        mimeType: file.type,
      };
      setProjects((prev) =>
        prev.map((p) =>
          p.id === projectId
            ? { ...p, documents: [localDoc, ...p.documents] }
            : p
        )
      );
      addToast({ title: 'Document Added (Guest Mode)', message: localDoc.name, type: 'info' });
      return localDoc;
    }
  };

  const deleteProjectDocument = async (projectId: string, docId: string, filePath?: string): Promise<void> => {
    const targetProject = projects.find((p) => p.id === projectId);
    const prevDocs = targetProject?.documents || [];

    setProjects((prev) =>
      prev.map((p) =>
        p.id === projectId
          ? { ...p, documents: p.documents.filter((d) => d.id !== docId) }
          : p
      )
    );
    addToast({ title: 'Document Removed', type: 'info' });

    if (user && !user.isGuest) {
      try {
        await supabaseService.deleteProjectDocument(docId, filePath);
      } catch (err: any) {
        console.error('Failed to delete document:', err);
        setProjects((prev) =>
          prev.map((p) => (p.id === projectId ? { ...p, documents: prevDocs } : p))
        );
        addToast({ title: 'Error deleting document', message: err.message, type: 'error' });
        throw err;
      }
    }
  };

  // ==========================================
  // SPRINT CRUD
  // ==========================================
  const createSprint = (data: Omit<Sprint, 'id' | 'createdAt'>): Sprint => {
    const tempId = crypto.randomUUID();
    const newSprint: Sprint = {
      ...data,
      id: tempId,
      createdAt: new Date().toISOString(),
    };

    setSprints((prev) => [...prev, newSprint]);
    addToast({ title: 'Sprint Created', message: `${newSprint.name} planned.`, type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.createSprint(data).then((saved) => {
        setSprints((prev) => prev.map((s) => (s.id === tempId ? saved : s)));
      }).catch((err) => {
        console.error('Failed to create sprint in Supabase:', err);
        setSprints((prev) => prev.filter((s) => s.id !== tempId));
        addToast({
          title: 'Sprint Creation Failed',
          message: err.message.includes('already active')
            ? 'Another sprint is already active in this project.'
            : err.message,
          type: 'error',
        });
      });
    }

    return newSprint;
  };

  const updateSprint = (id: string, updates: Partial<Sprint>) => {
    const prevSprints = sprintsRef.current;
    setSprints((prev) => prev.map((s) => (s.id === id ? { ...s, ...updates } : s)));
    addToast({ title: 'Sprint Updated', type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.updateSprint(id, updates).catch((err) => {
        console.error('Failed to update sprint in Supabase:', err);
        setSprints(prevSprints);
        addToast({
          title: 'Sprint Update Failed',
          message: err.message.includes('already active')
            ? 'Another sprint is already active in this project.'
            : err.message,
          type: 'error',
        });
      });
    }
  };

  const startSprint = (sprintId: string): boolean => {
    const target = sprints.find((s) => s.id === sprintId);
    if (!target) return false;

    // Check if another sprint is currently active for this project
    const activeExisting = sprints.find(
      (s) => s.projectId === target.projectId && s.status === 'Active' && s.id !== sprintId
    );
    if (activeExisting) {
      addToast({
        title: 'Active Sprint in Progress',
        message: 'Another sprint is already active in this project.',
        type: 'warning',
      });
      return false;
    }

    const prevSprints = sprintsRef.current;
    setSprints((prev) =>
      prev.map((s) => (s.id === sprintId ? { ...s, status: 'Active' } : s))
    );
    addToast({ title: 'Sprint Started!', message: `${target.name} is now active.`, type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.updateSprint(sprintId, { status: 'Active' }).catch((err) => {
        console.error('Failed to activate sprint in Supabase:', err);
        setSprints(prevSprints);
        addToast({
          title: 'Activation Failed',
          message: 'Another sprint is already active in this project.',
          type: 'error',
        });
      });
    }

    return true;
  };

  const completeSprint = (sprintId: string, outcomeNotes?: string) => {
    const prevSprints = sprintsRef.current;
    setSprints((prev) =>
      prev.map((s) => (s.id === sprintId ? { ...s, status: 'Completed', outcomeNotes } : s))
    );
    addToast({ title: 'Sprint Completed', message: 'You can now review or run a retrospective.', type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.updateSprint(sprintId, { status: 'Completed', outcomeNotes }).catch((err) => {
        console.error('Failed to complete sprint in Supabase:', err);
        setSprints(prevSprints);
        addToast({ title: 'Sync Error', message: err.message, type: 'error' });
      });
    }
  };

  const addStoriesToSprint = (sprintId: string, storyIds: string[]) => {
    setStories((prev) =>
      prev.map((st) => (storyIds.includes(st.id) ? { ...st, sprintId, status: 'In Sprint' } : st))
    );
    setSprints((prev) =>
      prev.map((sp) => {
        if (sp.id !== sprintId) return sp;
        const currentIds = new Set(sp.storyIds);
        storyIds.forEach((id) => currentIds.add(id));
        return { ...sp, storyIds: Array.from(currentIds) };
      })
    );
    addToast({ title: 'Stories Added to Sprint', message: `${storyIds.length} user story(s) added.`, type: 'success' });

    if (user && !user.isGuest) {
      storyIds.forEach((id) => {
        supabaseService.updateUserStory(id, { sprintId, status: 'In Sprint' as StoryStatus }).catch((err) => {
          console.warn('Failed to assign story to sprint in Supabase:', err);
        });
      });
    }
  };

  const removeStoryFromSprint = (storyId: string) => {
    setStories((prev) =>
      prev.map((st) => (st.id === storyId ? { ...st, sprintId: undefined, status: 'Backlog' } : st))
    );
    setSprints((prev) =>
      prev.map((sp) => ({
        ...sp,
        storyIds: sp.storyIds.filter((id) => id !== storyId),
      }))
    );
    addToast({ title: 'Story Moved to Backlog', type: 'info' });

    if (user && !user.isGuest) {
      supabaseService.updateUserStory(storyId, { sprintId: undefined, status: 'Backlog' }).catch((err) => {
        console.warn('Failed to decouple story from sprint in Supabase:', err);
      });
    }
  };

  // ==========================================
  // STORY CRUD
  // ==========================================
  const createStory = (data: Omit<UserStory, 'id' | 'createdAt' | 'updatedAt'>): UserStory => {
    const tempId = crypto.randomUUID();
    const existingNums = stories
      .map((s) => s.storyNumber || 0)
      .filter((n) => !isNaN(n));
    const nextNum = existingNums.length > 0 ? Math.max(...existingNums) + 1 : 1;

    const newStory: UserStory = {
      ...data,
      id: tempId,
      storyNumber: nextNum,
      displayNumber: formatStoryNumber(nextNum),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setStories((prev) => [...prev, newStory]);
    addToast({ title: 'User Story Created', message: `${newStory.displayNumber}: ${newStory.title}`, type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.createUserStory(data).then((saved) => {
        setStories((prev) => prev.map((s) => (s.id === tempId ? saved : s)));
      }).catch((err) => {
        console.error('Failed to create story in Supabase:', err);
        setStories((prev) => prev.filter((s) => s.id !== tempId));
        addToast({ title: 'Failed to create story', message: err.message, type: 'error' });
      });
    }

    return newStory;
  };

  const updateStory = (id: string, updates: Partial<UserStory>) => {
    setStories((prev) =>
      prev.map((s) => (s.id === id ? { ...s, ...updates, updatedAt: new Date().toISOString() } : s))
    );
    addToast({ title: 'User Story Saved', type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.updateUserStory(id, updates).catch((err) => {
        console.error('Failed to update story in Supabase:', err);
        addToast({ title: 'Sync Error', message: err.message, type: 'error' });
      });
    }
  };

  const deleteStory = (id: string) => {
    const prevStories = stories;
    setStories((prev) => prev.filter((s) => s.id !== id));
    setTasks((prev) => prev.filter((t) => t.storyId !== id));
    addToast({ title: 'User Story Deleted', type: 'info' });

    if (user && !user.isGuest) {
      supabaseService.deleteUserStory(id).catch((err) => {
        console.error('Failed to delete story in Supabase:', err);
        setStories(prevStories);
        addToast({ title: 'Failed to delete story', message: err.message, type: 'error' });
      });
    }
  };

  // ==========================================
  // TASK CRUD & DRAG-AND-DROP (Optimistic + History)
  // ==========================================
  const createTask = (data: Omit<Task, 'id' | 'createdAt' | 'order'>): Task => {
    const tempId = crypto.randomUUID();
    const existingNums = tasks
      .map((t) => t.taskNumber || 0)
      .filter((n) => !isNaN(n));
    const nextNum = existingNums.length > 0 ? Math.max(...existingNums) + 1 : 101;

    const newTask: Task = {
      ...data,
      id: tempId,
      taskNumber: nextNum,
      displayNumber: formatTaskNumber(nextNum),
      order: tasks.filter((t) => t.status === data.status && t.sprintId === data.sprintId).length,
      createdAt: new Date().toISOString(),
    };

    setTasks((prev) => [...prev, newTask]);
    addToast({ title: 'Task Created', message: `${newTask.displayNumber}: ${newTask.title}`, type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.createTask(data).then((saved) => {
        setTasks((prev) => prev.map((t) => (t.id === tempId ? saved : t)));
      }).catch((err) => {
        console.error('Failed to create task in Supabase:', err);
        setTasks((prev) => prev.filter((t) => t.id !== tempId));
        addToast({ title: 'Failed to create task', message: err.message, type: 'error' });
      });
    }

    return newTask;
  };

  const updateTask = (id: string, updates: Partial<Task>) => {
    const currentTask = tasksRef.current.find((t) => t.id === id);
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, ...updates } : t)));
    addToast({ title: 'Task Updated', type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.updateTask(id, updates, currentTask).catch((err) => {
        console.error('Failed to update task in Supabase:', err);
        addToast({ title: 'Sync Error', message: err.message, type: 'error' });
      });
    }
  };

  const moveTask = (taskId: string, newStatus: TaskStatus, newIndex?: number) => {
    const prevTasks = tasksRef.current;
    const currentTask = prevTasks.find((t) => t.id === taskId);
    if (!currentTask) return;

    // Optimistically update local state
    setTasks((prev) => {
      const task = prev.find((t) => t.id === taskId);
      if (!task) return prev;

      const otherTasks = prev.filter((t) => t.id !== taskId);
      const updatedTask: Task = { ...task, status: newStatus };

      if (newIndex !== undefined) {
        const columnTasks = otherTasks.filter(
          (t) => t.status === newStatus && t.sprintId === task.sprintId
        );
        columnTasks.splice(newIndex, 0, updatedTask);
        columnTasks.forEach((t, i) => {
          t.order = i;
        });
        const unaffected = otherTasks.filter(
          (t) => !(t.status === newStatus && t.sprintId === task.sprintId)
        );
        return [...unaffected, ...columnTasks];
      }

      return [...otherTasks, updatedTask];
    });

    // Persist to Supabase and record task_status_history
    if (user && !user.isGuest) {
      supabaseService.updateTask(taskId, { status: newStatus }, currentTask).catch((err) => {
        console.error('Failed to persist task move to Supabase:', err);
        setTasks(prevTasks); // Rollback
        addToast({
          title: 'Task Move Failed',
          message: 'Changes were rolled back due to a network or database error.',
          type: 'error',
        });
      });
    }
  };

  const deleteTask = (id: string) => {
    const prevTasks = tasksRef.current;
    setTasks((prev) => prev.filter((t) => t.id !== id));
    addToast({ title: 'Task Deleted', type: 'info' });

    if (user && !user.isGuest) {
      supabaseService.deleteTask(id).catch((err) => {
        console.error('Failed to delete task in Supabase:', err);
        setTasks(prevTasks);
        addToast({ title: 'Failed to delete task', message: err.message, type: 'error' });
      });
    }
  };

  // ==========================================
  // RISKS CRUD
  // ==========================================
  const createRisk = (data: Omit<Risk, 'id' | 'createdAt'>): Risk => {
    const tempId = crypto.randomUUID();
    const newRisk: Risk = {
      ...data,
      id: tempId,
      createdAt: new Date().toISOString(),
    };
    setRisks((prev) => [...prev, newRisk]);
    addToast({ title: 'Risk Logged', message: newRisk.title, type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.createRisk(data).then((saved) => {
        setRisks((prev) => prev.map((r) => (r.id === tempId ? saved : r)));
      }).catch((err) => {
        console.error('Failed to save risk to Supabase:', err);
        setRisks((prev) => prev.filter((r) => r.id !== tempId));
        addToast({ title: 'Failed to save risk', message: err.message, type: 'error' });
      });
    }

    return newRisk;
  };

  const updateRisk = (id: string, updates: Partial<Risk>) => {
    setRisks((prev) => prev.map((r) => (r.id === id ? { ...r, ...updates } : r)));
    addToast({ title: 'Risk Updated', type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.updateRisk(id, updates).catch((err) => {
        console.error('Failed to update risk in Supabase:', err);
        addToast({ title: 'Sync Error', message: err.message, type: 'error' });
      });
    }
  };

  const confirmRisk = (id: string) => {
    setRisks((prev) => prev.map((r) => (r.id === id ? { ...r, confirmed: true, isAiSuggested: false } : r)));
    addToast({ title: 'Risk Confirmed', message: 'Item confirmed and added to active risk ledger.', type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.updateRisk(id, { confirmed: true, isAiSuggested: false }).catch((err) => {
        console.error('Failed to confirm risk in Supabase:', err);
      });
    }
  };

  const deleteRisk = (id: string) => {
    const prevRisks = risks;
    setRisks((prev) => prev.filter((r) => r.id !== id));
    addToast({ title: 'Risk Deleted', type: 'info' });

    if (user && !user.isGuest) {
      supabaseService.deleteRisk(id).catch((err) => {
        console.error('Failed to delete risk in Supabase:', err);
        setRisks(prevRisks);
        addToast({ title: 'Failed to delete risk', message: err.message, type: 'error' });
      });
    }
  };

  // ==========================================
  // DEPENDENCIES CRUD
  // ==========================================
  const createDependency = (data: Omit<Dependency, 'id' | 'createdAt'>): Dependency => {
    const tempId = crypto.randomUUID();
    const newDep: Dependency = {
      ...data,
      id: tempId,
      createdAt: new Date().toISOString(),
    };
    setDependencies((prev) => [...prev, newDep]);
    addToast({ title: 'Dependency Logged', type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.createDependency(data).then((saved) => {
        setDependencies((prev) => prev.map((d) => (d.id === tempId ? saved : d)));
      }).catch((err) => {
        console.error('Failed to save dependency in Supabase:', err);
        setDependencies((prev) => prev.filter((d) => d.id !== tempId));
        addToast({ title: 'Failed to save dependency', message: err.message, type: 'error' });
      });
    }

    return newDep;
  };

  const updateDependency = (id: string, updates: Partial<Dependency>) => {
    setDependencies((prev) => prev.map((d) => (d.id === id ? { ...d, ...updates } : d)));
    addToast({ title: 'Dependency Updated', type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.updateDependency(id, updates).catch((err) => {
        console.error('Failed to update dependency in Supabase:', err);
      });
    }
  };

  const deleteDependency = (id: string) => {
    const prevDeps = dependencies;
    setDependencies((prev) => prev.filter((d) => d.id !== id));
    addToast({ title: 'Dependency Removed', type: 'info' });

    if (user && !user.isGuest) {
      supabaseService.deleteDependency(id).catch((err) => {
        console.error('Failed to delete dependency in Supabase:', err);
        setDependencies(prevDeps);
      });
    }
  };

  // ==========================================
  // DECISIONS CRUD
  // ==========================================
  const createDecision = (data: Omit<DecisionItem, 'id' | 'createdAt'>): DecisionItem => {
    const tempId = crypto.randomUUID();
    const newDec: DecisionItem = {
      ...data,
      id: tempId,
      createdAt: new Date().toISOString(),
    };
    setDecisions((prev) => [...prev, newDec]);
    addToast({ title: 'Decision Item Logged', message: newDec.item, type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.createDecision(data).then((saved) => {
        setDecisions((prev) => prev.map((d) => (d.id === tempId ? saved : d)));
      }).catch((err) => {
        console.error('Failed to save decision in Supabase:', err);
        setDecisions((prev) => prev.filter((d) => d.id !== tempId));
        addToast({ title: 'Failed to save decision', message: err.message, type: 'error' });
      });
    }

    return newDec;
  };

  const updateDecision = (id: string, updates: Partial<DecisionItem>) => {
    setDecisions((prev) => prev.map((d) => (d.id === id ? { ...d, ...updates } : d)));
    addToast({ title: 'Decision Item Updated', type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.updateDecision(id, updates).catch((err) => {
        console.error('Failed to update decision in Supabase:', err);
      });
    }
  };

  const deleteDecision = (id: string) => {
    const prevDecisions = decisions;
    setDecisions((prev) => prev.filter((d) => d.id !== id));
    addToast({ title: 'Decision Item Removed', type: 'info' });

    if (user && !user.isGuest) {
      supabaseService.deleteDecision(id).catch((err) => {
        console.error('Failed to delete decision in Supabase:', err);
        setDecisions(prevDecisions);
      });
    }
  };

  // ==========================================
  // RETROSPECTIVES
  // ==========================================
  const saveRetrospective = (data: Omit<SprintRetrospective, 'id' | 'savedAt'>): SprintRetrospective => {
    const tempId = `retro-${data.sprintId}`;
    const newRetro: SprintRetrospective = {
      ...data,
      id: tempId,
      savedAt: new Date().toISOString(),
    };

    setRetrospectives((prev) => {
      const idx = prev.findIndex((r) => r.sprintId === data.sprintId);
      if (idx >= 0) {
        const clone = [...prev];
        clone[idx] = newRetro;
        return clone;
      }
      return [...prev, newRetro];
    });

    addToast({ title: 'Retrospective Saved', message: 'Action items documented.', type: 'success' });

    if (user && !user.isGuest) {
      supabaseService.saveRetrospective(data).then((saved) => {
        setRetrospectives((prev) => prev.map((r) => (r.sprintId === data.sprintId ? saved : r)));
      }).catch((err) => {
        console.error('Failed to save retrospective in Supabase:', err);
        addToast({ title: 'Sync Error', message: err.message, type: 'error' });
      });
    }

    return newRetro;
  };

  // ==========================================
  // REQUIREMENT CHATS (Chats & Messages)
  // ==========================================
  const createRequirementChat = (initialTitle: string = 'New Requirement Session'): ChatSession => {
    const tempId = crypto.randomUUID();
    const newSession: ChatSession = {
      id: tempId,
      title: initialTitle,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      messages: [],
    };
    setRequirementChats((prev) => [newSession, ...prev]);
    setActiveChatId(newSession.id);

    if (user && !user.isGuest) {
      supabaseService.createChat(initialTitle).then((saved) => {
        setRequirementChats((prev) => prev.map((c) => (c.id === tempId ? { ...saved, messages: c.messages } : c)));
        setActiveChatId(saved.id);
      }).catch((err) => {
        console.error('Failed to save chat to Supabase:', err);
      });
    }

    return newSession;
  };

  const renameRequirementChat = (id: string, newTitle: string) => {
    setRequirementChats((prev) =>
      prev.map((c) => (c.id === id ? { ...c, title: newTitle, updatedAt: new Date().toISOString() } : c))
    );
    addToast({ title: 'Chat Renamed', type: 'info' });

    if (user && !user.isGuest) {
      supabaseService.renameChat(id, newTitle).catch((err) => {
        console.error('Failed to rename chat in Supabase:', err);
      });
    }
  };

  const deleteRequirementChat = (id: string) => {
    const prevChats = requirementChats;
    setRequirementChats((prev) => prev.filter((c) => c.id !== id));
    if (activeChatId === id) {
      const remaining = requirementChats.filter((c) => c.id !== id);
      setActiveChatId(remaining.length > 0 ? remaining[0].id : null);
    }
    addToast({ title: 'Chat Deleted', type: 'info' });

    if (user && !user.isGuest) {
      supabaseService.deleteChat(id).catch((err) => {
        console.error('Failed to delete chat in Supabase:', err);
        setRequirementChats(prevChats);
      });
    }
  };

  const addMessageToChat = (chatId: string, message: Omit<ChatMessage, 'id'>): string => {
    const msgId = crypto.randomUUID();
    const fullMessage: ChatMessage = { ...message, id: msgId };

    setRequirementChats((prev) =>
      prev.map((c) => {
        if (c.id !== chatId) return c;
        return {
          ...c,
          updatedAt: new Date().toISOString(),
          messages: [...c.messages, fullMessage],
        };
      })
    );

    // Persist to Supabase if not streaming placeholder
    if (user && !user.isGuest && !message.isStreaming) {
      supabaseService.addChatMessage(
        chatId,
        message.sender,
        message.content,
        message.attachments
      ).then((saved) => {
        setRequirementChats((prev) =>
          prev.map((c) => {
            if (c.id !== chatId) return c;
            return {
              ...c,
              messages: c.messages.map((m) => (m.id === msgId ? saved : m)),
            };
          })
        );
      }).catch((err) => {
        console.warn('Failed to save message to Supabase:', err);
      });
    }

    return msgId;
  };

  const updateChatMessage = (
    chatId: string,
    messageId: string,
    content: string,
    isStreaming?: boolean,
    error?: string,
    failedPrompt?: string
  ) => {
    setRequirementChats((prev) =>
      prev.map((c) => {
        if (c.id !== chatId) return c;
        return {
          ...c,
          messages: c.messages.map((m) =>
            m.id === messageId ? { ...m, content, isStreaming, error, failedPrompt } : m
          ),
        };
      })
    );

    // When streaming finishes, save complete assistant response to Supabase (only if non-error)
    if (user && !user.isGuest && !isStreaming && !error && content.trim() !== '') {
      supabaseService.addChatMessage(chatId, 'assistant', content).then((saved) => {
        setRequirementChats((prev) =>
          prev.map((c) => {
            if (c.id !== chatId) return c;
            return {
              ...c,
              messages: c.messages.map((m) => (m.id === messageId ? { ...saved, isStreaming: false } : m)),
            };
          })
        );
      }).catch((err) => {
        console.warn('Failed to save completed AI response to Supabase:', err);
      });
    }
  };

  const deleteChatMessage = (chatId: string, messageId: string) => {
    setRequirementChats((prev) =>
      prev.map((c) => {
        if (c.id !== chatId) return c;
        return {
          ...c,
          messages: c.messages.filter((m) => m.id !== messageId),
        };
      })
    );
  };

  const value = {
    user,
    isGuest: Boolean(user?.isGuest),
    isLoadingAuth,
    isLoadingData,
    signIn,
    register,
    signInWithGoogle,
    continueAsGuest,
    logout,
    guestBannerDismissed,
    dismissGuestBanner,
    theme,
    toggleTheme,
    toasts,
    addToast,
    removeToast,
    projects,
    currentProjectId,
    currentProject,
    setCurrentProjectId,
    createProject,
    updateProject,
    archiveProject,
    deleteProject,
    addProjectDocument,
    deleteProjectDocument,
    sprints,
    currentSprint,
    projectSprints,
    createSprint,
    updateSprint,
    startSprint,
    completeSprint,
    addStoriesToSprint,
    removeStoryFromSprint,
    stories,
    projectStories,
    createStory,
    updateStory,
    deleteStory,
    tasks,
    projectTasks,
    currentSprintTasks,
    createTask,
    updateTask,
    moveTask,
    deleteTask,
    risks,
    projectRisks,
    createRisk,
    updateRisk,
    confirmRisk,
    deleteRisk,
    dependencies,
    projectDependencies,
    createDependency,
    updateDependency,
    deleteDependency,
    decisions,
    projectDecisions,
    createDecision,
    updateDecision,
    deleteDecision,
    retrospectives,
    projectRetrospectives,
    saveRetrospective,
    requirementChats,
    activeChatId,
    activeChat,
    setActiveChatId,
    createRequirementChat,
    renameRequirementChat,
    deleteRequirementChat,
    addMessageToChat,
    updateChatMessage,
    deleteChatMessage,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
