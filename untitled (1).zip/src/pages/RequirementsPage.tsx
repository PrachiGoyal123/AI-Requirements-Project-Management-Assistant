import React, { useState, useRef, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useApp } from '../store/AppContext';
import { Logo } from '../components/common/Logo';
import { ThemeToggle } from '../components/common/ThemeToggle';
import { MarkdownRenderer } from '../components/common/MarkdownRenderer';
import { mockRequirementsService } from '../services/mockRequirementsService';
import { aiClient, AiClientError } from '../services/ai/aiClient';
import { supabaseService } from '../services/supabaseService';
import { validateFile, formatFileSize } from '../lib/fileValidation';
import { FileAttachment } from '../types/requirement';
import { 
  Plus, 
  MessageSquare, 
  LogOut, 
  Paperclip, 
  Mic, 
  MicOff, 
  Send, 
  Square, 
  Copy, 
  RotateCw, 
  Trash2, 
  Edit2, 
  X, 
  FileText, 
  Check, 
  Menu, 
  ArrowLeft,
  Sparkles,
  Bot,
  Download,
  Loader2,
  AlertCircle
} from 'lucide-react';

export const RequirementsPage: React.FC = () => {
  const navigate = useNavigate();
  const {
    user,
    isGuest,
    requirementChats,
    activeChatId,
    activeChat,
    setActiveChatId,
    createRequirementChat,
    renameRequirementChat,
    deleteRequirementChat,
    addMessageToChat,
    updateChatMessage,
    deleteChatMessage,
    logout,
    addToast,
  } = useApp();

  const [inputPrompt, setInputPrompt] = useState('');
  const [attachments, setAttachments] = useState<FileAttachment[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [downloadingPath, setDownloadingPath] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [speechLang, setSpeechLang] = useState<'en-IN' | 'hi-IN'>('en-IN');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [editingChatId, setEditingChatId] = useState<string | null>(null);
  const [renameTitle, setRenameTitle] = useState('');
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const recognitionRef = useRef<any>(null);
  const basePromptRef = useRef<string>('');

  // Auto-scroll on new message
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeChat?.messages, isGenerating]);

  // Clean up Speech Recognition on unmount
  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {
          // ignore
        }
      }
    };
  }, []);

  const toggleSpeech = async () => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      addToast({
        title: 'Unsupported Browser',
        message: 'Speech recognition is not supported in this browser. Please use Chrome or Edge.',
        type: 'warning',
      });
      return;
    }

    // Stop listening if already active (stop on second click)
    if (isListening) {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (err) {
          console.error('Error stopping speech recognition:', err);
        }
      }
      setIsListening(false);
      addToast({
        title: 'Listening Stopped',
        message: 'Speech recognition stopped. You can edit your requirement before sending.',
        type: 'info',
      });
      return;
    }

    // Request microphone permission explicitly via getUserMedia if available
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((track) => track.stop());
      } catch (err: any) {
        if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
          addToast({
            title: 'Permission Denied',
            message: 'Microphone permission was denied. Please allow microphone access in your browser settings.',
            type: 'error',
          });
          return;
        }
      }
    }

    try {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {
          // ignore
        }
      }

      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = speechLang;

      // Save the current text in inputPrompt so live interim results append smoothly
      basePromptRef.current = inputPrompt;

      recognition.onstart = () => {
        setIsListening(true);
        addToast({
          title: 'Listening...',
          message: `Listening in ${speechLang === 'en-IN' ? 'English (India)' : 'Hindi (India)'}. Speak clearly.`,
          type: 'info',
        });
      };

      recognition.onresult = (event: any) => {
        let finalTranscript = '';
        let interimTranscript = '';

        for (let i = 0; i < event.results.length; ++i) {
          const result = event.results[i];
          const text = result[0]?.transcript || '';
          if (result.isFinal) {
            finalTranscript += text;
          } else {
            interimTranscript += text;
          }
        }

        const spoken = (finalTranscript + interimTranscript).trim();
        const base = basePromptRef.current ? basePromptRef.current.trim() : '';

        if (base && spoken) {
          setInputPrompt(`${base} ${spoken}`);
        } else if (spoken) {
          setInputPrompt(spoken);
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error event:', event.error);
        setIsListening(false);

        if (event.error === 'not-allowed' || event.error === 'service-not-allowed') {
          addToast({
            title: 'Permission Denied',
            message: 'Microphone permission was denied. Please allow microphone access in your browser settings.',
            type: 'error',
          });
        } else if (event.error === 'no-speech') {
          addToast({
            title: 'No Speech Detected',
            message: 'No speech was detected. Please check your microphone and speak clearly.',
            type: 'warning',
          });
        } else if (event.error === 'audio-capture') {
          addToast({
            title: 'Microphone Not Found',
            message: 'No microphone was found or microphone is in use by another app.',
            type: 'error',
          });
        } else if (event.error === 'network') {
          addToast({
            title: 'Network Error',
            message: 'Speech recognition requires an internet connection.',
            type: 'error',
          });
        } else if (event.error === 'aborted') {
          // Manually stopped/aborted, ignore toast
        } else {
          addToast({
            title: 'Speech Recognition Error',
            message: `Speech error: ${event.error || 'Unknown error'}. Please try again.`,
            type: 'warning',
          });
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err: any) {
      console.error('Failed to start SpeechRecognition:', err);
      setIsListening(false);
      addToast({
        title: 'Speech Recognition Error',
        message: 'Could not start microphone recording. Please try again.',
        type: 'error',
      });
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const newAttachments: FileAttachment[] = [];

    Array.from(files).forEach((file) => {
      // Validate file before accepting
      const validation = validateFile(file);
      if (!validation.valid) {
        addToast({
          title: 'File Rejected',
          message: validation.error || 'Invalid file format or size.',
          type: 'error',
        });
        return;
      }

      const isText =
        file.type.includes('text') ||
        file.name.endsWith('.md') ||
        file.name.endsWith('.json') ||
        file.name.endsWith('.txt') ||
        file.name.endsWith('.csv');

      const attId = `att-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;

      if (isText) {
        const reader = new FileReader();
        reader.onload = () => {
          setAttachments((prev) => [
            ...prev,
            {
              id: attId,
              name: file.name,
              size: file.size,
              type: file.type || 'text/plain',
              file: file,
              extractedTextSnippet: String(reader.result).slice(0, 1000),
              uploading: false,
            },
          ]);
        };
        reader.readAsText(file);
      } else {
        newAttachments.push({
          id: attId,
          name: file.name,
          size: file.size,
          type: file.type || 'application/octet-stream',
          file: file,
          uploading: false,
        });
      }
    });

    if (newAttachments.length > 0) {
      setAttachments((prev) => [...prev, ...newAttachments]);
    }

    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeAttachment = (id: string) => {
    setAttachments((prev) => prev.filter((a) => a.id !== id));
  };

  const handleOpenAttachment = async (att: FileAttachment) => {
    if (!att.path) {
      addToast({
        title: 'File Preview',
        message: `${att.name} (${formatFileSize(att.size)})`,
        type: 'info',
      });
      return;
    }

    setDownloadingPath(att.path);
    try {
      // Always generate signed URL with 3600s validity (never public URL)
      const signedUrl = await supabaseService.createSignedUrl(att.path, 3600);
      const link = document.createElement('a');
      link.href = signedUrl;
      link.download = att.name;
      link.target = '_blank';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      addToast({ title: 'Opening file...', message: att.name, type: 'info' });
    } catch (err: any) {
      console.error('Failed to get signed URL:', err);
      addToast({
        title: 'Download Failed',
        message: err.message || 'Could not access file. Your session may have expired.',
        type: 'error',
      });
    } finally {
      setDownloadingPath(null);
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const prompt = textToSend !== undefined ? textToSend : inputPrompt;
    if (!prompt.trim() && attachments.length === 0) return;
    if (isGenerating || isUploading) return;

    // Ensure we have an active chat session
    let targetChatId = activeChatId;
    if (!targetChatId || !requirementChats.find((c) => c.id === targetChatId)) {
      const newSession = createRequirementChat(prompt.slice(0, 32) || 'Requirement Analysis');
      targetChatId = newSession.id;
    }

    // Stop listening if active
    if (isListening && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
    }

    // Upload files if signed in and attachments present
    const uploadedAttachments: { name: string; size: number; type: string; path?: string }[] = [];

    if (user && !isGuest && attachments.length > 0) {
      setIsUploading(true);
      setAttachments((prev) =>
        prev.map((a) => ({ ...a, uploading: true, uploadError: undefined }))
      );

      let uploadFailed = false;

      for (const att of attachments) {
        if (att.path) {
          uploadedAttachments.push({
            name: att.name,
            size: att.size,
            type: att.type,
            path: att.path,
          });
          continue;
        }

        if (!att.file) {
          uploadedAttachments.push({
            name: att.name,
            size: att.size,
            type: att.type,
          });
          continue;
        }

        try {
          const res = await supabaseService.uploadChatAttachment(targetChatId, att.file);
          uploadedAttachments.push({
            name: res.name,
            size: res.size,
            type: res.type,
            path: res.path,
          });
          setAttachments((prev) =>
            prev.map((a) => (a.id === att.id ? { ...a, uploading: false, path: res.path } : a))
          );
        } catch (err: any) {
          uploadFailed = true;
          const errMsg = err.message || 'Storage upload error';
          setAttachments((prev) =>
            prev.map((a) => (a.id === att.id ? { ...a, uploading: false, uploadError: errMsg } : a))
          );
          addToast({
            title: 'File Upload Failed',
            message: `Could not upload "${att.name}": ${errMsg}. Message was not sent; click Send to retry.`,
            type: 'error',
          });
          break;
        }
      }

      setIsUploading(false);

      if (uploadFailed) {
        // Keep message in input box and attachments in preview for retry!
        return;
      }
    } else if (attachments.length > 0) {
      // Guest mode: convert small files (max 5 MB) to base64 in request body
      let rejectedTooLarge = false;
      for (const a of attachments) {
        if (a.file) {
          if (a.file.size > 5 * 1024 * 1024) {
            rejectedTooLarge = true;
            addToast({
              title: 'File Too Large (Guest Mode)',
              message: `"${a.name}" is ${(a.file.size / (1024 * 1024)).toFixed(1)} MB. Guest uploads are limited to 5 MB. Please sign in to upload files up to 20 MB.`,
              type: 'error',
            });
            break;
          }
          try {
            const base64Data = await new Promise<string>((resolve, reject) => {
              const reader = new FileReader();
              reader.onload = () => {
                const res = String(reader.result || '');
                resolve(res.includes(',') ? res.split(',')[1] : res);
              };
              reader.onerror = reject;
              reader.readAsDataURL(a.file!);
            });
            uploadedAttachments.push({
              name: a.name,
              size: a.size,
              type: a.type,
              dataBase64: base64Data,
            } as any);
          } catch {
            uploadedAttachments.push({
              name: a.name,
              size: a.size,
              type: a.type,
            });
          }
        } else {
          uploadedAttachments.push({
            name: a.name,
            size: a.size,
            type: a.type,
          });
        }
      }
      if (rejectedTooLarge) {
        return;
      }
    }

    // Add user message with completed attachment objects
    addMessageToChat(targetChatId, {
      sender: 'user',
      content: prompt,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      attachments: uploadedAttachments.length > 0 ? (uploadedAttachments as any) : undefined,
    });

    // Clear inputs after successful upload and message dispatch
    setInputPrompt('');
    setAttachments([]);
    setIsGenerating(true);

    // Create assistant placeholder message
    const assistantMsgId = addMessageToChat(targetChatId, {
      sender: 'assistant',
      content: '',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isStreaming: true,
    });

    const abortController = new AbortController();
    abortControllerRef.current = abortController;

    // Build chat history array including previous messages and the new user message
    const chatHistory = (activeChat?.messages || []).map((m) => ({
      role: m.sender,
      content: m.content,
      attachments: m.attachments?.map((a) => ({
        name: a.name,
        size: a.size,
        type: a.type,
        path: a.path,
        dataBase64: (a as any).dataBase64,
        extractedTextSnippet: a.extractedTextSnippet,
      })),
    }));

    chatHistory.push({
      role: 'user',
      content: prompt,
      attachments: uploadedAttachments as any,
    });

    let currentAccumulated = '';

    try {
      await aiClient.streamRequirementChat({
        messages: chatHistory,
        onChunk: (delta, isDone) => {
          currentAccumulated += delta;
          updateChatMessage(targetChatId!, assistantMsgId, currentAccumulated, !isDone);
        },
        signal: abortController.signal,
      });
    } catch (err: any) {
      if (err.name === 'AbortError' || abortController.signal.aborted) {
        // User aborted via Stop Generating button: keep partial text
        const partial = currentAccumulated.trim()
          ? `${currentAccumulated}\n\n*(Generation stopped by user)*`
          : '*(Generation stopped by user)*';
        updateChatMessage(targetChatId!, assistantMsgId, partial, false);
      } else {
        const friendlyMessage =
          err instanceof AiClientError
            ? err.message
            : err?.message || 'Failed to complete requirement analysis. Please try again.';

        updateChatMessage(
          targetChatId!,
          assistantMsgId,
          currentAccumulated,
          false,
          friendlyMessage,
          prompt
        );

        addToast({
          title: err?.isRateLimit ? 'Rate Limit Reached' : err?.isQuota ? 'Quota Exceeded' : 'AI Analysis Error',
          message: friendlyMessage,
          type: 'error',
        });
      }
    } finally {
      setIsGenerating(false);
      abortControllerRef.current = null;
    }
  };

  const handleRetry = (failedPrompt: string, failedMsgId?: string) => {
    if (!failedPrompt || isGenerating) return;
    if (activeChatId && failedMsgId) {
      deleteChatMessage(activeChatId, failedMsgId);
    }
    handleSendMessage(failedPrompt);
  };

  const handleStopGenerating = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setIsGenerating(false);
  };

  const handleCopyContent = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMsgId(id);
    addToast({ title: 'Copied to clipboard', type: 'info' });
    setTimeout(() => setCopiedMsgId(null), 2000);
  };

  const handleRegenerate = async (lastUserMessage: string) => {
    if (isGenerating || !activeChatId) return;
    handleSendMessage(lastUserMessage);
  };

  const handleNewChat = () => {
    const session = createRequirementChat('New Requirement Session');
    setActiveChatId(session.id);
    setSidebarOpen(false);
  };

  const handleLogout = () => {
    logout();
    navigate('/welcome');
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / 1048576).toFixed(1)} MB`;
  };

  const promptChips = [
    'Break down an e-commerce checkout flow into user stories and acceptance criteria',
    'Analyze HIPAA compliance requirements for patient record export',
    'Draft non-functional specifications for sub-second search API',
    'Synthesize user onboarding edge cases and error states',
  ];

  return (
    <div className="flex h-screen bg-stone-50 dark:bg-stone-950 text-stone-900 dark:text-stone-100 overflow-hidden font-sans">
      {/* File input (hidden) */}
      <input
        type="file"
        multiple
        ref={fileInputRef}
        onChange={handleFileUpload}
        className="hidden"
      />

      {/* Left Sidebar */}
      <aside
        className={`fixed lg:static inset-y-0 left-0 z-40 w-72 bg-white dark:bg-stone-900 border-r border-stone-200 dark:border-stone-800 flex flex-col transition-transform duration-200 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Sidebar Header */}
        <div className="p-4 border-b border-stone-100 dark:border-stone-800 flex items-center justify-between">
          <Link to="/home" className="hover:opacity-85 transition-opacity">
            <Logo size="sm" />
          </Link>
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden p-1 text-stone-400 hover:text-stone-600 dark:hover:text-stone-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* New Chat Button */}
        <div className="p-3">
          <button
            onClick={handleNewChat}
            className="w-full flex items-center justify-center gap-2 py-2 px-3.5 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>New Chat</span>
          </button>
        </div>

        {/* Chat History List */}
        <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1">
          <p className="text-[11px] font-semibold text-stone-400 dark:text-stone-500 uppercase tracking-wider px-2 mb-1.5">
            Sessions
          </p>
          {requirementChats.length === 0 ? (
            <p className="text-xs text-stone-400 dark:text-stone-500 px-2 py-4 italic">
              No sessions yet.
            </p>
          ) : (
            requirementChats.map((chat) => {
              const isActive = chat.id === activeChatId;
              return (
                <div
                  key={chat.id}
                  className={`group relative flex items-center justify-between rounded-xl px-2.5 py-2 text-xs transition-colors ${
                    isActive
                      ? 'bg-teal-50 dark:bg-teal-950/60 text-teal-900 dark:text-teal-200 font-medium'
                      : 'text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800/60'
                  }`}
                >
                  {editingChatId === chat.id ? (
                    <div className="flex items-center gap-1 w-full">
                      <input
                        type="text"
                        value={renameTitle}
                        onChange={(e) => setRenameTitle(e.target.value)}
                        className="flex-1 px-1.5 py-0.5 text-xs bg-white dark:bg-stone-900 border border-teal-500 rounded outline-none"
                        autoFocus
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            renameRequirementChat(chat.id, renameTitle || chat.title);
                            setEditingChatId(null);
                          } else if (e.key === 'Escape') {
                            setEditingChatId(null);
                          }
                        }}
                      />
                      <button
                        onClick={() => {
                          renameRequirementChat(chat.id, renameTitle || chat.title);
                          setEditingChatId(null);
                        }}
                        className="p-1 text-teal-700 hover:text-teal-800"
                      >
                        <Check className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <button
                        onClick={() => {
                          setActiveChatId(chat.id);
                          setSidebarOpen(false);
                        }}
                        className="flex items-center gap-2 flex-1 min-w-0 text-left"
                      >
                        <MessageSquare className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-teal-700 dark:text-teal-400' : 'text-stone-400'}`} />
                        <span className="truncate">{chat.title}</span>
                      </button>

                      {/* Rename / Delete Menu */}
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingChatId(chat.id);
                            setRenameTitle(chat.title);
                          }}
                          className="p-1 text-stone-400 hover:text-stone-600 dark:hover:text-stone-200"
                          title="Rename"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteRequirementChat(chat.id);
                          }}
                          className="p-1 text-stone-400 hover:text-rose-600"
                          title="Delete"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Sidebar Footer: Back to Hub & Logout */}
        <div className="p-3 border-t border-stone-100 dark:border-stone-800 space-y-1">
          <Link
            to="/home"
            className="w-full flex items-center gap-2 py-2 px-3 text-xs font-medium text-stone-600 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-xl transition-colors"
          >
            <ArrowLeft className="w-4 h-4 text-stone-400" />
            <span>Return to Hub</span>
          </Link>
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2 py-2 px-3 text-xs font-medium text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* Main Chat Viewport */}
      <div className="flex-1 flex flex-col h-full overflow-hidden bg-stone-50/50 dark:bg-stone-950">
        {/* Top Navbar */}
        <header className="px-5 py-3.5 border-b border-stone-200/80 dark:border-stone-800/80 bg-white/60 dark:bg-stone-900/40 backdrop-blur-xs flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-1.5 text-stone-500 hover:text-stone-700 dark:hover:text-stone-300 rounded-lg"
              aria-label="Open sidebar"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div>
              <h2 className="text-sm font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
                <span>{activeChat?.title || 'AI Requirement Analysis'}</span>
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Link
              to="/projects"
              className="text-xs font-medium text-teal-700 dark:text-teal-400 hover:underline hidden sm:block"
            >
              Open Projects &rarr;
            </Link>
            <ThemeToggle />
          </div>
        </header>

        {/* Message Thread Scroll Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 space-y-6">
          {!activeChat || activeChat.messages.length === 0 ? (
            /* Empty State with greeting and 4 prompt chips */
            <div className="max-w-2xl mx-auto my-auto py-12 flex flex-col items-center text-center">
              <div className="w-14 h-14 rounded-2xl bg-teal-50 dark:bg-teal-950/80 text-teal-700 dark:text-teal-400 border border-teal-200/60 dark:border-teal-800/60 flex items-center justify-center mb-4 shadow-sm">
                <Bot className="w-7 h-7" />
              </div>
              <h3 className="text-xl font-bold text-stone-900 dark:text-stone-100">
                AI Requirements Architect
              </h3>
              <p className="text-xs text-stone-500 dark:text-stone-400 max-w-md mt-1.5 leading-relaxed">
                Describe a product feature, dictate requirements with speech, or attach documents. 
                The assistant will generate structured specifications and acceptance criteria.
              </p>

              {/* 4 Prompt Chips */}
              <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-3 w-full text-left">
                {promptChips.map((chip, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(chip)}
                    className="p-3.5 rounded-xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 hover:border-teal-600 dark:hover:border-teal-500 hover:bg-teal-50/30 dark:hover:bg-teal-950/30 text-xs text-stone-700 dark:text-stone-300 shadow-2xs transition-all duration-150 flex items-start gap-2.5 group"
                  >
                    <Sparkles className="w-4 h-4 text-amber-500 shrink-0 mt-0.5 group-hover:scale-110 transition-transform" />
                    <span className="leading-relaxed">{chip}</span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="max-w-3xl mx-auto space-y-6">
              {activeChat.messages.map((msg, index) => {
                const isUser = msg.sender === 'user';
                return (
                  <div
                    key={msg.id}
                    className={`flex items-start gap-3.5 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
                  >
                    {/* Avatar */}
                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 ${
                        isUser
                          ? 'bg-teal-700 text-white'
                          : 'bg-stone-200 dark:bg-stone-800 text-stone-700 dark:text-stone-200 ring-1 ring-stone-300 dark:ring-stone-700'
                      }`}
                    >
                      {isUser ? 'You' : <Bot className="w-4 h-4 text-teal-700 dark:text-teal-400" />}
                    </div>

                    {/* Bubble */}
                    <div className={`max-w-[85%] sm:max-w-[80%] flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
                      {/* Attachments pills if any */}
                      {msg.attachments && msg.attachments.length > 0 && (
                        <div className="flex flex-wrap gap-2 mb-2">
                          {msg.attachments.map((att, attIdx) => {
                            const isDownloading = downloadingPath === att.path;
                            return (
                              <button
                                key={att.path || att.id || attIdx}
                                type="button"
                                onClick={() => handleOpenAttachment(att)}
                                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-stone-100 hover:bg-stone-200 dark:bg-stone-800 dark:hover:bg-stone-700/80 border border-stone-200 dark:border-stone-700 text-[11px] text-stone-700 dark:text-stone-300 transition-colors cursor-pointer group shadow-2xs"
                                title={att.path ? 'Click to open or download (signed URL)' : 'Attached file'}
                              >
                                <FileText className="w-3.5 h-3.5 text-teal-700 dark:text-teal-400 group-hover:scale-105 transition-transform" />
                                <span className="truncate max-w-[120px] font-medium">{att.name}</span>
                                <span className="text-stone-400 text-[10px]">({formatFileSize(att.size)})</span>
                                {isDownloading ? (
                                  <Loader2 className="w-3 h-3 animate-spin text-teal-600 shrink-0" />
                                ) : (
                                  <Download className="w-3 h-3 text-stone-400 group-hover:text-stone-600 dark:group-hover:text-stone-200 shrink-0 transition-colors" />
                                )}
                              </button>
                            );
                          })}
                        </div>
                      )}

                      <div
                        className={`p-4 sm:p-5 rounded-2xl text-xs ${
                          isUser
                            ? 'bg-teal-700 text-white rounded-tr-xs'
                            : 'bg-white dark:bg-stone-900 border border-stone-200/80 dark:border-stone-800 rounded-tl-xs shadow-xs'
                        }`}
                      >
                        {isUser ? (
                          <p className="whitespace-pre-wrap leading-relaxed">{msg.content}</p>
                        ) : (
                          <>
                            {msg.isStreaming && !msg.content && (
                              <div className="flex items-center gap-2 text-stone-500 dark:text-stone-400 py-1 font-medium">
                                <Loader2 className="w-3.5 h-3.5 animate-spin text-teal-600" />
                                <span>Architecting specifications...</span>
                              </div>
                            )}

                            {msg.content && <MarkdownRenderer content={msg.content} />}

                            {msg.error && (
                              <div className={`${msg.content ? 'mt-3' : ''} p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/80 text-rose-800 dark:text-rose-200 text-xs flex flex-col gap-2.5`}>
                                <div className="flex items-start gap-2">
                                  <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
                                  <div className="flex-1 space-y-0.5">
                                    <p className="font-semibold text-rose-900 dark:text-rose-100">
                                      {msg.error.toLowerCase().includes('rate limit')
                                        ? 'Rate Limit Reached'
                                        : msg.error.toLowerCase().includes('quota')
                                        ? 'API Quota Exceeded'
                                        : msg.error.toLowerCase().includes('network')
                                        ? 'Network Connection Issue'
                                        : 'Generation Error'}
                                    </p>
                                    <p className="text-stone-600 dark:text-stone-300 leading-relaxed text-[11px]">{msg.error}</p>
                                  </div>
                                </div>
                                <div className="pt-2 border-t border-rose-200/60 dark:border-rose-800/60 flex items-center justify-between gap-2">
                                  <span className="text-[10px] text-stone-500 dark:text-stone-400">
                                    Click Retry to submit the requirement again
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => handleRetry(msg.failedPrompt || '', msg.id)}
                                    className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-teal-700 hover:bg-teal-800 text-white font-medium text-xs shadow-xs transition-colors cursor-pointer"
                                  >
                                    <RotateCw className="w-3 h-3" />
                                    <span>Retry</span>
                                  </button>
                                </div>
                              </div>
                            )}
                          </>
                        )}
                      </div>

                      {/* Message Footer: Actions & Timestamp */}
                      <div className="flex items-center gap-2 mt-1.5 px-1 text-[11px] text-stone-400">
                        <span>{msg.timestamp}</span>
                        {!isUser && (
                          <>
                            <span>·</span>
                            <button
                              onClick={() => handleCopyContent(msg.content, msg.id)}
                              className="hover:text-stone-700 dark:hover:text-stone-200 flex items-center gap-1 transition-colors"
                              title="Copy response"
                            >
                              {copiedMsgId === msg.id ? (
                                <>
                                  <Check className="w-3 h-3 text-teal-600" />
                                  <span className="text-teal-600">Copied</span>
                                </>
                              ) : (
                                <>
                                  <Copy className="w-3 h-3" />
                                  <span>Copy</span>
                                </>
                              )}
                            </button>
                            {index === activeChat.messages.length - 1 && (
                              <>
                                <span>·</span>
                                <button
                                  onClick={() => {
                                    const prevUser = activeChat.messages
                                      .slice(0, index)
                                      .reverse()
                                      .find((m) => m.sender === 'user');
                                    if (prevUser) handleRegenerate(prevUser.content);
                                  }}
                                  className="hover:text-stone-700 dark:hover:text-stone-200 flex items-center gap-1 transition-colors"
                                  title="Regenerate reply"
                                >
                                  <RotateCw className="w-3 h-3" />
                                  <span>Regenerate</span>
                                </button>
                              </>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
              <div ref={chatBottomRef} />
            </div>
          )}
        </div>

        {/* Input Bar Area */}
        <div className="p-4 sm:p-6 max-w-3xl w-full mx-auto shrink-0">
          {/* Stop generating floating button */}
          {isGenerating && (
            <div className="flex justify-center mb-2">
              <button
                onClick={handleStopGenerating}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 text-stone-700 dark:text-stone-200 text-xs font-medium shadow-md hover:bg-stone-50 dark:hover:bg-stone-800 transition-colors animate-in fade-in"
              >
                <Square className="w-3 h-3 fill-current text-rose-500" />
                <span>Stop generating</span>
              </button>
            </div>
          )}

          {/* Attached Files Preview Chips */}
          {attachments.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-2 px-1">
              {attachments.map((att) => (
                <div
                  key={att.id}
                  className={`inline-flex items-center gap-2 px-3 py-1 rounded-lg border text-xs shadow-2xs transition-colors ${
                    att.uploadError
                      ? 'bg-rose-50 dark:bg-rose-950/70 border-rose-300 dark:border-rose-800 text-rose-900 dark:text-rose-200'
                      : 'bg-teal-50 dark:bg-teal-950/70 border-teal-200/80 dark:border-teal-800/80 text-teal-900 dark:text-teal-200'
                  }`}
                >
                  {att.uploading ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-teal-700 dark:text-teal-400" />
                  ) : att.uploadError ? (
                    <span title={att.uploadError} className="inline-flex items-center">
                      <AlertCircle className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
                    </span>
                  ) : (
                    <FileText className="w-3.5 h-3.5 text-teal-700 dark:text-teal-400" />
                  )}
                  <span className="font-medium truncate max-w-[140px]">{att.name}</span>
                  <span className="text-[10px] opacity-75">
                    ({formatFileSize(att.size)})
                  </span>
                  {att.uploading && (
                    <span className="text-[10px] font-semibold text-teal-700 dark:text-teal-400 animate-pulse">
                      Uploading...
                    </span>
                  )}
                  {!att.uploading && (
                    <button
                      type="button"
                      onClick={() => removeAttachment(att.id)}
                      className="text-stone-400 hover:text-stone-600 dark:hover:text-stone-200 ml-1"
                      aria-label="Remove attachment"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Multi-line Input Box */}
          <div className="relative rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 shadow-sm focus-within:border-teal-700 dark:focus-within:border-teal-500 focus-within:ring-2 focus-within:ring-teal-700/20 transition-all p-2 flex items-end gap-2">
            
            {/* Attachment Button on Left */}
            <button
              type="button"
              disabled={isUploading || isGenerating}
              onClick={() => fileInputRef.current?.click()}
              className="p-2 text-stone-400 hover:text-teal-700 dark:hover:text-teal-400 disabled:opacity-40 rounded-xl hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors shrink-0"
              title="Attach requirements documents (PDF, DOCX, TXT, MD, CSV, XLSX, PPTX, PNG, JPG - max 20MB)"
              aria-label="Attach documents"
            >
              <Paperclip className="w-4 h-4" />
            </button>

            {/* Auto-growing Textarea */}
            <textarea
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendMessage();
                }
              }}
              placeholder={
                isListening
                  ? speechLang === 'hi-IN'
                    ? 'बोलिए... (Listening in Hindi - India)...'
                    : 'Listening in English (India)... speak now...'
                  : isUploading
                  ? 'Uploading files to storage...'
                  : attachments.length > 0
                  ? 'Add optional instructions, or press Enter to upload & summarize attachment...'
                  : 'Type requirements or prompt...'
              }
              rows={1}
              className="flex-1 py-1 px-1 bg-transparent border-0 outline-none resize-none text-xs text-stone-900 dark:text-stone-100 placeholder:text-stone-400 min-h-[36px] max-h-36 leading-relaxed"
            />

            {/* Speech Recognition Controls: Language Selector & Mic Button */}
            <div className="flex items-center gap-1 shrink-0">
              <select
                value={speechLang}
                onChange={(e) => setSpeechLang(e.target.value as 'en-IN' | 'hi-IN')}
                disabled={isListening || isUploading || isGenerating}
                className="text-[11px] font-medium bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 border border-stone-200 dark:border-stone-700 rounded-lg px-1.5 py-1 outline-none cursor-pointer hover:bg-stone-200 dark:hover:bg-stone-700 disabled:opacity-50 transition-colors"
                title="Speech recognition language (en-IN or hi-IN)"
                aria-label="Speech recognition language"
              >
                <option value="en-IN">EN (IN)</option>
                <option value="hi-IN">HI (IN)</option>
              </select>

              <button
                type="button"
                onClick={toggleSpeech}
                disabled={isUploading || isGenerating}
                className={`p-2 rounded-xl transition-all shrink-0 ${
                  isListening
                    ? 'bg-rose-500 text-white animate-pulse shadow-sm ring-2 ring-rose-400/50'
                    : 'text-stone-400 hover:text-teal-700 dark:hover:text-teal-400 hover:bg-stone-100 dark:hover:bg-stone-800'
                }`}
                title={
                  isListening
                    ? `Listening in ${speechLang === 'en-IN' ? 'English (India)' : 'Hindi (India)'}... Click to stop`
                    : `Dictate in ${speechLang === 'en-IN' ? 'English (India)' : 'Hindi (India)'}`
                }
                aria-label={isListening ? 'Stop recording voice' : 'Dictate with microphone'}
              >
                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>
            </div>

            {/* Send Button on Far Right */}
            <button
              type="button"
              onClick={() => handleSendMessage()}
              disabled={(!inputPrompt.trim() && attachments.length === 0) || isGenerating || isUploading}
              className="p-2 rounded-xl bg-teal-700 hover:bg-teal-800 disabled:opacity-30 disabled:hover:bg-teal-700 text-white transition-colors shrink-0 shadow-xs flex items-center justify-center"
              title="Send (Enter)"
              aria-label="Send message"
            >
              {isUploading ? (
                <Loader2 className="w-4 h-4 animate-spin text-white" />
              ) : (
                <Send className="w-4 h-4" />
              )}
            </button>
          </div>

          <div className="flex items-center justify-between mt-2 px-1 text-[11px] text-stone-400">
            <span>Shift + Enter for new line · Enter to send</span>
            <span>Local mock intelligence</span>
          </div>
        </div>
      </div>
    </div>
  );
};
