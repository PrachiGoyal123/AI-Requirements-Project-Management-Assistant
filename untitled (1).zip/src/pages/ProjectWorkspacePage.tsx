import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useApp } from '../store/AppContext';
import { Logo } from '../components/common/Logo';
import { GuestBanner } from '../components/common/GuestBanner';
import { Breadcrumbs } from '../components/common/Breadcrumbs';
import { StatusPill } from '../components/common/Badge';

// Workspace section views
import { OverviewView } from '../components/workspace/OverviewView';
import { BacklogView } from '../components/workspace/BacklogView';
import { SprintPlanningView } from '../components/workspace/SprintPlanningView';
import { ScrumBoardView } from '../components/workspace/ScrumBoardView';
import { RisksDependenciesView } from '../components/workspace/RisksDependenciesView';
import { DecisionsApprovalsView } from '../components/workspace/DecisionsApprovalsView';
import { ProjectAssistantView } from '../components/workspace/ProjectAssistantView';
import { SprintReviewView } from '../components/workspace/SprintReviewView';
import { RetrospectiveView } from '../components/workspace/RetrospectiveView';
import { ReportsView } from '../components/workspace/ReportsView';
import { ProjectSettingsView } from '../components/workspace/ProjectSettingsView';

import { 
  LayoutDashboard, 
  Layers, 
  Calendar, 
  Kanban, 
  AlertTriangle, 
  FileCheck, 
  Bot, 
  CheckCircle2, 
  RotateCcw, 
  FileText, 
  Settings, 
  ArrowLeft, 
  ChevronDown, 
  Menu, 
  X,
  Sparkles
} from 'lucide-react';

export type WorkspaceTab = 
  | 'overview'
  | 'backlog'
  | 'sprints'
  | 'board'
  | 'risks'
  | 'decisions'
  | 'assistant'
  | 'sprint-review'
  | 'retrospective'
  | 'reports'
  | 'settings';

export const ProjectWorkspacePage: React.FC = () => {
  const { id, tab } = useParams<{ id: string; tab?: string }>();
  const navigate = useNavigate();
  const { projects, currentProjectId, setCurrentProjectId, currentProject } = useApp();

  const [activeTab, setActiveTab] = useState<WorkspaceTab>(() => {
    return (tab as WorkspaceTab) || 'overview';
  });

  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Sync route params with state
  useEffect(() => {
    if (id && id !== currentProjectId) {
      setCurrentProjectId(id);
    }
  }, [id, currentProjectId, setCurrentProjectId]);

  useEffect(() => {
    if (tab) {
      setActiveTab(tab as WorkspaceTab);
    }
  }, [tab]);

  const handleTabChange = (newTab: WorkspaceTab) => {
    setActiveTab(newTab);
    setSidebarOpen(false);
    navigate(`/projects/${currentProject?.id || id}/${newTab}`);
  };

  const handleProjectSwitch = (newProjectId: string) => {
    setCurrentProjectId(newProjectId);
    navigate(`/projects/${newProjectId}/${activeTab}`);
  };

  const navItems: { id: WorkspaceTab; label: string; icon: any; count?: number }[] = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'backlog', label: 'Product Backlog', icon: Layers },
    { id: 'sprints', label: 'Sprint Planning', icon: Calendar },
    { id: 'board', label: 'Scrum Board', icon: Kanban },
    { id: 'risks', label: 'Risks & Dependencies', icon: AlertTriangle },
    { id: 'decisions', label: 'Decisions & Approvals', icon: FileCheck },
    { id: 'assistant', label: 'AI Project Assistant', icon: Bot },
    { id: 'sprint-review', label: 'Sprint Review', icon: CheckCircle2 },
    { id: 'retrospective', label: 'Retrospective', icon: RotateCcw },
    { id: 'reports', label: 'Reports', icon: FileText },
    { id: 'settings', label: 'Project Settings', icon: Settings },
  ];

  if (!currentProject) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-stone-50 dark:bg-stone-950 p-6 text-center">
        <h2 className="text-lg font-bold text-stone-900 dark:text-stone-100">Project Not Found</h2>
        <p className="text-xs text-stone-500 mt-1">The requested project could not be loaded.</p>
        <Link
          to="/projects"
          className="mt-4 px-4 py-2 bg-teal-700 text-white text-xs font-semibold rounded-xl"
        >
          Return to Projects
        </Link>
      </div>
    );
  }

  const activeNavItem = navItems.find((n) => n.id === activeTab);

  return (
    <div className="flex h-screen bg-stone-50 dark:bg-stone-950 text-stone-900 dark:text-stone-100 overflow-hidden font-sans">
      
      {/* SIDEBAR NAVIGATION */}
      <aside
        className={`fixed lg:static inset-y-0 left-0 z-40 w-64 bg-white dark:bg-stone-900 border-r border-stone-200 dark:border-stone-800 flex flex-col transition-transform duration-200 ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Sidebar Header & Project Switcher */}
        <div className="p-4 border-b border-stone-100 dark:border-stone-800 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <Link to="/home" className="hover:opacity-85 transition-opacity">
              <Logo size="sm" />
            </Link>
            <button
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden p-1 text-stone-400 hover:text-stone-600 dark:hover:text-stone-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Project Switcher Dropdown */}
          <div className="relative">
            <select
              value={currentProject.id}
              onChange={(e) => handleProjectSwitch(e.target.value)}
              className="w-full py-1.5 pl-2.5 pr-7 text-xs font-semibold rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-950 text-stone-900 dark:text-stone-100 focus:outline-none focus:ring-1 focus:ring-teal-700 appearance-none truncate cursor-pointer"
            >
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3.5 h-3.5 text-stone-400 absolute right-2.5 top-2.5 pointer-events-none" />
          </div>
        </div>

        {/* Navigation Sections */}
        <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-1">
          <p className="text-[10px] uppercase font-bold tracking-wider text-stone-400 px-2 mb-1.5">
            Agile Workspace
          </p>
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleTabChange(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2 text-xs font-semibold rounded-xl transition-all ${
                  isActive
                    ? 'bg-teal-50 dark:bg-teal-950/70 text-teal-900 dark:text-teal-200 shadow-2xs font-bold'
                    : 'text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800/60 hover:text-stone-900 dark:hover:text-stone-100'
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive ? 'text-teal-700 dark:text-teal-400' : 'text-stone-400'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                </div>
                {item.id === 'assistant' && (
                  <Sparkles className="w-3 h-3 text-amber-500 shrink-0" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Sidebar Footer */}
        <div className="p-3 border-t border-stone-100 dark:border-stone-800 space-y-1">
          <Link
            to="/projects"
            className="w-full flex items-center gap-2 py-2 px-3 text-xs font-semibold text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-xl transition-colors"
          >
            <ArrowLeft className="w-4 h-4 text-stone-400" />
            <span>Back to All Projects</span>
          </Link>
          <Link
            to="/requirements"
            className="w-full flex items-center gap-2 py-2 px-3 text-xs font-semibold text-teal-700 dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-teal-950/40 rounded-xl transition-colors"
          >
            <Bot className="w-4 h-4" />
            <span>AI Requirements Chat</span>
          </Link>
        </div>
      </aside>

      {/* MAIN VIEWPORT */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        <GuestBanner />

        {/* Top Workspace Header Bar */}
        <header className="px-6 py-3.5 border-b border-stone-200/80 dark:border-stone-800/80 bg-white/70 dark:bg-stone-900/60 backdrop-blur-xs flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-1.5 text-stone-500 hover:text-stone-700 rounded-lg"
              aria-label="Toggle menu"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Breadcrumbs */}
            <Breadcrumbs
              items={[
                { label: 'Projects', path: '/projects' },
                { label: currentProject.name, path: `/projects/${currentProject.id}/overview` },
                { label: activeNavItem?.label || 'Overview' },
              ]}
            />
          </div>

          <div className="flex items-center gap-3">
            <StatusPill status={currentProject.status} size="sm" />
          </div>
        </header>

        {/* Main Section Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8">
          <div className="max-w-7xl mx-auto">
            {activeTab === 'overview' && (
              <OverviewView onNavigateTab={(tab) => handleTabChange(tab as WorkspaceTab)} />
            )}
            {activeTab === 'backlog' && <BacklogView />}
            {activeTab === 'sprints' && (
              <SprintPlanningView onNavigateToBoard={() => handleTabChange('board')} />
            )}
            {activeTab === 'board' && (
              <ScrumBoardView onNavigateToSprintPlanning={() => handleTabChange('sprints')} />
            )}
            {activeTab === 'risks' && <RisksDependenciesView />}
            {activeTab === 'decisions' && <DecisionsApprovalsView />}
            {activeTab === 'assistant' && <ProjectAssistantView />}
            {activeTab === 'sprint-review' && <SprintReviewView />}
            {activeTab === 'retrospective' && (
              <RetrospectiveView onNavigateToSprintPlanning={() => handleTabChange('sprints')} />
            )}
            {activeTab === 'reports' && <ReportsView />}
            {activeTab === 'settings' && <ProjectSettingsView />}
          </div>
        </main>
      </div>

    </div>
  );
};
