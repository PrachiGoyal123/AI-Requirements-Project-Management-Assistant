import React from 'react';
import { Link } from 'react-router-dom';
import { Logo } from '../components/common/Logo';
import { ArrowLeft, Compass } from 'lucide-react';

export const NotFoundPage: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-stone-50 dark:bg-stone-950 text-stone-900 dark:text-stone-100 p-6 text-center">
      <Logo size="lg" className="mb-6" />
      <div className="w-12 h-12 rounded-2xl bg-stone-100 dark:bg-stone-800 text-stone-400 flex items-center justify-center mb-4">
        <Compass className="w-6 h-6" />
      </div>
      <h1 className="text-3xl font-extrabold tracking-tight">404 - Page Not Found</h1>
      <p className="text-xs text-stone-500 dark:text-stone-400 max-w-sm mt-2 leading-relaxed">
        The requested agile workspace route or document does not exist.
      </p>
      <div className="mt-6 flex items-center gap-3">
        <Link
          to="/home"
          className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-xl shadow-xs transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Return to Workspace Hub</span>
        </Link>
      </div>
    </div>
  );
};
