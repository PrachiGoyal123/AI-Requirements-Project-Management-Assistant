import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../store/AppContext';
import { Logo } from '../components/common/Logo';
import { ThemeToggle } from '../components/common/ThemeToggle';
import { isSupabaseConfigured } from '../lib/supabaseClient';
import { authService } from '../services/authService';
import { 
  Sparkles, 
  Layers, 
  ShieldCheck, 
  ArrowRight, 
  Lock, 
  Mail, 
  User as UserIcon,
  Bot,
  AlertCircle,
  CheckCircle2,
  KeyRound
} from 'lucide-react';

export const WelcomePage: React.FC = () => {
  const navigate = useNavigate();
  const { signIn, register, signInWithGoogle, continueAsGuest, addToast } = useApp();

  const [isSignUp, setIsSignUp] = useState(false);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [confirmationNotice, setConfirmationNotice] = useState<string | null>(null);

  // Validation errors
  const [errors, setErrors] = useState<{
    email?: string;
    password?: string;
    confirmPassword?: string;
    name?: string;
  }>({});

  const validate = () => {
    const errs: typeof errors = {};
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!email.trim()) {
      errs.email = 'Email address is required.';
    } else if (!emailRegex.test(email)) {
      errs.email = 'Please enter a valid email address.';
    }

    if (!isForgotPassword) {
      if (!password) {
        errs.password = 'Password is required.';
      } else if (password.length < 6) {
        errs.password = 'Password must be at least 6 characters.';
      }

      if (isSignUp) {
        if (!name.trim()) {
          errs.name = 'Full name is required.';
        }
        if (password !== confirmPassword) {
          errs.confirmPassword = 'Passwords do not match.';
        }
      }
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setConfirmationNotice(null);
    if (!validate()) return;

    setIsLoading(true);
    try {
      if (isForgotPassword) {
        await authService.resetPasswordForEmail(email.trim());
        setConfirmationNotice(`Password reset instructions sent to ${email.trim()}. Please check your inbox.`);
        addToast({ title: 'Reset Link Sent', message: `Check ${email} for instructions`, type: 'info' });
      } else if (isSignUp) {
        const { requiresEmailConfirmation } = await register(email.trim(), password, name.trim());
        if (requiresEmailConfirmation) {
          setConfirmationNotice(
            'Check your email to confirm your account! We sent a verification link to your inbox.'
          );
        } else {
          navigate('/home');
        }
      } else {
        await signIn(email.trim(), password);
        navigate('/home');
      }
    } catch (err: any) {
      setAuthError(err.message || 'Authentication failed. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setAuthError(null);
    setIsLoading(true);
    try {
      await signInWithGoogle();
    } catch (err: any) {
      setAuthError(err.message || 'Could not initiate Google authentication.');
      setIsLoading(false);
    }
  };

  const handleGuest = () => {
    continueAsGuest();
    navigate('/home');
  };

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 dark:bg-stone-950 text-stone-900 dark:text-stone-100 transition-colors">
      {/* Top minimal bar */}
      <header className="px-6 py-4 flex items-center justify-between border-b border-stone-200/80 dark:border-stone-800/80 bg-white/50 dark:bg-stone-900/40 backdrop-blur-xs">
        <Logo size="md" />
        <div className="flex items-center gap-3">
          <ThemeToggle />
        </div>
      </header>

      {/* Supabase Missing Notice (if misconfigured) */}
      {!isSupabaseConfigured && (
        <div className="bg-rose-50 dark:bg-rose-950/70 border-b border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 px-4 py-3 text-xs">
          <div className="max-w-7xl mx-auto flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 dark:text-rose-400" />
            <span>
              <strong>Supabase environment variables missing.</strong> Please ensure <code>VITE_SUPABASE_URL</code> and <code>VITE_SUPABASE_PUBLISHABLE_KEY</code> are set. You can still test as Guest.
            </span>
          </div>
        </div>
      )}

      {/* Split Hero & Auth Body */}
      <main className="flex-1 flex flex-col lg:flex-row max-w-7xl w-full mx-auto p-6 sm:p-10 lg:p-12 items-center justify-center gap-12 lg:gap-16">
        
        {/* Left Side: Product Identity & Value Props */}
        <div className="flex-1 max-w-xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-teal-50 dark:bg-teal-950/60 border border-teal-200/60 dark:border-teal-800/60 text-teal-800 dark:text-teal-300 text-xs font-semibold mb-6">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Autonomous Agile Architecture &amp; Delivery</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight font-sans text-stone-900 dark:text-stone-50 leading-[1.15]">
            AI Requirements &amp; Project Management Assistant
          </h1>

          <p className="mt-4 text-base sm:text-lg text-stone-600 dark:text-stone-400 leading-relaxed">
            Bridge the gap between raw business requirements and sprint execution. 
            Transform unstructured stakeholder documents into structured user stories, acceptance criteria, 
            interactive scrum boards, and data-grounded project intelligence.
          </p>

          {/* Feature Highlights Grid */}
          <div className="mt-8 space-y-4">
            <div className="flex items-start gap-3.5 p-3.5 rounded-xl bg-white dark:bg-stone-900/80 border border-stone-200/80 dark:border-stone-800 shadow-xs">
              <div className="p-2 rounded-lg bg-teal-50 dark:bg-teal-950/80 text-teal-700 dark:text-teal-400 shrink-0">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-sm font-semibold text-stone-900 dark:text-stone-100">
                  AI Requirement Analysis &amp; Voice Input
                </h2>
                <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5 leading-relaxed">
                  Synthesize functional specifications, identify open edge-case questions, and upload requirement files with zero cloud lock-in.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3.5 p-3.5 rounded-xl bg-white dark:bg-stone-900/80 border border-stone-200/80 dark:border-stone-800 shadow-xs">
              <div className="p-2 rounded-lg bg-teal-50 dark:bg-teal-950/80 text-teal-700 dark:text-teal-400 shrink-0">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-sm font-semibold text-stone-900 dark:text-stone-100">
                  Live Agile Scrum Workspaces
                </h2>
                <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5 leading-relaxed">
                  Backlog estimation, sprint planning with velocity matching, drag-and-drop scrum columns, and auto-calculated health telemetry.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3.5 p-3.5 rounded-xl bg-white dark:bg-stone-900/80 border border-stone-200/80 dark:border-stone-800 shadow-xs">
              <div className="p-2 rounded-lg bg-teal-50 dark:bg-teal-950/80 text-teal-700 dark:text-teal-400 shrink-0">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-sm font-semibold text-stone-900 dark:text-stone-100">
                  Risks, Decisions &amp; Follow-Up Automation
                </h2>
                <p className="text-xs text-stone-500 dark:text-stone-400 mt-0.5 leading-relaxed">
                  Assess schedule impacts, highlight overdue client decisions, and draft professional communication drafts with one click.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Auth Card */}
        <div className="w-full max-w-md">
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-7 sm:p-8 shadow-xl shadow-stone-200/50 dark:shadow-none transition-all">
            <div className="mb-6">
              <h2 className="text-xl font-bold text-stone-900 dark:text-stone-100">
                {isForgotPassword
                  ? 'Reset your password'
                  : isSignUp
                  ? 'Create your account'
                  : 'Welcome back'}
              </h2>
              <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
                {isForgotPassword
                  ? 'Enter your email to receive recovery instructions'
                  : isSignUp
                  ? 'Join AgileMind to manage agile product sprints'
                  : 'Sign in to access your projects and sprint boards'}
              </p>
            </div>

            {/* Error Message Box */}
            {authError && (
              <div className="mb-5 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/80 border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-200 text-xs flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <p className="leading-relaxed">{authError}</p>
              </div>
            )}

            {/* Confirmation Banner */}
            {confirmationNotice && (
              <div className="mb-5 p-3 rounded-xl bg-teal-50 dark:bg-teal-950/80 border border-teal-200 dark:border-teal-800 text-teal-800 dark:text-teal-200 text-xs flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <p className="leading-relaxed">{confirmationNotice}</p>
              </div>
            )}

            {!isForgotPassword && (
              <>
                {/* Google Sign In */}
                <button
                  type="button"
                  onClick={handleGoogleSignIn}
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-3 py-2.5 px-4 rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-800/60 hover:bg-stone-100 dark:hover:bg-stone-800 text-stone-700 dark:text-stone-200 text-xs font-semibold shadow-xs transition-colors"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17Z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24Z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15Z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98Z"
                    />
                  </svg>
                  <span>Sign in with Google</span>
                </button>

                {/* Divider */}
                <div className="relative my-5">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-stone-200 dark:border-stone-800" />
                  </div>
                  <div className="relative flex justify-center text-xs">
                    <span className="px-3 bg-white dark:bg-stone-900 text-stone-400 font-medium">or</span>
                  </div>
                </div>
              </>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              {isSignUp && !isForgotPassword && (
                <div>
                  <label className="block text-xs font-medium text-stone-700 dark:text-stone-300 mb-1">
                    Full Name
                  </label>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Alex Morgan"
                      className={`w-full pl-9 pr-3 py-2 text-xs rounded-xl border bg-stone-50/50 dark:bg-stone-950 dark:text-stone-100 transition-colors focus:outline-none focus:ring-2 focus:ring-teal-700 ${
                        errors.name ? 'border-rose-400 ring-rose-200' : 'border-stone-200 dark:border-stone-700'
                      }`}
                    />
                  </div>
                  {errors.name && (
                    <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1">{errors.name}</p>
                  )}
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-stone-700 dark:text-stone-300 mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="alex.morgan@company.io"
                    className={`w-full pl-9 pr-3 py-2 text-xs rounded-xl border bg-stone-50/50 dark:bg-stone-950 dark:text-stone-100 transition-colors focus:outline-none focus:ring-2 focus:ring-teal-700 ${
                      errors.email ? 'border-rose-400 ring-rose-200' : 'border-stone-200 dark:border-stone-700'
                    }`}
                  />
                </div>
                {errors.email && (
                  <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1">{errors.email}</p>
                )}
              </div>

              {!isForgotPassword && (
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-medium text-stone-700 dark:text-stone-300">
                      Password
                    </label>
                    {!isSignUp && (
                      <button
                        type="button"
                        onClick={() => {
                          setIsForgotPassword(true);
                          setAuthError(null);
                        }}
                        className="text-[11px] text-teal-700 dark:text-teal-400 hover:underline"
                      >
                        Forgot password?
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                    <input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className={`w-full pl-9 pr-3 py-2 text-xs rounded-xl border bg-stone-50/50 dark:bg-stone-950 dark:text-stone-100 transition-colors focus:outline-none focus:ring-2 focus:ring-teal-700 ${
                        errors.password ? 'border-rose-400 ring-rose-200' : 'border-stone-200 dark:border-stone-700'
                      }`}
                    />
                  </div>
                  {errors.password && (
                    <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1">{errors.password}</p>
                  )}
                </div>
              )}

              {isSignUp && !isForgotPassword && (
                <div>
                  <label className="block text-xs font-medium text-stone-700 dark:text-stone-300 mb-1">
                    Confirm Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                    <input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="••••••••"
                      className={`w-full pl-9 pr-3 py-2 text-xs rounded-xl border bg-stone-50/50 dark:bg-stone-950 dark:text-stone-100 transition-colors focus:outline-none focus:ring-2 focus:ring-teal-700 ${
                        errors.confirmPassword
                          ? 'border-rose-400 ring-rose-200'
                          : 'border-stone-200 dark:border-stone-700'
                      }`}
                    />
                  </div>
                  {errors.confirmPassword && (
                    <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1">
                      {errors.confirmPassword}
                    </p>
                  )}
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 active:bg-teal-900 shadow-sm transition-colors mt-2"
              >
                <span>
                  {isForgotPassword
                    ? 'Send Reset Link'
                    : isSignUp
                    ? 'Create account'
                    : 'Sign in'}
                </span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>

            {/* Toggle sign in / sign up / forgot */}
            <div className="mt-4 text-center">
              {isForgotPassword ? (
                <button
                  type="button"
                  onClick={() => {
                    setIsForgotPassword(false);
                    setAuthError(null);
                    setConfirmationNotice(null);
                  }}
                  className="text-xs text-teal-700 dark:text-teal-400 hover:underline"
                >
                  &larr; Back to sign in
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setIsSignUp(!isSignUp);
                    setErrors({});
                    setAuthError(null);
                    setConfirmationNotice(null);
                  }}
                  className="text-xs text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200 transition-colors"
                >
                  {isSignUp ? (
                    <span>
                      Already have an account? <strong className="text-teal-700 dark:text-teal-400">Sign in</strong>
                    </span>
                  ) : (
                    <span>
                      New user? <strong className="text-teal-700 dark:text-teal-400">Create account</strong>
                    </span>
                  )}
                </button>
              )}
            </div>

            {/* Continue as Guest Button */}
            <div className="mt-5 pt-4 border-t border-stone-100 dark:border-stone-800">
              <button
                type="button"
                onClick={handleGuest}
                className="w-full py-2 px-3 text-xs font-medium text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 bg-stone-100/80 dark:bg-stone-800/60 hover:bg-stone-200 dark:hover:bg-stone-800 rounded-xl transition-colors"
              >
                Continue as Guest &rarr;
              </button>
              <p className="text-[11px] text-center text-stone-400 dark:text-stone-500 mt-2">
                In-memory mode · Resets on page reload · Does not modify Supabase
              </p>
            </div>
          </div>
        </div>

      </main>

      {/* Footer */}
      <footer className="px-6 py-4 text-center text-xs text-stone-400 dark:text-stone-500 border-t border-stone-200/60 dark:border-stone-800/60">
        AI Requirements &amp; Project Management Assistant · Built with React, TypeScript &amp; Supabase
      </footer>
    </div>
  );
};
