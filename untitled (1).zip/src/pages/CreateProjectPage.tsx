import React, { useState, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useApp } from '../store/AppContext';
import { Logo } from '../components/common/Logo';
import { ThemeToggle } from '../components/common/ThemeToggle';
import { ProjectType, TeamMember, ProjectDocument } from '../types/project';
import { aiClient, AiClientError, AiProjectAnalysisResult } from '../services/ai/aiClient';
import { validateFile, formatFileSize } from '../lib/fileValidation';
import { 
  ArrowLeft, 
  Sparkles, 
  Plus, 
  Trash2, 
  Upload, 
  FileText, 
  Check, 
  AlertCircle,
  HelpCircle,
  Bot,
  Loader2,
  RotateCw
} from 'lucide-react';

export const CreateProjectPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, isGuest, createProject, addProjectDocument, addToast } = useApp();

  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [goal, setGoal] = useState('');
  const [startDate, setStartDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() + 45);
    return d.toISOString().split('T')[0];
  });
  const [projectType, setProjectType] = useState<ProjectType>('Agile Scrum');
  const [projectManager, setProjectManager] = useState('Alex Morgan');

  // Team members list
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([
    { id: 'tm-initial-1', name: 'Alex Morgan', email: 'alex.m@company.io', role: 'Project Manager', avatarInitials: 'AM' },
    { id: 'tm-initial-2', name: 'Sofia Chen', email: 'sofia.c@company.io', role: 'Lead UI/UX Designer', avatarInitials: 'SC' },
  ]);
  const [newMemberName, setNewMemberName] = useState('');
  const [newMemberEmail, setNewMemberEmail] = useState('');
  const [newMemberRole, setNewMemberRole] = useState('Frontend Engineer');

  // Uploaded documents
  const [documents, setDocuments] = useState<ProjectDocument[]>([]);
  const [attachedRawFiles, setAttachedRawFiles] = useState<{ id: string; file: File }[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // AI Analysis Section State
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState<AiProjectAnalysisResult | null>(null);

  // Validation
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!name.trim()) errs.name = 'Project Name is mandatory.';
    if (!description.trim()) errs.description = 'Description is mandatory.';
    if (!goal.trim()) errs.goal = 'Project Goal is mandatory.';
    if (!startDate) errs.startDate = 'Start Date is mandatory.';
    if (!endDate) errs.endDate = 'End/Target Date is mandatory.';
    if (startDate && endDate && new Date(endDate) <= new Date(startDate)) {
      errs.endDate = 'End/Target Date must be after the Start Date.';
    }
    if (!projectManager.trim()) errs.projectManager = 'Project Manager is mandatory.';
    if (teamMembers.length === 0) errs.teamMembers = 'At least one team member must be added.';

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleAddMember = () => {
    if (!newMemberName.trim() || !newMemberEmail.trim()) {
      addToast({ title: 'Member Info Incomplete', message: 'Please provide both name and email.', type: 'warning' });
      return;
    }

    const initials = newMemberName
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2) || 'TM';

    const member: TeamMember = {
      id: `tm-${Date.now().toString(36)}`,
      name: newMemberName.trim(),
      email: newMemberEmail.trim(),
      role: newMemberRole,
      avatarInitials: initials,
    };

    setTeamMembers((prev) => [...prev, member]);
    setNewMemberName('');
    setNewMemberEmail('');
  };

  const handleRemoveMember = (id: string) => {
    setTeamMembers((prev) => prev.filter((m) => m.id !== id));
  };

  const handleFiles = (files: FileList | null) => {
    if (!files) return;
    const newDocs: ProjectDocument[] = [];
    const newRaw: { id: string; file: File }[] = [];

    Array.from(files).forEach((file) => {
      const validation = validateFile(file);
      if (!validation.valid) {
        addToast({
          title: 'File Rejected',
          message: validation.error || 'Invalid file format or size.',
          type: 'error',
        });
        return;
      }

      const id = `doc-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 5)}`;
      newDocs.push({
        id,
        name: file.name,
        size: formatFileSize(file.size),
        uploadedAt: new Date().toISOString().split('T')[0],
        type: file.type || 'document',
        fileSize: file.size,
        mimeType: file.type,
      });
      newRaw.push({ id, file });
    });

    if (newDocs.length > 0) {
      setDocuments((prev) => [...prev, ...newDocs]);
      setAttachedRawFiles((prev) => [...prev, ...newRaw]);
    }
  };

  const handleRemoveDoc = (id: string) => {
    setDocuments((prev) => prev.filter((d) => d.id !== id));
    setAttachedRawFiles((prev) => prev.filter((r) => r.id !== id));
  };

  const [analysisError, setAnalysisError] = useState<string | null>(null);

  const handleAnalyzeWithAi = async () => {
    if (!name.trim()) {
      addToast({ title: 'Enter Project Name first', message: 'AI needs a project name to analyze.', type: 'warning' });
      return;
    }
    setIsAnalyzing(true);
    setAnalysisError(null);
    try {
      const result = await aiClient.analyzeProjectCreation(name, goal, projectType);
      setAiSuggestions(result);
      addToast({ title: 'AI Analysis Complete', message: 'Review suggested goals and checklist.', type: 'success' });
    } catch (err: any) {
      const msg = err instanceof AiClientError ? err.message : (err?.message || 'AI analysis failed.');
      setAnalysisError(msg);
      addToast({ title: 'Analysis Error', message: msg, type: 'error' });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleAcceptAiGoal = () => {
    if (aiSuggestions?.improvedGoal) {
      setGoal(aiSuggestions.improvedGoal);
      addToast({ title: 'Goal Applied', message: 'AI refined goal accepted.', type: 'info' });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) {
      addToast({ title: 'Missing Mandatory Fields', message: 'Please fix highlighted errors.', type: 'error' });
      return;
    }

    setIsSubmitting(true);
    try {
      const created = createProject({
        name: name.trim(),
        description: description.trim(),
        goal: goal.trim(),
        startDate,
        endDate,
        projectType,
        projectManager: projectManager.trim(),
        teamMembers,
        documents: isGuest ? documents : [],
      });

      // Upload documents to {user_id}/projects/{project_id}/{timestamp}-{sanitized_file_name}
      // and insert rows in project_documents
      if (user && !isGuest && attachedRawFiles.length > 0) {
        for (const item of attachedRawFiles) {
          try {
            await addProjectDocument(created.id, item.file);
          } catch (uploadErr: any) {
            console.error('Failed to upload project document:', uploadErr);
            addToast({
              title: 'Document Upload Warning',
              message: `Could not upload "${item.file.name}": ${uploadErr.message}`,
              type: 'warning',
            });
          }
        }
      }

      navigate(`/projects/${created.id}/overview`);
    } catch (err: any) {
      console.error('Project creation failed:', err);
      addToast({ title: 'Creation Error', message: err.message, type: 'error' });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 dark:bg-stone-950 text-stone-900 dark:text-stone-100 transition-colors">
      {/* Top Header */}
      <header className="px-6 py-4 flex items-center justify-between border-b border-stone-200/80 dark:border-stone-800/80 bg-white/70 dark:bg-stone-900/60 backdrop-blur-xs sticky top-0 z-20">
        <div className="flex items-center gap-4">
          <Link to="/home" className="hover:opacity-85 transition-opacity">
            <Logo size="md" />
          </Link>
          <div className="hidden sm:flex items-center gap-1.5 text-xs text-stone-400 pl-4 border-l border-stone-200 dark:border-stone-800">
            <Link to="/projects" className="hover:text-stone-700 dark:hover:text-stone-200">
              Projects
            </Link>
            <span>/</span>
            <span className="font-semibold text-stone-800 dark:text-stone-200">Create New Project</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <ThemeToggle />
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-4xl w-full mx-auto p-6 sm:p-10">
        <Link
          to="/projects"
          className="inline-flex items-center gap-1.5 text-xs font-medium text-stone-500 hover:text-stone-900 dark:hover:text-stone-100 mb-6 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to Projects</span>
        </Link>

        <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl shadow-sm p-6 sm:p-10">
          <div className="pb-6 border-b border-stone-100 dark:border-stone-800 mb-8">
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-900 dark:text-stone-100">
              Create Project Workspace
            </h1>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
              Initialize a project workspace with team roles, milestone dates, and AI-assisted goal refinement. All fields are mandatory.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            
            {/* Section 1: Basic Information */}
            <div className="space-y-4">
              <h2 className="text-xs font-bold uppercase tracking-wider text-teal-800 dark:text-teal-400">
                1. Project Definition
              </h2>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Project Name *
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. NextGen Mobile Banking Platform"
                    className={`w-full px-3.5 py-2 text-xs rounded-xl border bg-stone-50/50 dark:bg-stone-950 dark:text-stone-100 focus:outline-none focus:ring-2 focus:ring-teal-700 ${
                      errors.name ? 'border-rose-400 ring-rose-200' : 'border-stone-200 dark:border-stone-700'
                    }`}
                  />
                  {errors.name && <p className="text-[11px] text-rose-600 mt-1">{errors.name}</p>}
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Project Description *
                  </label>
                  <textarea
                    rows={2}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Brief description of the product scope, target market, and operational boundaries..."
                    className={`w-full px-3.5 py-2 text-xs rounded-xl border bg-stone-50/50 dark:bg-stone-950 dark:text-stone-100 focus:outline-none focus:ring-2 focus:ring-teal-700 ${
                      errors.description ? 'border-rose-400 ring-rose-200' : 'border-stone-200 dark:border-stone-700'
                    }`}
                  />
                  {errors.description && <p className="text-[11px] text-rose-600 mt-1">{errors.description}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Project Type *
                  </label>
                  <select
                    value={projectType}
                    onChange={(e) => setProjectType(e.target.value as ProjectType)}
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-stone-200 dark:border-stone-700 bg-stone-50/50 dark:bg-stone-950 dark:text-stone-100 focus:outline-none focus:ring-2 focus:ring-teal-700"
                  >
                    <option value="Agile Scrum">Agile Scrum</option>
                    <option value="Kanban Delivery">Kanban Delivery</option>
                    <option value="Product Discovery">Product Discovery</option>
                    <option value="Enterprise Migration">Enterprise Migration</option>
                    <option value="MVP Launch">MVP Launch</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Project Manager *
                  </label>
                  <input
                    type="text"
                    value={projectManager}
                    onChange={(e) => setProjectManager(e.target.value)}
                    placeholder="Alex Morgan"
                    className={`w-full px-3.5 py-2 text-xs rounded-xl border bg-stone-50/50 dark:bg-stone-950 dark:text-stone-100 focus:outline-none focus:ring-2 focus:ring-teal-700 ${
                      errors.projectManager ? 'border-rose-400' : 'border-stone-200 dark:border-stone-700'
                    }`}
                  />
                  {errors.projectManager && <p className="text-[11px] text-rose-600 mt-1">{errors.projectManager}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    Start Date *
                  </label>
                  <input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className={`w-full px-3.5 py-2 text-xs rounded-xl border bg-stone-50/50 dark:bg-stone-950 dark:text-stone-100 focus:outline-none focus:ring-2 focus:ring-teal-700 ${
                      errors.startDate ? 'border-rose-400' : 'border-stone-200 dark:border-stone-700'
                    }`}
                  />
                  {errors.startDate && <p className="text-[11px] text-rose-600 mt-1">{errors.startDate}</p>}
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                    End / Target Date *
                  </label>
                  <input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className={`w-full px-3.5 py-2 text-xs rounded-xl border bg-stone-50/50 dark:bg-stone-950 dark:text-stone-100 focus:outline-none focus:ring-2 focus:ring-teal-700 ${
                      errors.endDate ? 'border-rose-400' : 'border-stone-200 dark:border-stone-700'
                    }`}
                  />
                  {errors.endDate && <p className="text-[11px] text-rose-600 mt-1">{errors.endDate}</p>}
                </div>
              </div>
            </div>

            {/* Section 2: Project Goal & AI Analysis Section */}
            <div className="space-y-4 pt-6 border-t border-stone-100 dark:border-stone-800">
              <div className="flex items-center justify-between">
                <h2 className="text-xs font-bold uppercase tracking-wider text-teal-800 dark:text-teal-400">
                  2. Project Goal &amp; AI Analysis
                </h2>
                <button
                  type="button"
                  onClick={handleAnalyzeWithAi}
                  disabled={isAnalyzing}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-teal-800 dark:text-teal-300 bg-teal-50 dark:bg-teal-950/70 border border-teal-200 dark:border-teal-800 hover:bg-teal-100 dark:hover:bg-teal-900 rounded-xl transition-colors shadow-2xs"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>{isAnalyzing ? 'Analyzing with AI...' : 'Analyze with AI'}</span>
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 dark:text-stone-300 mb-1">
                  Primary Project Goal *
                </label>
                <textarea
                  rows={2}
                  value={goal}
                  onChange={(e) => setGoal(e.target.value)}
                  placeholder="Define the core value proposition and tangible outcome expected upon completion..."
                  className={`w-full px-3.5 py-2 text-xs rounded-xl border bg-stone-50/50 dark:bg-stone-950 dark:text-stone-100 focus:outline-none focus:ring-2 focus:ring-teal-700 ${
                    errors.goal ? 'border-rose-400' : 'border-stone-200 dark:border-stone-700'
                  }`}
                />
                {errors.goal && <p className="text-[11px] text-rose-600 mt-1">{errors.goal}</p>}
              </div>

              {/* AI Analysis Error Panel with Retry */}
              {analysisError && (
                <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-xs flex items-center justify-between gap-3 animate-in fade-in">
                  <div className="flex items-center gap-2 text-rose-800 dark:text-rose-200">
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 dark:text-rose-400" />
                    <span>{analysisError}</span>
                  </div>
                  <button
                    type="button"
                    onClick={handleAnalyzeWithAi}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-lg shadow-2xs transition-colors shrink-0"
                  >
                    <RotateCw className="w-3 h-3" />
                    <span>Retry</span>
                  </button>
                </div>
              )}

              {/* AI Analysis Result Panel */}
              {aiSuggestions && (
                <div className="p-4 rounded-xl bg-teal-50/60 dark:bg-teal-950/40 border border-teal-200/80 dark:border-teal-800/80 space-y-3 animate-in fade-in">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2 text-xs font-bold text-teal-900 dark:text-teal-200">
                      <Bot className="w-4 h-4 text-teal-700 dark:text-teal-400" />
                      <span>AI Suggested Improved Goal</span>
                    </div>
                    <button
                      type="button"
                      onClick={handleAcceptAiGoal}
                      className="px-2.5 py-1 text-[11px] font-semibold text-white bg-teal-700 hover:bg-teal-800 rounded-lg transition-colors shadow-2xs"
                    >
                      Accept Goal
                    </button>
                  </div>
                  <p className="text-xs text-stone-700 dark:text-stone-300 italic bg-white/70 dark:bg-stone-900/60 p-2.5 rounded-lg border border-teal-100 dark:border-teal-900">
                    &quot;{aiSuggestions.improvedGoal}&quot;
                  </p>

                  <div className="pt-2">
                    <p className="text-xs font-semibold text-stone-800 dark:text-stone-200 mb-1.5 flex items-center gap-1.5">
                      <HelpCircle className="w-3.5 h-3.5 text-amber-500" />
                      <span>Missing Information Checklist:</span>
                    </p>
                    <ul className="space-y-1 pl-4 list-disc text-[11px] text-stone-600 dark:text-stone-400">
                      {aiSuggestions.missingInformationChecklist.map((item, idx) => (
                        <li key={idx}>{item}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>

            {/* Section 3: Team Members */}
            <div className="space-y-4 pt-6 border-t border-stone-100 dark:border-stone-800">
              <h2 className="text-xs font-bold uppercase tracking-wider text-teal-800 dark:text-teal-400">
                3. Team Members *
              </h2>

              {/* Current team list */}
              <div className="space-y-2">
                {teamMembers.map((tm) => (
                  <div
                    key={tm.id}
                    className="flex items-center justify-between p-2.5 rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-950 text-xs"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-full bg-teal-700 text-white font-bold text-[10px] flex items-center justify-center">
                        {tm.avatarInitials}
                      </div>
                      <div>
                        <p className="font-semibold text-stone-900 dark:text-stone-100">{tm.name}</p>
                        <p className="text-[11px] text-stone-400">{tm.email} · {tm.role}</p>
                      </div>
                    </div>
                    {teamMembers.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveMember(tm.id)}
                        className="p-1 text-stone-400 hover:text-rose-600 transition-colors"
                        title="Remove member"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
              {errors.teamMembers && <p className="text-[11px] text-rose-600">{errors.teamMembers}</p>}

              {/* Add member inputs */}
              <div className="p-3 rounded-xl border border-dashed border-stone-200 dark:border-stone-800 bg-white/40 dark:bg-stone-900/40 grid grid-cols-1 sm:grid-cols-4 gap-2.5 items-end">
                <div>
                  <label className="block text-[11px] text-stone-500 mb-1">Name</label>
                  <input
                    type="text"
                    value={newMemberName}
                    onChange={(e) => setNewMemberName(e.target.value)}
                    placeholder="Priya Patel"
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-950"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-stone-500 mb-1">Email</label>
                  <input
                    type="email"
                    value={newMemberEmail}
                    onChange={(e) => setNewMemberEmail(e.target.value)}
                    placeholder="priya.p@company.io"
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-950"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-stone-500 mb-1">Role</label>
                  <select
                    value={newMemberRole}
                    onChange={(e) => setNewMemberRole(e.target.value)}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-950"
                  >
                    <option value="Frontend Engineer">Frontend Engineer</option>
                    <option value="Backend Engineer">Backend Engineer</option>
                    <option value="QA & Security Lead">QA &amp; Security Lead</option>
                    <option value="Product Designer">Product Designer</option>
                    <option value="Scrum Master">Scrum Master</option>
                  </select>
                </div>
                <button
                  type="button"
                  onClick={handleAddMember}
                  className="flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-teal-800 dark:text-teal-200 bg-teal-50 dark:bg-teal-950/70 border border-teal-200 dark:border-teal-800 hover:bg-teal-100 rounded-lg transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Member</span>
                </button>
              </div>
            </div>

            {/* Section 4: Drag & Drop Documents Upload */}
            <div className="space-y-4 pt-6 border-t border-stone-100 dark:border-stone-800">
              <h2 className="text-xs font-bold uppercase tracking-wider text-teal-800 dark:text-teal-400">
                4. Project Documents &amp; Specifications
              </h2>

              <input
                type="file"
                multiple
                ref={fileInputRef}
                onChange={(e) => handleFiles(e.target.files)}
                className="hidden"
              />

              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragging(true);
                }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setIsDragging(false);
                  handleFiles(e.dataTransfer.files);
                }}
                onClick={() => fileInputRef.current?.click()}
                className={`p-6 border-2 border-dashed rounded-2xl flex flex-col items-center justify-center text-center cursor-pointer transition-colors ${
                  isDragging
                    ? 'border-teal-600 bg-teal-50/50 dark:bg-teal-950/40'
                    : 'border-stone-200 dark:border-stone-800 hover:border-teal-500 bg-stone-50/30 dark:bg-stone-950/40'
                }`}
              >
                <Upload className="w-6 h-6 text-stone-400 mb-2" />
                <p className="text-xs font-medium text-stone-700 dark:text-stone-300">
                  Drop specification documents here, or <span className="text-teal-700 dark:text-teal-400 underline">browse</span>
                </p>
                <p className="text-[11px] text-stone-400 mt-0.5">PDF, DOCX, Markdown, or JSON specifications (UI preview only)</p>
              </div>

              {documents.length > 0 && (
                <div className="space-y-1.5">
                  {documents.map((doc) => (
                    <div
                      key={doc.id}
                      className="flex items-center justify-between p-2 rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <FileText className="w-4 h-4 text-teal-700 dark:text-teal-400" />
                        <span className="font-medium text-stone-800 dark:text-stone-200">{doc.name}</span>
                        <span className="text-stone-400 text-[10px]">({doc.size})</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleRemoveDoc(doc.id)}
                        className="text-stone-400 hover:text-rose-600 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Form Action Buttons */}
            <div className="pt-6 border-t border-stone-200 dark:border-stone-800 flex items-center justify-end gap-3">
              <button
                type="button"
                disabled={isSubmitting}
                onClick={() => navigate('/projects')}
                className="px-4 py-2 text-xs font-semibold text-stone-600 dark:text-stone-400 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-xl transition-colors disabled:opacity-40"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-6 py-2.5 text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 active:bg-teal-900 disabled:opacity-50 rounded-xl shadow-xs transition-colors flex items-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                    <span>Creating Workspace &amp; Uploading...</span>
                  </>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Create Workspace &amp; Open Overview</span>
                  </>
                )}
              </button>
            </div>

          </form>
        </div>
      </main>
    </div>
  );
};
