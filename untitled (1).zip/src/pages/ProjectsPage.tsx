import React, { useState, useMemo } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useApp } from '../store/AppContext';
import { Logo } from '../components/common/Logo';
import { ThemeToggle } from '../components/common/ThemeToggle';
import { GuestBanner } from '../components/common/GuestBanner';
import { StatusPill } from '../components/common/Badge';
import { EmptyState } from '../components/common/EmptyState';
import { 
  Plus, 
  Search, 
  LayoutGrid, 
  List, 
  Calendar, 
  Users, 
  CheckCircle2, 
  ArrowRight, 
  FolderKanban,
  Sparkles,
  ArrowLeft
} from 'lucide-react';

export const ProjectsPage: React.FC = () => {
  const navigate = useNavigate();
  const { projects, tasks, setCurrentProjectId } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filteredProjects = useMemo(() => {
    return projects.filter((project) => {
      if (project.isArchived) return false;
      const matchesSearch =
        project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        project.projectType.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesStatus = statusFilter === 'All' || project.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [projects, searchQuery, statusFilter]);

  const handleSelectProject = (projectId: string) => {
    setCurrentProjectId(projectId);
    navigate(`/projects/${projectId}/overview`);
  };

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 dark:bg-stone-950 text-stone-900 dark:text-stone-100 transition-colors">
      <GuestBanner />

      {/* Header */}
      <header className="px-6 py-4 flex items-center justify-between border-b border-stone-200/80 dark:border-stone-800/80 bg-white/70 dark:bg-stone-900/60 backdrop-blur-xs sticky top-0 z-20">
        <div className="flex items-center gap-4">
          <Link to="/home" className="hover:opacity-85 transition-opacity">
            <Logo size="md" />
          </Link>
          <div className="hidden sm:flex items-center gap-1.5 text-xs text-stone-400 pl-4 border-l border-stone-200 dark:border-stone-800">
            <Link to="/home" className="hover:text-stone-700 dark:hover:text-stone-200">
              Hub
            </Link>
            <span>/</span>
            <span className="font-semibold text-stone-800 dark:text-stone-200">Projects</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <Link
            to="/requirements"
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-teal-700 dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-teal-950/40 rounded-lg transition-colors border border-teal-200/70 dark:border-teal-800/70"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>AI Requirements</span>
          </Link>
          <ThemeToggle />
          <button
            onClick={() => navigate('/projects/new')}
            className="flex items-center gap-1.5 py-1.5 px-3.5 rounded-xl text-xs font-semibold text-white bg-teal-700 hover:bg-teal-800 shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Create Project</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-6 sm:p-8 lg:p-10">
        
        {/* Title Bar & Controls */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-stone-200/80 dark:border-stone-800/80">
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight text-stone-900 dark:text-stone-50">
              Projects &amp; Workspaces
            </h1>
            <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
              Select an active workspace to track sprints, manage user stories, and triage risks.
            </p>
          </div>

          {/* Search, Filter & View Toggle */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Search */}
            <div className="relative min-w-[200px]">
              <Search className="w-3.5 h-3.5 text-stone-400 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search projects..."
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-teal-700"
              />
            </div>

            {/* Status Filter */}
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="py-1.5 px-3 text-xs rounded-xl border border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 text-stone-700 dark:text-stone-300 focus:outline-none focus:ring-2 focus:ring-teal-700"
            >
              <option value="All">All Statuses</option>
              <option value="On Track">On Track</option>
              <option value="At Risk">At Risk</option>
              <option value="Delayed">Delayed</option>
            </select>

            {/* Grid / List Toggle */}
            <div className="flex items-center p-0.5 rounded-lg border border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900">
              <button
                type="button"
                onClick={() => setViewMode('grid')}
                className={`p-1.5 rounded-md text-xs transition-colors ${
                  viewMode === 'grid'
                    ? 'bg-stone-100 dark:bg-stone-800 text-stone-900 dark:text-stone-100'
                    : 'text-stone-400 hover:text-stone-600'
                }`}
                title="Grid view"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setViewMode('list')}
                className={`p-1.5 rounded-md text-xs transition-colors ${
                  viewMode === 'list'
                    ? 'bg-stone-100 dark:bg-stone-800 text-stone-900 dark:text-stone-100'
                    : 'text-stone-400 hover:text-stone-600'
                }`}
                title="List view"
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Projects Display */}
        <div className="mt-8">
          {filteredProjects.length === 0 ? (
            <EmptyState
              icon={FolderKanban}
              title="No projects match your filter"
              description="Adjust your search criteria or create a new project workspace."
              actionLabel="Create Project"
              onAction={() => navigate('/projects/new')}
            />
          ) : viewMode === 'grid' ? (
            /* Grid View */
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProjects.map((project) => {
                const projectTs = tasks.filter((t) => t.projectId === project.id);
                const doneCount = projectTs.filter((t) => t.status === 'Done').length;
                const totalCount = projectTs.length;
                const progressPct = totalCount > 0 ? Math.round((doneCount / totalCount) * 100) : 0;

                return (
                  <div
                    key={project.id}
                    onClick={() => handleSelectProject(project.id)}
                    className="group flex flex-col p-6 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200/90 dark:border-stone-800 hover:border-teal-600 dark:hover:border-teal-500 shadow-xs hover:shadow-lg transition-all duration-200 cursor-pointer"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <span className="text-[10px] font-semibold tracking-wider uppercase text-teal-700 dark:text-teal-400">
                          {project.projectType}
                        </span>
                        <h2 className="text-base font-bold text-stone-900 dark:text-stone-100 group-hover:text-teal-700 dark:group-hover:text-teal-400 transition-colors mt-0.5">
                          {project.name}
                        </h2>
                      </div>
                      <StatusPill status={project.status} />
                    </div>

                    <p className="text-xs text-stone-500 dark:text-stone-400 mt-2 line-clamp-2 leading-relaxed flex-1">
                      {project.description}
                    </p>

                    {/* Auto-calculated Progress Bar */}
                    <div className="mt-5 space-y-1.5">
                      <div className="flex items-center justify-between text-[11px] text-stone-500">
                        <span className="font-medium">Progress</span>
                        <span className="font-semibold text-stone-800 dark:text-stone-200 tabular-nums">
                          {progressPct}% ({doneCount}/{totalCount} tasks)
                        </span>
                      </div>
                      <div className="h-1.5 w-full bg-stone-100 dark:bg-stone-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-teal-700 dark:bg-teal-500 rounded-full transition-all duration-500"
                          style={{ width: `${progressPct}%` }}
                        />
                      </div>
                    </div>

                    {/* Card Footer: Target Date & Avatars */}
                    <div className="mt-5 pt-4 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between text-xs text-stone-500">
                      <div className="flex items-center gap-1.5">
                        <Calendar className="w-3.5 h-3.5 text-stone-400" />
                        <span className="tabular-nums">Due {project.endDate}</span>
                      </div>

                      {/* Team Avatars */}
                      <div className="flex items-center -space-x-1.5">
                        {project.teamMembers.slice(0, 3).map((tm) => (
                          <div
                            key={tm.id}
                            title={`${tm.name} (${tm.role})`}
                            className="w-6 h-6 rounded-full bg-stone-200 dark:bg-stone-700 text-stone-700 dark:text-stone-200 text-[10px] font-bold flex items-center justify-center ring-2 ring-white dark:ring-stone-900"
                          >
                            {tm.avatarInitials}
                          </div>
                        ))}
                        {project.teamMembers.length > 3 && (
                          <div className="w-6 h-6 rounded-full bg-teal-100 dark:bg-teal-950 text-teal-800 dark:text-teal-300 text-[10px] font-bold flex items-center justify-center ring-2 ring-white dark:ring-stone-900">
                            +{project.teamMembers.length - 3}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            /* List View */
            <div className="bg-white dark:bg-stone-900 rounded-2xl border border-stone-200/90 dark:border-stone-800 overflow-hidden shadow-xs divide-y divide-stone-100 dark:divide-stone-800">
              {filteredProjects.map((project) => {
                const projectTs = tasks.filter((t) => t.projectId === project.id);
                const doneCount = projectTs.filter((t) => t.status === 'Done').length;
                const totalCount = projectTs.length;
                const progressPct = totalCount > 0 ? Math.round((doneCount / totalCount) * 100) : 0;

                return (
                  <div
                    key={project.id}
                    onClick={() => handleSelectProject(project.id)}
                    className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-stone-50/60 dark:hover:bg-stone-800/40 cursor-pointer transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2.5">
                        <h2 className="text-sm font-bold text-stone-900 dark:text-stone-100 hover:text-teal-700 transition-colors truncate">
                          {project.name}
                        </h2>
                        <StatusPill status={project.status} size="sm" />
                        <span className="text-[11px] text-stone-400">· {project.projectType}</span>
                      </div>
                      <p className="text-xs text-stone-500 dark:text-stone-400 mt-1 truncate">
                        {project.description}
                      </p>
                    </div>

                    <div className="flex items-center gap-6 shrink-0 text-xs">
                      <div className="w-32">
                        <div className="flex items-center justify-between text-[11px] text-stone-500 mb-1">
                          <span>Progress</span>
                          <span className="tabular-nums font-semibold">{progressPct}%</span>
                        </div>
                        <div className="h-1.5 w-full bg-stone-100 dark:bg-stone-800 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-teal-700 rounded-full"
                            style={{ width: `${progressPct}%` }}
                          />
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 text-stone-500 tabular-nums">
                        <Calendar className="w-3.5 h-3.5" />
                        <span>{project.endDate}</span>
                      </div>

                      <div className="flex items-center -space-x-1.5">
                        {project.teamMembers.slice(0, 3).map((tm) => (
                          <div
                            key={tm.id}
                            className="w-6 h-6 rounded-full bg-stone-200 dark:bg-stone-700 text-[10px] font-bold flex items-center justify-center ring-2 ring-white dark:ring-stone-900"
                          >
                            {tm.avatarInitials}
                          </div>
                        ))}
                      </div>

                      <ArrowRight className="w-4 h-4 text-stone-400 hover:text-teal-700 transition-colors" />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

      </main>
    </div>
  );
};
