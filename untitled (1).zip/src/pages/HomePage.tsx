import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../store/AppContext';
import { Logo } from '../components/common/Logo';
import { ThemeToggle } from '../components/common/ThemeToggle';
import { GuestBanner } from '../components/common/GuestBanner';
import { 
  Bot, 
  Kanban, 
  ArrowRight, 
  Sparkles, 
  LogOut, 
  LogIn, 
  FolderKanban,
  FileText,
  Clock,
  Compass
} from 'lucide-react';

export const HomePage: React.FC = () => {
  const navigate = useNavigate();
  const { user, isGuest, logout } = useApp();

  const handleLogout = () => {
    logout();
    navigate('/welcome');
  };

  const displayName = user?.name || (isGuest ? 'Guest' : 'Project Lead');

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 dark:bg-stone-950 text-stone-900 dark:text-stone-100 transition-colors">
      <GuestBanner />

      {/* Header */}
      <header className="px-6 py-4 flex items-center justify-between border-b border-stone-200/80 dark:border-stone-800/80 bg-white/70 dark:bg-stone-900/60 backdrop-blur-xs sticky top-0 z-20">
        <Logo size="md" />

        <div className="flex items-center gap-4">
          <ThemeToggle />

          <div className="flex items-center gap-3 pl-3 border-l border-stone-200 dark:border-stone-800">
            <div className="w-8 h-8 rounded-full bg-teal-700 text-white flex items-center justify-center text-xs font-bold uppercase shadow-xs">
              {displayName.charAt(0)}
            </div>
            <div className="hidden sm:block text-left">
              <p className="text-xs font-semibold text-stone-900 dark:text-stone-100 leading-tight">
                {displayName}
              </p>
              <p className="text-[10px] text-stone-500 dark:text-stone-400">
                {user?.role || (isGuest ? 'Guest User' : 'Project Manager')}
              </p>
            </div>

            {isGuest ? (
              <button
                onClick={() => navigate('/welcome')}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-teal-700 dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-teal-950/50 rounded-lg transition-colors border border-teal-200 dark:border-teal-800"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign in</span>
              </button>
            ) : (
              <button
                onClick={handleLogout}
                className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-lg transition-colors"
                title="Log out"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Logout</span>
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Home Hub */}
      <main className="flex-1 max-w-5xl w-full mx-auto p-6 sm:p-10 flex flex-col justify-center">
        {/* Welcome Greeting */}
        <div className="mb-10 text-center sm:text-left">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-stone-100 dark:bg-stone-800 text-stone-600 dark:text-stone-300 text-xs font-medium mb-3">
            <Compass className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
            <span>Workspace Hub</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-stone-900 dark:text-stone-100 tracking-tight">
            Hello, {displayName}
          </h1>
          <p className="text-sm text-stone-500 dark:text-stone-400 mt-1 max-w-xl">
            Choose a workspace to begin. Analyze product requirements with AI intelligence, or jump directly into project planning and sprint execution.
          </p>
        </div>

        {/* Two Large Action Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
          
          {/* Card 1: AI Requirement Analysis */}
          <button
            onClick={() => navigate('/requirements')}
            className="group relative flex flex-col text-left p-7 sm:p-8 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 hover:border-teal-600 dark:hover:border-teal-500 shadow-sm hover:shadow-xl hover:shadow-teal-900/5 transition-all duration-200 cursor-pointer overflow-hidden"
          >
            <div className="flex items-start justify-between">
              <div className="p-3.5 rounded-2xl bg-teal-50 dark:bg-teal-950/60 border border-teal-200/50 dark:border-teal-800/50 text-teal-700 dark:text-teal-400 group-hover:scale-105 transition-transform duration-200">
                <Bot className="w-7 h-7" />
              </div>
              <span className="inline-flex items-center gap-1 text-xs font-semibold text-teal-700 dark:text-teal-400 group-hover:translate-x-1 transition-transform">
                <span>Start Chat</span>
                <ArrowRight className="w-4 h-4" />
              </span>
            </div>

            <div className="mt-6 flex-1">
              <h2 className="text-xl font-bold text-stone-900 dark:text-stone-100 group-hover:text-teal-700 dark:group-hover:text-teal-400 transition-colors">
                AI Requirement Analysis
              </h2>
              <p className="text-xs sm:text-sm text-stone-500 dark:text-stone-400 mt-2 leading-relaxed">
                Interact with the intelligent requirements assistant. Upload documents, dictate with speech-to-text, generate acceptance criteria, and refine user stories with markdown export.
              </p>
            </div>

            <div className="mt-6 pt-5 border-t border-stone-100 dark:border-stone-800 flex items-center gap-4 text-xs text-stone-400 dark:text-stone-500">
              <span className="flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5" />
                <span>Multi-File Attach</span>
              </span>
              <span>·</span>
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>Speech Input</span>
              </span>
            </div>
          </button>

          {/* Card 2: AI Project Management Assistant */}
          <button
            onClick={() => navigate('/projects')}
            className="group relative flex flex-col text-left p-7 sm:p-8 rounded-2xl bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 hover:border-teal-600 dark:hover:border-teal-500 shadow-sm hover:shadow-xl hover:shadow-teal-900/5 transition-all duration-200 cursor-pointer overflow-hidden"
          >
            <div className="flex items-start justify-between">
              <div className="p-3.5 rounded-2xl bg-stone-100 dark:bg-stone-800/80 border border-stone-200/50 dark:border-stone-700/50 text-stone-800 dark:text-stone-200 group-hover:scale-105 transition-transform duration-200">
                <Kanban className="w-7 h-7 text-teal-700 dark:text-teal-400" />
              </div>
              <span className="inline-flex items-center gap-1 text-xs font-semibold text-teal-700 dark:text-teal-400 group-hover:translate-x-1 transition-transform">
                <span>View Projects</span>
                <ArrowRight className="w-4 h-4" />
              </span>
            </div>

            <div className="mt-6 flex-1">
              <h2 className="text-xl font-bold text-stone-900 dark:text-stone-100 group-hover:text-teal-700 dark:group-hover:text-teal-400 transition-colors">
                AI Project Management Assistant
              </h2>
              <p className="text-xs sm:text-sm text-stone-500 dark:text-stone-400 mt-2 leading-relaxed">
                Plan, organize and track projects using Agile Methodologies. Manage sprints, drag-and-drop scrum tasks, analyze risks, track decisions, and run retrospectives.
              </p>
            </div>

            <div className="mt-6 pt-5 border-t border-stone-100 dark:border-stone-800 flex items-center gap-4 text-xs text-stone-400 dark:text-stone-500">
              <span className="flex items-center gap-1.5">
                <FolderKanban className="w-3.5 h-3.5" />
                <span>Scrum Boards</span>
              </span>
              <span>·</span>
              <span className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                <span>Sprint Reviews</span>
              </span>
            </div>
          </button>

        </div>
      </main>

      {/* Footer */}
      <footer className="px-6 py-4 text-center text-xs text-stone-400 dark:text-stone-500 border-t border-stone-200/60 dark:border-stone-800/60">
        Demo mode active · Client mock state
      </footer>
    </div>
  );
};
