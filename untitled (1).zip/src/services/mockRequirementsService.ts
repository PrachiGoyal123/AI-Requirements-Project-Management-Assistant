import { FileAttachment } from '../types/requirement';

export interface AnalysisStreamChunk {
  text: string;
  isDone: boolean;
}

/**
 * Mock Requirements Service
 * 
 * Future replacement:
 * Replace this implementation with an API call to Gemini 2.5 Flash / Pro
 * or a dedicated backend service endpoint (/api/ai/analyze-requirements).
 */
export const mockRequirementsService = {
  /**
   * Generates a streaming markdown response.
   * Calls onChunk with incremental content until complete.
   */
  async streamResponse(
    prompt: string,
    attachments: FileAttachment[],
    onChunk: (chunk: string, isDone: boolean) => void,
    signal?: AbortSignal
  ): Promise<string> {
    const hasInstruction = prompt.trim().length > 0;
    const hasAttachments = attachments.length > 0;

    let fullMarkdown = '';

    if (!hasInstruction && hasAttachments) {
      // User sent ONLY a file/text/audio with NO instruction -> "Summary" response
      const fileNames = attachments.map(f => f.name).join(', ');
      fullMarkdown = `### Requirement Document Summary: ${fileNames}

**Executive Overview:**
The uploaded artifact(s) outline functional specifications and operational criteria for the upcoming delivery phase.

#### 1. Key Points & Business Drivers
* **Core Objective:** Establish unified, secure authentication and workflow tracking for the distributed customer base.
* **Target Audience:** Cross-functional engineering teams, product managers, and enterprise compliance auditors.
* **Non-negotiable Standards:** SOC2 Type II compliance, sub-300ms p95 latency, and zero-downtime rolling deployments.

#### 2. Requirements Identified
| ID | Category | Requirement Description | Acceptance Criteria |
| :--- | :--- | :--- | :--- |
| **REQ-01** | Security | Multi-Factor Authentication (TOTP + Passkey fallback) | Must enforce enrollment on high-privilege administrative accounts |
| **REQ-02** | Workflow | Audit Trail Logging for state transitions | Immutable log stored for $\ge 365$ days with tamper-proof hashing |
| **REQ-03** | Interface | Real-time Board Synchronization | Column and status updates reflect across active client sessions |
| **REQ-04** | Compliance | Data Retention & GDPR Scrubbing | User data purge workflow executable within 72 hours of validated request |

#### 3. Open Questions & Ambiguities
1. **Third-Party Providers:** Should the OAuth provider whitelist be restricted to Google Workspace and Okta SAML, or include consumer Google accounts?
2. **Offline Tolerance:** What is the required client behavior when local network connectivity drops during active sprint card edits?
3. **Notification Thresholds:** Does the system require digest emails, direct webhook webhooks, or in-app toasts only?`;
    } else {
      // User provided text instruction
      const lower = prompt.toLowerCase();
      const topic = lower.includes('payment') ? 'Payment Gateway & Billing'
        : lower.includes('auth') || lower.includes('login') ? 'Authentication & Identity Verification'
        : lower.includes('mobile') || lower.includes('app') ? 'Mobile App Experience'
        : 'System Architecture & Requirements Specification';

      fullMarkdown = `### ${topic} — Analysis & Structured Specification

Based on your prompt, here is the structured requirement breakdown with recommended user stories and verification matrix.

#### 1. Functional Scope & User Stories

* **User Story 1 — Intuitive Onboarding Flow**
  * *As a* newly registered user,
  * *I want to* complete initial profile setup within under 2 minutes,
  * *So that* I can immediately access my assigned project workspaces.

* **User Story 2 — Role-Based Permission Validation**
  * *As a* Project Manager,
  * *I want to* restrict sprint backlog editing permissions to designated team members,
  * *So that* accidental scope adjustments during an active cycle are prevented.

* **User Story 3 — Automated Block Detection**
  * *As an* Agile Coach,
  * *I want* tasks flagged as "Blocked" to highlight immediately on the Scrum Board,
  * *So that* daily standup triage can resolve bottlenecks proactively.

#### 2. Requirement Specification Table

| Spec ID | Priority | Feature Module | Technical Considerations | Verification Method |
| :--- | :--- | :--- | :--- | :--- |
| **SPEC-101** | High | Session Resilience | JWT refresh rotation with secure HttpOnly cookies | Automated integration suite |
| **SPEC-102** | High | Real-time Conflict Resolution | Optimistic UI updates with last-write-wins fallback | Load testing (500 concurrent connections) |
| **SPEC-103** | Medium | Exportable Sprint Reports | Client-side Markdown & CSV generation | Manual QA across Chrome/Safari/Firefox |
| **SPEC-104** | Low | Custom Color Theme Accents | CSS custom properties with WCAG AA compliance | Contrast automated audit |

#### 3. Edge Cases & Boundary Conditions
* **Simultaneous Card Moves:** Ensure idempotency if two users drag the same task card concurrently.
* **Network Throttling:** Provide a clear unboxed banner indicating unsaved changes if offline.
* **Special Characters in Story Titles:** Sanitize Markdown inputs against XSS and excessive line-breaks.

#### 4. Recommended Next Actions
1. Convert Spec **SPEC-101** and **SPEC-102** into formal user stories in the Product Backlog.
2. Estimate initial story points during the next Sprint Planning session.
3. Validate client sign-off on the authentication boundary questions.`;
    }

    // Simulate streaming by splitting by words / chunks with realistic intervals
    const words = fullMarkdown.split(' ');
    let accumulated = '';
    const chunkSize = 4;

    for (let i = 0; i < words.length; i += chunkSize) {
      if (signal?.aborted) {
        throw new Error('Aborted by user');
      }

      const nextChunk = words.slice(i, i + chunkSize).join(' ') + (i + chunkSize < words.length ? ' ' : '');
      accumulated += nextChunk;
      const isDone = i + chunkSize >= words.length;

      onChunk(accumulated, isDone);
      // Brief streaming delay (30ms)
      await new Promise((resolve) => setTimeout(resolve, 35));
    }

    return accumulated;
  },
};
