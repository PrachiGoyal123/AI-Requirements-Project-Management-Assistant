import { supabase, supabaseUrl, supabasePublishableKey } from '../../lib/supabaseClient';
import { PriorityLevel } from '../../types/task';
import { Project } from '../../types/project';
import { Sprint, RetroItem } from '../../types/sprint';
import { Task } from '../../types/task';
import { UserStory } from '../../types/backlog';
import { Risk, Dependency } from '../../types/risk';
import { DecisionItem } from '../../types/decision';

export interface ChatMessageInput {
  role: 'user' | 'assistant';
  content: string;
  attachments?: {
    name: string;
    size: number;
    type: string;
    path?: string;
    dataBase64?: string;
    extractedTextSnippet?: string;
  }[];
}

export interface StreamOptions {
  messages: ChatMessageInput[];
  onChunk: (delta: string, isDone: boolean) => void;
  signal?: AbortSignal;
}

export interface ProjectDataPayload {
  project?: Project;
  sprint?: Sprint;
  tasks?: Task[];
  stories?: UserStory[];
  risks?: Risk[];
  decisions?: DecisionItem[];
  dependencies?: Dependency[];
}

export interface AiProjectAnalysisResult {
  improvedGoal: string;
  missingInformationChecklist: string[];
  suggestedInitialStories: string[];
}

export interface SuggestedTaskItem {
  id: string;
  title: string;
  description: string;
  priority: PriorityLevel;
  estimatedHours: number;
  selected: boolean;
}

export interface SuggestedRiskItem {
  id: string;
  title: string;
  description: string;
  impact: 'Low' | 'Medium' | 'High' | 'Critical';
  probability: 'Low' | 'Medium' | 'High';
  mitigationPlan: string;
  owner: string;
  selected: boolean;
}

export interface ProjectSummaryResult {
  executiveSummary: string;
  overallHealth: 'On Track' | 'At Risk' | 'Delayed';
  healthReasoning: string;
  keyAccomplishments: string[];
  criticalRisks: string[];
  recommendedActions: string[];
  unconfirmedItems: {
    id: string;
    title: string;
    description: string;
    impact: string;
  }[];
}

export class AiClientError extends Error {
  status?: number;
  isRateLimit?: boolean;
  isQuota?: boolean;
  isNetwork?: boolean;

  constructor(message: string, status?: number) {
    super(message);
    this.name = 'AiClientError';
    this.status = status;
    this.isRateLimit = status === 429 || message.toLowerCase().includes('rate limit');
    this.isQuota = status === 403 || message.toLowerCase().includes('quota');
    this.isNetwork = message.toLowerCase().includes('network') || message.toLowerCase().includes('failed to fetch');
  }
}

async function getAuthHeader(): Promise<string> {
  let authHeader = `Bearer ${supabasePublishableKey || ''}`;
  if (supabase) {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.access_token) {
        authHeader = `Bearer ${session.access_token}`;
      }
    } catch (authErr) {
      console.warn('Could not retrieve user session token for AI gateway; using publishable key', authErr);
    }
  }
  return authHeader;
}

async function postJson<T>(payload: any, signal?: AbortSignal): Promise<T> {
  if (!supabaseUrl) {
    throw new AiClientError('Supabase URL is not configured. Please verify your environment variables.', 500);
  }

  const endpoint = `${supabaseUrl.replace(/\/$/, '')}/functions/v1/ai-gateway`;
  const authHeader = await getAuthHeader();

  let response: Response;
  try {
    response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authHeader,
        'apikey': supabasePublishableKey || '',
      },
      body: JSON.stringify(payload),
      signal,
    });
  } catch (fetchErr: any) {
    if (fetchErr.name === 'AbortError' || signal?.aborted) throw fetchErr;
    throw new AiClientError('Network connection failed. Could not reach the AI Gateway service.', 0);
  }

  if (!response.ok) {
    let errorMessage = `AI Gateway error (${response.status})`;
    try {
      const errJson = await response.json();
      if (errJson?.error) errorMessage = errJson.error;
    } catch {
      const raw = await response.text().catch(() => '');
      if (raw) errorMessage = raw.slice(0, 200);
    }
    throw new AiClientError(errorMessage, response.status);
  }

  return response.json();
}

async function streamSse(
  payload: any,
  onChunk: (delta: string, isDone: boolean) => void,
  signal?: AbortSignal
): Promise<string> {
  if (!supabaseUrl) {
    throw new AiClientError('Supabase URL is not configured. Please verify your environment configuration.', 500);
  }

  const endpoint = `${supabaseUrl.replace(/\/$/, '')}/functions/v1/ai-gateway`;
  const authHeader = await getAuthHeader();

  let response: Response;
  try {
    response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': authHeader,
        'apikey': supabasePublishableKey || '',
      },
      body: JSON.stringify(payload),
      signal,
    });
  } catch (fetchErr: any) {
    if (fetchErr.name === 'AbortError' || signal?.aborted) throw fetchErr;
    throw new AiClientError('Network connection failed. Could not reach the AI Gateway service.', 0);
  }

  if (!response.ok) {
    let errorMessage = `AI Gateway error (HTTP ${response.status})`;
    try {
      const errJson = await response.json();
      if (errJson?.error) errorMessage = errJson.error;
    } catch {
      const rawText = await response.text().catch(() => '');
      if (rawText) errorMessage = rawText.slice(0, 200);
    }
    throw new AiClientError(errorMessage, response.status);
  }

  if (!response.body) {
    throw new AiClientError('No response stream received from AI Gateway.', 502);
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let buffer = '';
  let accumulatedText = '';

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';

      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith(':')) continue;

        if (trimmed.startsWith('data: ')) {
          const jsonStr = trimmed.slice(6).trim();
          if (!jsonStr) continue;

          if (jsonStr === '[DONE]') {
            onChunk('', true);
            return accumulatedText;
          }

          try {
            const parsed = JSON.parse(jsonStr);
            if (parsed.error) {
              throw new AiClientError(parsed.error);
            }
            if (parsed.delta) {
              accumulatedText += parsed.delta;
              onChunk(parsed.delta, false);
            }
            if (parsed.done) {
              onChunk('', true);
              return accumulatedText;
            }
          } catch (parseErr: any) {
            if (parseErr instanceof AiClientError) throw parseErr;
          }
        }
      }
    }

    onChunk('', true);
    return accumulatedText;
  } catch (streamErr: any) {
    if (streamErr.name === 'AbortError' || signal?.aborted) {
      return accumulatedText;
    }
    if (streamErr instanceof AiClientError) throw streamErr;
    throw new AiClientError(streamErr?.message || 'Error occurred while streaming AI response.', 500);
  } finally {
    try {
      reader.releaseLock();
    } catch {
      // ignore
    }
  }
}

/**
 * AI Client connecting the frontend to the Supabase Edge Function 'ai-gateway'.
 * All model keys stay in server secrets.
 */
export const aiClient = {
  // --------------------------------------------------------------------------
  // STREAMED ACTIONS
  // --------------------------------------------------------------------------

  /**
   * Requirement Chat (Streamed, Multi-modal)
   */
  async streamRequirementChat({ messages, onChunk, signal }: StreamOptions): Promise<string> {
    return streamSse({ action: 'requirement_chat', messages }, onChunk, signal);
  },

  /**
   * Project Assistant (Streamed)
   */
  async streamProjectAssistant({
    query,
    projectData,
    onChunk,
    signal,
  }: {
    query: string;
    projectData: ProjectDataPayload;
    onChunk: (delta: string, isDone: boolean) => void;
    signal?: AbortSignal;
  }): Promise<string> {
    return streamSse({ action: 'project_assistant', query, projectData }, onChunk, signal);
  },

  /**
   * Status Report (Streamed)
   */
  async streamStatusReport({
    projectData,
    onChunk,
    signal,
  }: {
    projectData: ProjectDataPayload;
    onChunk: (delta: string, isDone: boolean) => void;
    signal?: AbortSignal;
  }): Promise<string> {
    return streamSse({ action: 'status_report', projectData }, onChunk, signal);
  },

  /**
   * Sprint Summary (Streamed)
   */
  async streamSprintSummary({
    projectData,
    onChunk,
    signal,
  }: {
    projectData: ProjectDataPayload;
    onChunk: (delta: string, isDone: boolean) => void;
    signal?: AbortSignal;
  }): Promise<string> {
    return streamSse({ action: 'sprint_summary', projectData }, onChunk, signal);
  },

  // --------------------------------------------------------------------------
  // NON-STREAMED STRUCTURED ACTIONS
  // --------------------------------------------------------------------------

  /**
   * Generate tasks for a User Story (Structured JSON)
   */
  async generateTasksForStory(
    storyTitle: string,
    storyDescription: string,
    signal?: AbortSignal
  ): Promise<SuggestedTaskItem[]> {
    const res = await postJson<{ tasks: Array<{ title: string; description: string; priority: PriorityLevel; estimatedHours: number }> }>(
      { action: 'generate_tasks', storyTitle, storyDescription },
      signal
    );

    return (res.tasks || []).map((t, idx) => ({
      id: `gen-${Date.now()}-${idx}`,
      title: t.title,
      description: t.description,
      priority: t.priority || 'Medium',
      estimatedHours: t.estimatedHours || 4,
      selected: true,
    }));
  },

  /**
   * Analyze project risks (Structured JSON)
   */
  async analyzeRisks(projectData: ProjectDataPayload, signal?: AbortSignal): Promise<SuggestedRiskItem[]> {
    const res = await postJson<{ risks: Array<{ title: string; description: string; impact: any; probability: any; mitigationPlan: string; owner: string }> }>(
      { action: 'analyze_risks', projectData },
      signal
    );

    return (res.risks || []).map((r, idx) => ({
      id: `rsk-sug-${Date.now()}-${idx}`,
      title: r.title,
      description: r.description,
      impact: r.impact || 'Medium',
      probability: r.probability || 'Medium',
      mitigationPlan: r.mitigationPlan || 'Active monitoring and sprint contingency.',
      owner: r.owner || 'Project Manager',
      selected: true,
    }));
  },

  /**
   * Project Summary & Health (Structured JSON)
   */
  async generateProjectSummary(projectData: ProjectDataPayload, signal?: AbortSignal): Promise<ProjectSummaryResult> {
    return postJson<ProjectSummaryResult>({ action: 'project_summary', projectData }, signal);
  },

  /**
   * Project Goal Analysis during creation (Structured JSON)
   */
  async analyzeProjectCreation(
    name: string,
    goal: string,
    projectType: string,
    signal?: AbortSignal
  ): Promise<AiProjectAnalysisResult> {
    return postJson<AiProjectAnalysisResult>(
      { action: 'goal_analysis', name, goal, projectType },
      signal
    );
  },

  /**
   * Suggest Sprint Plan (Structured JSON)
   */
  async suggestSprintPlan(
    availableStories: UserStory[],
    sprintGoal: string,
    targetVelocity: number = 20,
    signal?: AbortSignal
  ): Promise<{ recommendedStoryIds: string[]; reasoning: string }> {
    return postJson<{ recommendedStoryIds: string[]; reasoning: string }>(
      { action: 'sprint_plan', availableStories, sprintGoal, targetVelocity },
      signal
    );
  },

  /**
   * Retrospective Continuous Improvement Suggestions (Structured JSON)
   */
  async generateRetroImprovements(
    whatWentWell: RetroItem[],
    whatDidntGoWell: RetroItem[],
    signal?: AbortSignal
  ): Promise<string[]> {
    const res = await postJson<{ improvements: string[] }>(
      { action: 'retro_suggestions', whatWentWell, whatDidntGoWell },
      signal
    );
    return res.improvements || [];
  },

  /**
   * Draft Follow-Up Message for a Decision Item (Structured JSON)
   */
  async draftFollowUpMessage(
    item: DecisionItem,
    projectName: string,
    signal?: AbortSignal
  ): Promise<string> {
    const res = await postJson<{ subject: string; messageText: string }>(
      { action: 'followup_message', item, projectName },
      signal
    );
    return `Subject: ${res.subject}\n\n${res.messageText}`;
  },

  /**
   * Assess Downstream Schedule Drift for a Decision Item (Structured JSON)
   */
  async assessDecisionImpact(
    item: DecisionItem,
    projectName: string,
    signal?: AbortSignal
  ): Promise<{ days: number; impactText: string }> {
    return postJson<{ days: number; impactText: string }>(
      { action: 'schedule_impact', item, projectName },
      signal
    );
  },
};
