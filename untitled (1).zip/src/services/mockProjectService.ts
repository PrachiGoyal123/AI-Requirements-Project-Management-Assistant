import { Project } from '../types/project';
import { UserStory } from '../types/backlog';
import { Task, PriorityLevel } from '../types/task';
import { Sprint, RetroItem } from '../types/sprint';
import { Risk, Dependency } from '../types/risk';
import { DecisionItem } from '../types/decision';
import { StatusReportData } from '../types/report';

export interface AiProjectAnalysisResult {
  improvedGoal: string;
  missingInformationChecklist: string[];
  suggestedInitialStories: string[];
}

export interface SuggestedTaskItem {
  id: string;
  title: string;
  description: string;
  priority: PriorityLevel;
  estimatedHours: number;
  selected: boolean;
}

export interface SuggestedRiskItem {
  id: string;
  title: string;
  description: string;
  impact: 'Low' | 'Medium' | 'High' | 'Critical';
  probability: 'Low' | 'Medium' | 'High';
  mitigationPlan: string;
  owner: string;
  selected: boolean;
}

export const mockProjectService = {
  /**
   * Analyzes project creation inputs and returns improved goal and missing info checklist
   */
  async analyzeProjectCreation(
    name: string,
    goal: string,
    projectType: string
  ): Promise<AiProjectAnalysisResult> {
    await new Promise((resolve) => setTimeout(resolve, 600));

    const refinedGoal = goal.trim()
      ? `Deliver ${name} utilizing ${projectType} principles to achieve high operational reliability, measurable customer adoption, and seamless security governance within the scheduled timeline.`
      : `Establish a high-performance ${projectType} baseline for ${name}, targeting zero-defect sprint milestones, strict acceptance compliance, and verified user satisfaction.`;

    return {
      improvedGoal: refinedGoal,
      missingInformationChecklist: [
        'Clarify external API service level agreements (SLAs) and third-party rate limits',
        'Identify target release environment specifications (Staging, Pre-prod, Production)',
        'Define explicit Definition of Done (DoD) including minimum automated test coverage (e.g. 80%)',
        'Verify client product owner availability for bi-weekly sprint reviews',
      ],
      suggestedInitialStories: [
        'Core architecture initialization & CI/CD pipeline setup',
        'Authentication and user profile baseline',
        'Telemetry dashboard and audit logging framework',
      ],
    };
  },

  /**
   * Generates task breakdown suggestions for a User Story
   */
  async generateTasksForStory(storyTitle: string, _storyDescription: string): Promise<SuggestedTaskItem[]> {
    await new Promise((resolve) => setTimeout(resolve, 500));

    // Custom tailored tasks based on story title
    const lower = storyTitle.toLowerCase();
    if (lower.includes('registration') || lower.includes('sign up') || lower.includes('register')) {
      return [
        { id: 'gen-1', title: 'Create Registration UI Component', description: 'Build responsive signup form with accessible input fields and live validation state', priority: 'High', estimatedHours: 6, selected: true },
        { id: 'gen-2', title: 'Create Registration API Endpoint', description: 'Implement server validation, rate limiting, and password hashing service', priority: 'High', estimatedHours: 8, selected: true },
        { id: 'gen-3', title: 'Add Email Validation & Format Check', description: 'Enforce RFC-compliant regex, disposable email detection, and mx record verification', priority: 'Medium', estimatedHours: 4, selected: true },
        { id: 'gen-4', title: 'Add Password Strength & Complexity Rules', description: 'Enforce zxcvbn score $\\ge 3$, minimum length 8, and special character checks', priority: 'Medium', estimatedHours: 4, selected: true },
        { id: 'gen-5', title: 'Perform QA Testing & Edge Case Matrix', description: 'Write automated unit tests and manual smoke test suite for edge case scenarios', priority: 'High', estimatedHours: 5, selected: true },
      ];
    } else if (lower.includes('login') || lower.includes('auth')) {
      return [
        { id: 'gen-1', title: 'Build Secure Login Form & Remember Me', description: 'Create responsive login UI with accessible tab indexing and credential autofill support', priority: 'High', estimatedHours: 6, selected: true },
        { id: 'gen-2', title: 'Implement JWT Session & Refresh Tokens', description: 'Configure HttpOnly secure cookies with sliding expiration and CSRF protection', priority: 'High', estimatedHours: 8, selected: true },
        { id: 'gen-3', title: 'Add Brute Force & Rate Limit Protection', description: 'Lock accounts temporarily after 5 consecutive failed authentication attempts', priority: 'Medium', estimatedHours: 5, selected: true },
        { id: 'gen-4', title: 'QA Security Verification & Logout Edge Cases', description: 'Verify token invalidation on logout and multi-tab state synchronization', priority: 'High', estimatedHours: 4, selected: true },
      ];
    } else if (lower.includes('forgot') || lower.includes('reset')) {
      return [
        { id: 'gen-1', title: 'Password Reset Request Interface', description: 'Build user-friendly email prompt with debounce and anti-enumeration feedback', priority: 'High', estimatedHours: 4, selected: true },
        { id: 'gen-2', title: 'Time-Limited Secure Token Dispatch Service', description: 'Generate cryptographically random 15-minute validity reset tokens', priority: 'High', estimatedHours: 6, selected: true },
        { id: 'gen-3', title: 'New Password Entry & Confirmation View', description: 'Provide interactive validation checklist for the updated credentials', priority: 'Medium', estimatedHours: 4, selected: true },
        { id: 'gen-4', title: 'Integration Test Suite for Expiry & Re-use', description: 'Verify one-time token consumption and revoked previous sessions', priority: 'High', estimatedHours: 4, selected: true },
      ];
    }

    return [
      { id: 'gen-1', title: `Implement UI components for ${storyTitle}`, description: 'Build responsive views following design guidelines and accessibility standards', priority: 'High', estimatedHours: 6, selected: true },
      { id: 'gen-2', title: `Develop backend business logic for ${storyTitle}`, description: 'Implement controllers, validation schemas, and database transactions', priority: 'High', estimatedHours: 8, selected: true },
      { id: 'gen-3', title: `Add automated unit & integration tests`, description: 'Verify happy path, boundary criteria, and error recovery', priority: 'Medium', estimatedHours: 5, selected: true },
      { id: 'gen-4', title: `Perform peer code review and UX verification`, description: 'Ensure adherence to coding standards and acceptance criteria sign-off', priority: 'Medium', estimatedHours: 3, selected: true },
    ];
  },

  /**
   * Suggests a Sprint Plan based on available backlog items and team velocity
   */
  async suggestSprintPlan(
    availableStories: UserStory[],
    sprintGoal: string,
    targetVelocity: number = 20
  ): Promise<{ recommendedStoryIds: string[]; reasoning: string }> {
    await new Promise((resolve) => setTimeout(resolve, 550));

    let accumulatedPoints = 0;
    const selectedIds: string[] = [];

    // Prioritize high/critical stories first
    const sorted = [...availableStories].sort((a, b) => {
      const order = { Critical: 4, High: 3, Medium: 2, Low: 1 };
      return order[b.priority] - order[a.priority];
    });

    for (const story of sorted) {
      if (accumulatedPoints + story.storyPoints <= targetVelocity || selectedIds.length === 0) {
        selectedIds.push(story.id);
        accumulatedPoints += story.storyPoints;
      }
    }

    return {
      recommendedStoryIds: selectedIds,
      reasoning: `Selected ${selectedIds.length} high-priority stories totaling ${accumulatedPoints} story points (target velocity: ${targetVelocity} pts). Aligns directly with sprint goal: "${sprintGoal || 'Core feature delivery'}".`,
    };
  },

  /**
   * Analyzes project risks and suggests new mitigated items
   */
  async analyzeRisks(): Promise<SuggestedRiskItem[]> {
    await new Promise((resolve) => setTimeout(resolve, 500));

    return [
      {
        id: 'rsk-sug-1',
        title: 'Third-Party Identity Provider API Rate Limit',
        description: 'High burst sign-up traffic may exceed current tier rate limits during promotional launch.',
        impact: 'High',
        probability: 'Medium',
        mitigationPlan: 'Implement exponential backoff queuing with fallback cache and upgrade API tier 2 weeks before launch.',
        owner: 'DevOps Lead',
        selected: true,
      },
      {
        id: 'rsk-sug-2',
        title: 'Pending Legal Data Compliance Sign-off',
        description: 'GDPR consent workflow changes have not yet been formally countersigned by external counsel.',
        impact: 'Critical',
        probability: 'Low',
        mitigationPlan: 'Escalate approval item in weekly governance sync; schedule legal audit review call for Thursday.',
        owner: 'Project Manager',
        selected: true,
      },
      {
        id: 'rsk-sug-3',
        title: 'Sprint Scope Creep from Secondary Stakeholder Requests',
        description: 'Informal feature tweaks requested during mid-sprint demos threaten the planned delivery date.',
        impact: 'Medium',
        probability: 'High',
        mitigationPlan: 'Enforce strict backlog intake workflow; defer non-critical tweaks to the next refinement cycle.',
        owner: 'Scrum Master',
        selected: false,
      },
    ];
  },

  /**
   * Assesses schedule impact of a decision item
   */
  async assessDecisionImpact(item: DecisionItem): Promise<{ days: number; impactText: string }> {
    await new Promise((resolve) => setTimeout(resolve, 400));
    const days = item.status === 'Overdue' ? 5 : 3;

    return {
      days,
      impactText: `Delay in resolving "${item.item}" directly blocks dependent user stories. Estimated downstream schedule impact: +${days} business days on the staging release milestone if unresolved by ${item.dueDate}.`,
    };
  },

  /**
   * Drafts a professional follow-up message for a pending decision
   */
  async draftFollowUpMessage(item: DecisionItem, projectName: string): Promise<string> {
    await new Promise((resolve) => setTimeout(resolve, 350));

    return `Subject: Action Required: Clarification on "${item.item}" for ${projectName}

Dear ${item.requestedFrom},

I hope this message finds you well.

We are writing to follow up on the open decision item regarding:
"${item.item}"

Details:
${item.description}

Current Target Due Date: ${item.dueDate}
Status: ${item.status}

Our sprint engineering team is currently aligned to proceed with the core implementation. To ensure we maintain our agreed sprint schedule and prevent delivery blockers, could you please provide your formal guidance or approval by ${item.dueDate}?

Please let us know if a brief 10-minute sync would help expedite this review.

Best regards,
${item.owner}
${projectName} Delivery Team`;
  },

  /**
   * Generates retrospective improvement suggestions
   */
  async generateRetroImprovements(
    whatWentWell: RetroItem[],
    whatDidntGoWell: RetroItem[]
  ): Promise<string[]> {
    await new Promise((resolve) => setTimeout(resolve, 450));

    const suggestions = [
      'Introduce 15-minute daily async blockers check-in before the morning standup',
      'Refine User Story Acceptance Criteria checklist to mandate mock API contracts before frontend development',
      'Allocate 10% of sprint capacity specifically for technical debt and automated test coverage',
      'Conduct bi-weekly backlog grooming sessions to keep stories in "Ready for Sprint" state',
    ];

    if (whatDidntGoWell.some(i => i.text.toLowerCase().includes('review') || i.text.toLowerCase().includes('pr'))) {
      suggestions.unshift('Enforce maximum PR size limit ($\le 350$ lines) to accelerate code review turnaround');
    }

    return suggestions;
  },

  /**
   * Compiles live project status report
   */
  compileStatusReport(
    project: Project,
    activeSprint: Sprint | undefined,
    tasks: Task[],
    stories: UserStory[],
    risks: Risk[],
    decisions: DecisionItem[],
    dependencies: Dependency[]
  ): StatusReportData {
    const totalTasks = tasks.length;
    const completedTasks = tasks.filter(t => t.status === 'Done');
    const inProgressTasks = tasks.filter(t => t.status === 'In Progress');
    const delayedTasks = tasks.filter(t => {
      if (t.status === 'Done') return false;
      const due = new Date(t.dueDate).getTime();
      return due < Date.now();
    });
    const blockedTasks = tasks.filter(t => t.isBlocked);
    const openRisks = risks.filter(r => r.status === 'Open');
    const pendingDecisions = decisions.filter(d => d.status === 'Pending' || d.status === 'Overdue');

    const completionRate = totalTasks > 0 ? Math.round((completedTasks.length / totalTasks) * 100) : 0;

    let overallHealth: 'On Track' | 'At Risk' | 'Delayed' = 'On Track';
    if (delayedTasks.length > 2 || blockedTasks.length > 2 || openRisks.some(r => r.impact === 'Critical')) {
      overallHealth = 'At Risk';
    }
    if (delayedTasks.length > 4 || blockedTasks.length > 3) {
      overallHealth = 'Delayed';
    }

    const keyAchievements = completedTasks.slice(0, 5).map(t => t.title);
    if (keyAchievements.length === 0) {
      keyAchievements.push('Sprint backlog initialized and architecture contracts verified');
    }

    const inProgressHighlights = inProgressTasks.slice(0, 5).map(t => `${t.title} (${t.assigneeName})`);
    const delayedItems = delayedTasks.map(t => `${t.title} — Due ${t.dueDate} (${t.assigneeName})`);
    const topRisks = openRisks.map(r => `[${r.impact} Impact] ${r.title} (Owner: ${r.owner})`);
    const criticalBlockers = blockedTasks.map(t => `${t.title}: ${t.blockedReason || 'Blocked by external dependency'}`);
    const keyDependencies = dependencies.filter(d => d.status !== 'Resolved').map(d => `${d.title} [Status: ${d.status}]`);
    const clientAttentionItems = pendingDecisions.map(d => `${d.item} (Requested from: ${d.requestedFrom}, Due: ${d.dueDate})`);

    const recommendedNextSteps = [
      'Unblock active impediment on delayed tasks through targeted pairing session',
      'Obtain pending stakeholder sign-offs on open decision items',
      'Conduct mid-sprint velocity sanity check to ensure target completion by sprint end date',
      'Validate acceptance criteria with automated integration tests prior to Sprint Review',
    ];

    const markdownContent = `# Project Status Report: ${project.name}
**Generated:** ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}  
**Project Manager:** ${project.projectManager}  
**Active Sprint:** ${activeSprint ? activeSprint.name : 'No active sprint'}  
**Overall Health:** **${overallHealth}** (${completionRate}% task completion rate)

---

### 1. Overall Project Status
* **Sprint Velocity & Progress:** ${completedTasks.length} of ${totalTasks} tasks completed (${completionRate}%).
* **Active Workstream:** ${inProgressTasks.length} tasks currently in progress across the engineering team.
* **Health Assessment:** ${overallHealth === 'On Track' ? 'Delivery is progressing according to schedule with no blocking escalations.' : 'Certain milestones are experiencing friction and require project manager intervention.'}

### 2. Completed Work (Achievements)
${keyAchievements.map(a => `* ${a}`).join('\n')}

### 3. In Progress Items
${inProgressHighlights.length > 0 ? inProgressHighlights.map(i => `* ${i}`).join('\n') : '* No items currently in progress'}

### 4. Delayed Work & Schedule Slippage
${delayedItems.length > 0 ? delayedItems.map(d => `* ⚠️ ${d}`).join('\n') : '* None. All active tasks are within their scheduled due dates.'}

### 5. Active Blockers & Impairments
${criticalBlockers.length > 0 ? criticalBlockers.map(b => `* 🛑 ${b}`).join('\n') : '* Zero blocked tasks recorded in the current sprint cycle.'}

### 6. Risks & Watch Items
${topRisks.length > 0 ? topRisks.map(r => `* ${r}`).join('\n') : '* All identified risks are currently mitigated or accepted.'}

### 7. Cross-Team Dependencies
${keyDependencies.length > 0 ? keyDependencies.map(d => `* ${d}`).join('\n') : '* No outstanding cross-team dependencies pending.'}

### 8. Client / Stakeholder Attention Required
${clientAttentionItems.length > 0 ? clientAttentionItems.map(c => `* 📌 **Action Required:** ${c}`).join('\n') : '* No urgent stakeholder decisions pending at this time.'}

### 9. Recommended Next Steps for Project Manager
${recommendedNextSteps.map((s, idx) => `${idx + 1}. ${s}`).join('\n')}`;

    return {
      generatedAt: new Date().toISOString(),
      projectName: project.name,
      projectManager: project.projectManager,
      activeSprintName: activeSprint ? activeSprint.name : 'None',
      overallHealth,
      completionRate,
      completedTasksCount: completedTasks.length,
      inProgressTasksCount: inProgressTasks.length,
      delayedTasksCount: delayedTasks.length,
      blockedTasksCount: blockedTasks.length,
      openRisksCount: openRisks.length,
      pendingDecisionsCount: pendingDecisions.length,
      keyAchievements,
      inProgressHighlights,
      delayedItems,
      topRisks,
      criticalBlockers,
      keyDependencies,
      clientAttentionItems,
      recommendedNextSteps,
      markdownContent,
    };
  },
};
