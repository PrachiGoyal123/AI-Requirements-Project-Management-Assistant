import { User } from '../types/auth';
import { supabase, isSupabaseConfigured } from '../lib/supabaseClient';

export interface AuthSessionResult {
  user: User | null;
  error?: string | null;
}

export const authService = {
  isConfigured(): boolean {
    return isSupabaseConfigured && Boolean(supabase);
  },

  async getSession(): Promise<User | null> {
    if (!this.isConfigured() || !supabase) return null;
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      if (error || !session?.user) return null;
      return this.mapSupabaseUser(session.user);
    } catch (err) {
      console.warn('Failed to retrieve Supabase session:', err);
      return null;
    }
  },

  onAuthStateChange(callback: (user: User | null) => void) {
    if (!this.isConfigured() || !supabase) {
      return { unsubscribe: () => {} };
    }
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        callback(this.mapSupabaseUser(session.user));
      } else {
        callback(null);
      }
    });
    return {
      unsubscribe: () => subscription.unsubscribe(),
    };
  },

  mapSupabaseUser(sbUser: any): User {
    const meta = sbUser.user_metadata || {};
    const email = sbUser.email || '';
    const fallbackName = email ? email.split('@')[0].replace(/[._-]/g, ' ') : 'Project Lead';
    const name = meta.name || meta.full_name || fallbackName;

    return {
      id: sbUser.id,
      name: name.replace(/\b\w/g, (c: string) => c.toUpperCase()),
      email,
      isGuest: false,
      role: meta.role || 'Project Manager',
      avatarUrl: meta.avatar_url || undefined,
    };
  },

  async signInWithEmail(email: string, password: string): Promise<User> {
    if (!this.isConfigured() || !supabase) {
      throw new Error('Supabase client is not configured. Please verify your environment variables.');
    }
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) {
      throw error;
    }
    if (!data.user) {
      throw new Error('No user returned from authentication service.');
    }
    return this.mapSupabaseUser(data.user);
  },

  async registerWithEmail(email: string, password: string, name?: string): Promise<{ user: User | null; requiresEmailConfirmation: boolean }> {
    if (!this.isConfigured() || !supabase) {
      throw new Error('Supabase client is not configured. Please verify your environment variables.');
    }
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          name: name?.trim(),
          role: 'Project Manager',
        },
      },
    });
    if (error) {
      throw error;
    }

    const requiresEmailConfirmation = Boolean(data.user && !data.session);
    const user = data.user ? this.mapSupabaseUser(data.user) : null;
    return { user, requiresEmailConfirmation };
  },

  async signInWithGoogle(): Promise<void> {
    if (!this.isConfigured() || !supabase) {
      throw new Error('Supabase client is not configured. Please verify your environment variables.');
    }
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: window.location.origin + '/home',
      },
    });
    if (error) {
      throw error;
    }
  },

  async signOut(): Promise<void> {
    if (this.isConfigured() && supabase) {
      try {
        await supabase.auth.signOut();
      } catch (err) {
        console.warn('Error signing out of Supabase:', err);
      }
    }
  },

  async resetPasswordForEmail(email: string): Promise<void> {
    if (!this.isConfigured() || !supabase) {
      throw new Error('Supabase client is not configured.');
    }
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/welcome?reset=true`,
    });
    if (error) {
      throw error;
    }
  },

  async updateUserPassword(newPassword: string): Promise<void> {
    if (!this.isConfigured() || !supabase) {
      throw new Error('Supabase client is not configured.');
    }
    const { error } = await supabase.auth.updateUser({
      password: newPassword,
    });
    if (error) {
      throw error;
    }
  },

  createGuestUser(): User {
    return {
      id: `guest-${Math.random().toString(36).substring(2, 8)}`,
      name: 'Guest User',
      email: 'guest@agilemind.local',
      isGuest: true,
      role: 'Guest Collaborator',
    };
  },
};
