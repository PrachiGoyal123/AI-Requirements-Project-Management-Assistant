import { Project } from '../types/project';
import { Sprint } from '../types/sprint';
import { Task } from '../types/task';
import { UserStory } from '../types/backlog';
import { Risk, Dependency } from '../types/risk';
import { DecisionItem } from '../types/decision';

export const mockAiAssistantService = {
  /**
   * Responds to user questions using REAL current state data of the project.
   */
  async queryProjectAssistant(
    query: string,
    project: Project,
    sprint: Sprint | undefined,
    tasks: Task[],
    stories: UserStory[],
    risks: Risk[],
    decisions: DecisionItem[],
    dependencies: Dependency[]
  ): Promise<string> {
    await new Promise((resolve) => setTimeout(resolve, 450));

    const q = query.toLowerCase().trim();
    const now = Date.now();

    // 1. Delayed tasks query
    if (q.includes('delayed') || q.includes('overdue') || q.includes('late')) {
      const delayed = tasks.filter((t) => {
        if (t.status === 'Done') return false;
        return new Date(t.dueDate).getTime() < now;
      });

      if (delayed.length === 0) {
        return `### Delayed Tasks Analysis for ${project.name}

Great news: **There are currently 0 delayed tasks** in ${sprint ? sprint.name : 'the current backlog'}. All active tasks are within their scheduled due dates.

* Total active tasks: ${tasks.filter(t => t.status !== 'Done').length}
* Completed tasks: ${tasks.filter(t => t.status === 'Done').length}`;
      }

      return `### Delayed Tasks in ${project.name} (${delayed.length} Found)

Based on current task schedule due dates, the following tasks are past their deadline and require immediate attention:

${delayed
  .map(
    (t) =>
      `* **${t.id}: ${t.title}**
  * **Assignee:** ${t.assigneeName}
  * **Status:** ${t.status}
  * **Due Date:** ${t.dueDate} (Past due)
  * **Priority:** ${t.priority}${t.isBlocked ? ` (🛑 Blocked: ${t.blockedReason})` : ''}`
  )
  .join('\n\n')}

**Recommended Action:**
Contact ${Array.from(new Set(delayed.map(t => t.assigneeName))).join(', ')} to determine if scope adjustment or team re-allocation is necessary.`;
    }

    // 2. Sprint blockers query
    if (q.includes('block') || q.includes('impediment')) {
      const blocked = tasks.filter((t) => t.isBlocked);
      const blockedDeps = dependencies.filter((d) => d.status === 'Blocked');

      if (blocked.length === 0 && blockedDeps.length === 0) {
        return `### Blocker Analysis for ${project.name}

Currently, **no tasks or dependencies are marked as Blocked**. 

The delivery pipeline is uninhibited. If an engineer encounters an obstacle, prompt them to toggle the "Blocked" flag in the task detail drawer with an explanation for immediate triage.`;
      }

      let response = `### Current Impediments & Blockers (${blocked.length} Tasks, ${blockedDeps.length} Dependencies)\n\n`;
      if (blocked.length > 0) {
        response += `#### Blocked Tasks\n`;
        response += blocked
          .map(
            (t) =>
              `* **${t.id}: ${t.title}** (${t.assigneeName})
  * **Reason:** ${t.blockedReason || 'Unspecified technical blocker'}
  * **Current Column:** ${t.status}`
          )
          .join('\n');
        response += '\n\n';
      }

      if (blockedDeps.length > 0) {
        response += `#### Blocked Cross-Team Dependencies\n`;
        response += blockedDeps
          .map(
            (d) =>
              `* **${d.title}** (Owner: ${d.owner}, Due: ${d.dueDate})
  * Status: Blocked`
          )
          .join('\n');
        response += '\n\n';
      }

      response += `**Recommended Next Step:** Convene an immediate 10-minute impediment clearance sync with the task owners.`;
      return response;
    }

    // 3. What to discuss with client / stakeholders
    if (q.includes('client') || q.includes('stakeholder') || q.includes('discuss')) {
      const pendingDec = decisions.filter(
        (d) => d.status === 'Pending' || d.status === 'Overdue'
      );
      const openCriticalRisks = risks.filter(
        (r) => r.status === 'Open' && (r.impact === 'Critical' || r.impact === 'High')
      );

      if (pendingDec.length === 0 && openCriticalRisks.length === 0) {
        return `### Client Agenda for ${project.name}

All formal client approval items are currently up-to-date! 

**Recommended Agenda Points for your next sync:**
1. Present the current sprint demo (${sprint ? sprint.name : 'active features'}).
2. Review completion velocity (${tasks.filter(t => t.status === 'Done').length}/${tasks.length} tasks completed).
3. Validate preview designs for upcoming backlog stories.`;
      }

      let response = `### Recommended Client & Stakeholder Discussion Agenda\n\n`;
      response += `Here are the critical items awaiting stakeholder feedback or approvals:\n\n`;

      if (pendingDec.length > 0) {
        response += `#### Pending Decisions Requiring Client Sign-Off\n`;
        response += pendingDec
          .map(
            (d) =>
              `* **${d.item}** (Requested from: ${d.requestedFrom})
  * **Due Date:** ${d.dueDate} ${d.status === 'Overdue' ? '⚠️ [OVERDUE]' : ''}
  * **Description:** ${d.description}`
          )
          .join('\n');
        response += '\n\n';
      }

      if (openCriticalRisks.length > 0) {
        response += `#### High-Impact Risks to Escalate\n`;
        response += openCriticalRisks
          .map(
            (r) =>
              `* **${r.title}** [${r.impact} Impact]
  * Mitigation Plan: ${r.mitigationPlan}`
          )
          .join('\n');
        response += '\n\n';
      }

      response += `*Tip: You can use the "Draft Follow-up Message" button in the Decisions & Approvals tab to generate a ready-to-send email.*`;
      return response;
    }

    // 4. Summarize current project status
    if (q.includes('summarize') || q.includes('status') || q.includes('overview') || q.includes('progress')) {
      const total = tasks.length;
      const done = tasks.filter(t => t.status === 'Done').length;
      const inProg = tasks.filter(t => t.status === 'In Progress').length;
      const blocked = tasks.filter(t => t.isBlocked).length;
      const pct = total > 0 ? Math.round((done / total) * 100) : 0;

      return `### Project Executive Summary: ${project.name}

* **Project Manager:** ${project.projectManager}
* **Project Type:** ${project.projectType}
* **Active Sprint:** ${sprint ? `${sprint.name} (${sprint.status})` : 'None in progress'}
* **Target Delivery Date:** ${project.endDate}

#### Work Breakdown & Velocity
* **Task Completion Rate:** **${pct}%** (${done} of ${total} tasks finished)
* **In Progress Work:** ${inProg} tasks
* **Blocked Items:** ${blocked} ${blocked > 0 ? '⚠️' : '✅'}
* **Product Backlog:** ${stories.length} user stories logged
* **Open Risks:** ${risks.filter(r => r.status === 'Open').length} logged risks
* **Pending Decisions:** ${decisions.filter(d => d.status === 'Pending').length} items

Overall health indicator is **${project.status}**.`;
    }

    // 5. Dependencies affecting delivery
    if (q.includes('dependenc') || q.includes('depend')) {
      if (dependencies.length === 0) {
        return `### Dependency Assessment for ${project.name}

There are currently **no external dependencies tracked** in the workspace. To log an integration or cross-team dependency, visit the "Risks & Dependencies" section.`;
      }

      const unresolved = dependencies.filter(d => d.status !== 'Resolved');
      return `### Tracked Dependencies (${dependencies.length} Total, ${unresolved.length} Unresolved)

${dependencies
  .map(
    (d) =>
      `* **${d.title}**
  * **Source / Dependent:** ${d.sourceItem} ➔ ${d.dependentItem}
  * **Owner:** ${d.owner}
  * **Status:** ${d.status}
  * **Target Date:** ${d.dueDate}`
  )
  .join('\n\n')}

${unresolved.length > 0 ? `⚠️ **Watch:** ${unresolved.length} dependencies remain active and could introduce schedule drift if delayed.` : '✅ All logged dependencies are marked as Resolved.'}`;
    }

    // 6. What should I focus on this week?
    if (q.includes('focus') || q.includes('week') || q.includes('priority') || q.includes('priorities')) {
      const blocked = tasks.filter(t => t.isBlocked);
      const delayed = tasks.filter(t => t.status !== 'Done' && new Date(t.dueDate).getTime() < now);
      const inProg = tasks.filter(t => t.status === 'In Progress');

      const focusItems: string[] = [];

      if (blocked.length > 0) {
        focusItems.push(`**Resolve Blockers:** ${blocked.length} task(s) are actively blocked (${blocked.map(t => t.title).slice(0, 2).join(', ')}).`);
      }
      if (delayed.length > 0) {
        focusItems.push(`**Catch Up on Overdue Deliverables:** ${delayed.length} overdue item(s) (${delayed.map(t => t.title).slice(0, 2).join(', ')}).`);
      }
      if (inProg.length > 0) {
        focusItems.push(`**Complete In-Progress Sprint Tasks:** Drive the ${inProg.length} currently active tasks into Review/Done.`);
      }

      const pendingDec = decisions.filter(d => d.status === 'Pending' || d.status === 'Overdue');
      if (pendingDec.length > 0) {
        focusItems.push(`**Follow up with Stakeholders:** Clear ${pendingDec.length} pending decision item(s).`);
      }

      if (focusItems.length === 0) {
        focusItems.push('Refine the next sprint backlog and prepare upcoming user story estimates.');
        focusItems.push('Review automated test coverage and documentation artifacts.');
      }

      return `### Recommended Weekly Focus for Project Management

Here are the highest-impact priorities for this week on **${project.name}**:

${focusItems.map((item, i) => `${i + 1}. ${item}`).join('\n\n')}

*Focus on closing work-in-progress before pulling new user stories into the active sprint.*`;
    }

    // Fallback for custom user questions
    return `### Project Query: "${query}"

Here is what the live workspace data shows for **${project.name}**:

* **Active Sprint:** ${sprint ? sprint.name : 'No active sprint'}
* **Total User Stories:** ${stories.length}
* **Tasks:** ${tasks.filter(t => t.status === 'Done').length} completed, ${tasks.filter(t => t.status === 'In Progress').length} in progress, ${tasks.filter(t => t.status === 'To Do').length} to do
* **Blockers:** ${tasks.filter(t => t.isBlocked).length}
* **Open Risks:** ${risks.filter(r => r.status === 'Open').length}

*(If you are looking for specific task, dependency, or client decision insights, try asking one of the suggested chips below or asking about delayed tasks, blockers, or dependencies).*`;
  },
};
