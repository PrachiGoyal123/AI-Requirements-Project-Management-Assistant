import { getSupabase } from '../lib/supabaseClient';
import { Project, TeamMember, ProjectType, ProjectDocument } from '../types/project';
import { Sprint, SprintStatus, SprintRetrospective, RetroItem } from '../types/sprint';
import { UserStory, AcceptanceCriterion, StoryStatus } from '../types/backlog';
import { Task, TaskStatus, PriorityLevel } from '../types/task';
import { Risk, RiskImpact, RiskProbability, RiskStatus, Dependency, DependencyStatus } from '../types/risk';
import { DecisionItem, DecisionStatus } from '../types/decision';
import { ChatSession, ChatMessage, FileAttachment } from '../types/requirement';
import { validateFile, sanitizeFileName, formatFileSize } from '../lib/fileValidation';

// Helper status converters
export function toDbTaskStatus(status: TaskStatus): string {
  switch (status) {
    case 'To Do': return 'todo';
    case 'In Progress': return 'in_progress';
    case 'Review': return 'review';
    case 'Done': return 'done';
    default: return 'todo';
  }
}

export function fromDbTaskStatus(status: string): TaskStatus {
  switch (status?.toLowerCase()) {
    case 'todo': return 'To Do';
    case 'in_progress': return 'In Progress';
    case 'review': return 'Review';
    case 'done': return 'Done';
    default: return 'To Do';
  }
}

export function toDbSprintStatus(status: SprintStatus): string {
  return status.toLowerCase();
}

export function fromDbSprintStatus(status: string): SprintStatus {
  switch (status?.toLowerCase()) {
    case 'active': return 'Active';
    case 'completed': return 'Completed';
    case 'planned':
    default: return 'Planned';
  }
}

export function formatStoryNumber(storyNumber?: number, fallbackId: string = ''): string {
  if (storyNumber !== undefined && storyNumber !== null) {
    return `US-${String(storyNumber).padStart(3, '0')}`;
  }
  return fallbackId;
}

export function formatTaskNumber(taskNumber?: number, fallbackId: string = ''): string {
  if (taskNumber !== undefined && taskNumber !== null) {
    return `T-${String(taskNumber).padStart(3, '0')}`;
  }
  return fallbackId;
}

export const supabaseService = {
  // ==========================================
  // PROJECTS & MEMBERS
  // ==========================================
  async fetchProjects(): Promise<Project[]> {
    const supabase = getSupabase();
    const { data: projectRows, error: projErr } = await supabase
      .from('projects')
      .select('*')
      .order('created_at', { ascending: false });

    if (projErr) throw projErr;
    if (!projectRows || projectRows.length === 0) return [];

    const projectIds = projectRows.map((p) => p.id);
    const { data: memberRows, error: memErr } = await supabase
      .from('project_members')
      .select('*')
      .in('project_id', projectIds);

    if (memErr) console.warn('Could not load project members:', memErr);

    const membersByProject: Record<string, TeamMember[]> = {};
    (memberRows || []).forEach((m) => {
      if (!membersByProject[m.project_id]) {
        membersByProject[m.project_id] = [];
      }
      const initials = m.name
        ? m.name.split(' ').map((n: string) => n[0]).join('').slice(0, 2).toUpperCase()
        : 'TM';
      membersByProject[m.project_id].push({
        id: m.id,
        name: m.name,
        email: m.email,
        role: m.role || 'Contributor',
        avatarInitials: initials,
      });
    });

    // Load project documents
    const { data: docRows, error: docErr } = await supabase
      .from('project_documents')
      .select('*')
      .in('project_id', projectIds)
      .order('created_at', { ascending: false });

    if (docErr) console.warn('Could not load project documents:', docErr);

    const docsByProject: Record<string, ProjectDocument[]> = {};
    (docRows || []).forEach((d) => {
      if (!docsByProject[d.project_id]) {
        docsByProject[d.project_id] = [];
      }
      docsByProject[d.project_id].push({
        id: d.id,
        name: d.file_name,
        size: formatFileSize(Number(d.file_size) || 0),
        uploadedAt: d.created_at ? new Date(d.created_at).toISOString().split('T')[0] : '',
        type: d.mime_type || 'document',
        filePath: d.file_path,
        fileSize: Number(d.file_size) || 0,
        mimeType: d.mime_type,
      });
    });

    return projectRows.map((row) => ({
      id: row.id,
      name: row.name,
      description: row.description || '',
      goal: row.goal || '',
      projectType: (row.project_type || 'Agile Scrum') as ProjectType,
      startDate: row.start_date || new Date().toISOString().split('T')[0],
      endDate: row.target_date || new Date().toISOString().split('T')[0],
      projectManager: row.project_manager || 'Alex Morgan',
      teamMembers: membersByProject[row.id] || [],
      documents: docsByProject[row.id] || [],
      status: 'On Track',
      createdAt: row.created_at,
      updatedAt: row.created_at,
      isArchived: Boolean(row.archived),
    }));
  },

  async createProject(
    data: Omit<Project, 'id' | 'createdAt' | 'updatedAt' | 'status'>
  ): Promise<Project> {
    const supabase = getSupabase();
    const insertPayload: Record<string, any> = {
      name: data.name,
      description: data.description,
      goal: data.goal,
      project_type: data.projectType,
      start_date: data.startDate,
      target_date: data.endDate,
      project_manager: data.projectManager,
      archived: Boolean(data.isArchived),
    };

    const { data: created, error } = await supabase
      .from('projects')
      .insert(insertPayload)
      .select()
      .single();

    if (error) throw error;

    // Insert team members if any
    const createdMembers: TeamMember[] = [];
    if (data.teamMembers && data.teamMembers.length > 0) {
      const memberPayloads = data.teamMembers.map((m) => ({
        project_id: created.id,
        name: m.name,
        email: m.email,
        role: m.role,
      }));
      const { data: insertedMembers, error: memErr } = await supabase
        .from('project_members')
        .insert(memberPayloads)
        .select();

      if (!memErr && insertedMembers) {
        insertedMembers.forEach((m) => {
          const initials = m.name.split(' ').map((n: string) => n[0]).join('').slice(0, 2).toUpperCase();
          createdMembers.push({
            id: m.id,
            name: m.name,
            email: m.email,
            role: m.role,
            avatarInitials: initials,
          });
        });
      }
    }

    return {
      id: created.id,
      name: created.name,
      description: created.description || '',
      goal: created.goal || '',
      projectType: (created.project_type || 'Agile Scrum') as ProjectType,
      startDate: created.start_date,
      endDate: created.target_date,
      projectManager: created.project_manager,
      teamMembers: createdMembers.length > 0 ? createdMembers : data.teamMembers || [],
      documents: [],
      status: 'On Track',
      createdAt: created.created_at,
      updatedAt: created.created_at,
      isArchived: Boolean(created.archived),
    };
  },

  async updateProject(id: string, updates: Partial<Project>): Promise<void> {
    const supabase = getSupabase();
    const dbUpdates: Record<string, any> = {};
    if (updates.name !== undefined) dbUpdates.name = updates.name;
    if (updates.description !== undefined) dbUpdates.description = updates.description;
    if (updates.goal !== undefined) dbUpdates.goal = updates.goal;
    if (updates.projectType !== undefined) dbUpdates.project_type = updates.projectType;
    if (updates.startDate !== undefined) dbUpdates.start_date = updates.startDate;
    if (updates.endDate !== undefined) dbUpdates.target_date = updates.endDate;
    if (updates.projectManager !== undefined) dbUpdates.project_manager = updates.projectManager;
    if (updates.isArchived !== undefined) dbUpdates.archived = updates.isArchived;

    if (Object.keys(dbUpdates).length > 0) {
      const { error } = await supabase.from('projects').update(dbUpdates).eq('id', id);
      if (error) throw error;
    }
  },

  async deleteProject(id: string): Promise<void> {
    const supabase = getSupabase();
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user?.id) {
        await this.deleteProjectFiles(user.id, id);
      }
    } catch (cleanErr) {
      console.warn('Storage cleanup warning during deleteProject:', cleanErr);
    }
    const { error } = await supabase.from('projects').delete().eq('id', id);
    if (error) throw error;
  },

  // ==========================================
  // SPRINTS
  // ==========================================
  async fetchSprints(projectId?: string): Promise<Sprint[]> {
    const supabase = getSupabase();
    let query = supabase.from('sprints').select('*').order('created_at', { ascending: true });
    if (projectId) {
      query = query.eq('project_id', projectId);
    }
    const { data, error } = await query;
    if (error) throw error;

    return (data || []).map((row) => ({
      id: row.id,
      projectId: row.project_id,
      name: row.name,
      goal: row.goal || '',
      startDate: row.start_date,
      endDate: row.end_date,
      status: fromDbSprintStatus(row.status),
      storyIds: [],
      createdAt: row.created_at,
    }));
  },

  async createSprint(sprint: Omit<Sprint, 'id' | 'createdAt'>): Promise<Sprint> {
    const supabase = getSupabase();
    const dbStatus = toDbSprintStatus(sprint.status);

    const { data, error } = await supabase
      .from('sprints')
      .insert({
        project_id: sprint.projectId,
        name: sprint.name,
        goal: sprint.goal,
        start_date: sprint.startDate,
        end_date: sprint.endDate,
        status: dbStatus,
      })
      .select()
      .single();

    if (error) {
      if (error.message?.includes('duplicate') || error.code === '23505' || error.message?.includes('active')) {
        throw new Error('Another sprint is already active in this project.');
      }
      throw error;
    }

    return {
      id: data.id,
      projectId: data.project_id,
      name: data.name,
      goal: data.goal || '',
      startDate: data.start_date,
      endDate: data.end_date,
      status: fromDbSprintStatus(data.status),
      storyIds: sprint.storyIds || [],
      createdAt: data.created_at,
    };
  },

  async updateSprint(id: string, updates: Partial<Sprint>): Promise<void> {
    const supabase = getSupabase();
    const dbUpdates: Record<string, any> = {};
    if (updates.name !== undefined) dbUpdates.name = updates.name;
    if (updates.goal !== undefined) dbUpdates.goal = updates.goal;
    if (updates.startDate !== undefined) dbUpdates.start_date = updates.startDate;
    if (updates.endDate !== undefined) dbUpdates.end_date = updates.endDate;
    if (updates.status !== undefined) dbUpdates.status = toDbSprintStatus(updates.status);

    const { error } = await supabase.from('sprints').update(dbUpdates).eq('id', id);
    if (error) {
      if (error.message?.includes('duplicate') || error.code === '23505' || error.message?.includes('active')) {
        throw new Error('Another sprint is already active in this project.');
      }
      throw error;
    }
  },

  // ==========================================
  // USER STORIES
  // ==========================================
  async fetchUserStories(projectId?: string): Promise<UserStory[]> {
    const supabase = getSupabase();
    let query = supabase.from('user_stories').select('*').order('sort_order', { ascending: true });
    if (projectId) {
      query = query.eq('project_id', projectId);
    }
    const { data, error } = await query;
    if (error) throw error;

    return (data || []).map((row) => ({
      id: row.id,
      storyNumber: row.story_number,
      displayNumber: formatStoryNumber(row.story_number, row.id),
      projectId: row.project_id,
      title: row.title,
      description: row.description || '',
      priority: (row.priority || 'Medium') as PriorityLevel,
      storyPoints: row.story_points ?? 3,
      status: (row.status || 'Backlog') as StoryStatus,
      acceptanceCriteria: Array.isArray(row.acceptance_criteria)
        ? row.acceptance_criteria
        : [],
      relatedRequirement: row.related_requirement || undefined,
      sprintId: row.sprint_id || undefined,
      createdAt: row.created_at,
      updatedAt: row.created_at,
    }));
  },

  async createUserStory(story: Omit<UserStory, 'id' | 'createdAt' | 'updatedAt'>): Promise<UserStory> {
    const supabase = getSupabase();
    // Do NOT generate story_number on client; DB trigger auto-assigns it
    const { data, error } = await supabase
      .from('user_stories')
      .insert({
        project_id: story.projectId,
        title: story.title,
        description: story.description,
        priority: story.priority,
        story_points: story.storyPoints,
        status: story.status || 'Backlog',
        acceptance_criteria: story.acceptanceCriteria || [],
        related_requirement: story.relatedRequirement || null,
        sprint_id: story.sprintId || null,
        sort_order: 0,
      })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      storyNumber: data.story_number,
      displayNumber: formatStoryNumber(data.story_number, data.id),
      projectId: data.project_id,
      title: data.title,
      description: data.description || '',
      priority: data.priority as PriorityLevel,
      storyPoints: data.story_points ?? 3,
      status: data.status as StoryStatus,
      acceptanceCriteria: data.acceptance_criteria || [],
      relatedRequirement: data.related_requirement || undefined,
      sprintId: data.sprint_id || undefined,
      createdAt: data.created_at,
      updatedAt: data.created_at,
    };
  },

  async updateUserStory(id: string, updates: Partial<UserStory>): Promise<void> {
    const supabase = getSupabase();
    const dbUpdates: Record<string, any> = {};
    if (updates.title !== undefined) dbUpdates.title = updates.title;
    if (updates.description !== undefined) dbUpdates.description = updates.description;
    if (updates.priority !== undefined) dbUpdates.priority = updates.priority;
    if (updates.storyPoints !== undefined) dbUpdates.story_points = updates.storyPoints;
    if (updates.status !== undefined) dbUpdates.status = updates.status;
    if (updates.acceptanceCriteria !== undefined) dbUpdates.acceptance_criteria = updates.acceptanceCriteria;
    if (updates.relatedRequirement !== undefined) dbUpdates.related_requirement = updates.relatedRequirement;
    if (updates.sprintId !== undefined) dbUpdates.sprint_id = updates.sprintId || null;

    const { error } = await supabase.from('user_stories').update(dbUpdates).eq('id', id);
    if (error) throw error;
  },

  async deleteUserStory(id: string): Promise<void> {
    const supabase = getSupabase();
    const { error } = await supabase.from('user_stories').delete().eq('id', id);
    if (error) throw error;
  },

  // ==========================================
  // TASKS & STATUS HISTORY
  // ==========================================
  async fetchTasks(projectId?: string): Promise<Task[]> {
    const supabase = getSupabase();
    let query = supabase.from('tasks').select('*').order('created_at', { ascending: true });
    if (projectId) {
      query = query.eq('project_id', projectId);
    }
    const { data, error } = await query;
    if (error) throw error;

    return (data || []).map((row, index) => {
      const assignee = row.assignee || 'Unassigned';
      const initials = assignee.split(' ').map((n: string) => n[0]).join('').slice(0, 2).toUpperCase() || 'UN';

      return {
        id: row.id,
        taskNumber: row.task_number,
        displayNumber: formatTaskNumber(row.task_number, row.id),
        title: row.title,
        description: row.description || '',
        status: fromDbTaskStatus(row.status),
        priority: (row.priority || 'Medium') as PriorityLevel,
        assigneeName: assignee,
        assigneeInitials: initials,
        dueDate: row.due_date || new Date().toISOString().split('T')[0],
        storyId: row.story_id || undefined,
        projectId: row.project_id,
        sprintId: row.sprint_id || undefined,
        isBlocked: Boolean(row.is_blocked),
        blockedReason: row.blocked_reason || undefined,
        order: index,
        createdAt: row.created_at,
      };
    });
  },

  async createTask(task: Omit<Task, 'id' | 'createdAt' | 'order'>): Promise<Task> {
    const supabase = getSupabase();
    // Do NOT generate task_number on client; DB trigger auto-assigns it
    const { data, error } = await supabase
      .from('tasks')
      .insert({
        project_id: task.projectId,
        story_id: task.storyId || null,
        sprint_id: task.sprintId || null,
        title: task.title,
        description: task.description || '',
        status: toDbTaskStatus(task.status),
        priority: task.priority || 'Medium',
        assignee: task.assigneeName || 'Alex Morgan',
        due_date: task.dueDate || new Date().toISOString().split('T')[0],
        is_blocked: Boolean(task.isBlocked),
        blocked_reason: task.blockedReason || null,
      })
      .select()
      .single();

    if (error) throw error;

    const assignee = data.assignee || 'Alex Morgan';
    const initials = assignee.split(' ').map((n: string) => n[0]).join('').slice(0, 2).toUpperCase();

    return {
      id: data.id,
      taskNumber: data.task_number,
      displayNumber: formatTaskNumber(data.task_number, data.id),
      title: data.title,
      description: data.description || '',
      status: fromDbTaskStatus(data.status),
      priority: data.priority as PriorityLevel,
      assigneeName: assignee,
      assigneeInitials: initials,
      dueDate: data.due_date,
      storyId: data.story_id || undefined,
      projectId: data.project_id,
      sprintId: data.sprint_id || undefined,
      isBlocked: Boolean(data.is_blocked),
      blockedReason: data.blocked_reason || undefined,
      order: 0,
      createdAt: data.created_at,
    };
  },

  async updateTask(
    id: string,
    updates: Partial<Task>,
    currentTask?: Task
  ): Promise<void> {
    const supabase = getSupabase();
    const dbUpdates: Record<string, any> = {
      updated_at: new Date().toISOString(),
    };

    if (updates.title !== undefined) dbUpdates.title = updates.title;
    if (updates.description !== undefined) dbUpdates.description = updates.description;
    if (updates.status !== undefined) dbUpdates.status = toDbTaskStatus(updates.status);
    if (updates.priority !== undefined) dbUpdates.priority = updates.priority;
    if (updates.assigneeName !== undefined) dbUpdates.assignee = updates.assigneeName;
    if (updates.dueDate !== undefined) dbUpdates.due_date = updates.dueDate;
    if (updates.storyId !== undefined) dbUpdates.story_id = updates.storyId || null;
    if (updates.sprintId !== undefined) dbUpdates.sprint_id = updates.sprintId || null;
    if (updates.isBlocked !== undefined) dbUpdates.is_blocked = updates.isBlocked;
    if (updates.blockedReason !== undefined) dbUpdates.blocked_reason = updates.blockedReason || null;

    const { error } = await supabase.from('tasks').update(dbUpdates).eq('id', id);
    if (error) throw error;

    // Record task status transition in task_status_history
    if (updates.status && currentTask && updates.status !== currentTask.status) {
      const fromStatus = toDbTaskStatus(currentTask.status);
      const toStatus = toDbTaskStatus(updates.status);
      const { error: histErr } = await supabase.from('task_status_history').insert({
        task_id: id,
        from_status: fromStatus,
        to_status: toStatus,
        changed_at: new Date().toISOString(),
      });
      if (histErr) {
        console.warn('Failed to record task_status_history:', histErr);
      }
    }
  },

  async deleteTask(id: string): Promise<void> {
    const supabase = getSupabase();
    const { error } = await supabase.from('tasks').delete().eq('id', id);
    if (error) throw error;
  },

  // ==========================================
  // RISKS
  // ==========================================
  async fetchRisks(projectId?: string): Promise<Risk[]> {
    const supabase = getSupabase();
    let query = supabase.from('risks').select('*').order('created_at', { ascending: false });
    if (projectId) {
      query = query.eq('project_id', projectId);
    }
    const { data, error } = await query;
    if (error) throw error;

    return (data || []).map((row) => ({
      id: row.id,
      projectId: row.project_id,
      title: row.title,
      description: row.description || '',
      impact: (row.impact || 'Medium') as RiskImpact,
      probability: (row.probability || 'Medium') as RiskProbability,
      status: (row.status || 'Open') as RiskStatus,
      mitigationPlan: row.mitigation_plan || '',
      owner: row.owner || 'Project Lead',
      isAiSuggested: Boolean(row.ai_suggested),
      confirmed: Boolean(row.confirmed),
      createdAt: row.created_at,
    }));
  },

  async createRisk(risk: Omit<Risk, 'id' | 'createdAt'>): Promise<Risk> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('risks')
      .insert({
        project_id: risk.projectId,
        title: risk.title,
        description: risk.description || '',
        impact: risk.impact,
        probability: risk.probability,
        status: risk.status || 'Open',
        mitigation_plan: risk.mitigationPlan || '',
        owner: risk.owner || 'Project Lead',
        ai_suggested: Boolean(risk.isAiSuggested),
        confirmed: risk.isAiSuggested ? Boolean(risk.confirmed) : true,
      })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      projectId: data.project_id,
      title: data.title,
      description: data.description || '',
      impact: data.impact as RiskImpact,
      probability: data.probability as RiskProbability,
      status: data.status as RiskStatus,
      mitigationPlan: data.mitigation_plan || '',
      owner: data.owner,
      isAiSuggested: Boolean(data.ai_suggested),
      confirmed: Boolean(data.confirmed),
      createdAt: data.created_at,
    };
  },

  async updateRisk(id: string, updates: Partial<Risk>): Promise<void> {
    const supabase = getSupabase();
    const dbUpdates: Record<string, any> = {};
    if (updates.title !== undefined) dbUpdates.title = updates.title;
    if (updates.description !== undefined) dbUpdates.description = updates.description;
    if (updates.impact !== undefined) dbUpdates.impact = updates.impact;
    if (updates.probability !== undefined) dbUpdates.probability = updates.probability;
    if (updates.status !== undefined) dbUpdates.status = updates.status;
    if (updates.mitigationPlan !== undefined) dbUpdates.mitigation_plan = updates.mitigationPlan;
    if (updates.owner !== undefined) dbUpdates.owner = updates.owner;
    if (updates.confirmed !== undefined) dbUpdates.confirmed = updates.confirmed;

    const { error } = await supabase.from('risks').update(dbUpdates).eq('id', id);
    if (error) throw error;
  },

  async deleteRisk(id: string): Promise<void> {
    const supabase = getSupabase();
    const { error } = await supabase.from('risks').delete().eq('id', id);
    if (error) throw error;
  },

  // ==========================================
  // DEPENDENCIES
  // ==========================================
  async fetchDependencies(projectId?: string): Promise<Dependency[]> {
    const supabase = getSupabase();
    let query = supabase.from('dependencies').select('*').order('created_at', { ascending: false });
    if (projectId) {
      query = query.eq('project_id', projectId);
    }
    const { data, error } = await query;
    if (error) throw error;

    return (data || []).map((row) => ({
      id: row.id,
      projectId: row.project_id,
      title: row.title,
      sourceItem: row.title,
      dependentItem: row.depends_on || '',
      status: (row.status || 'Pending') as DependencyStatus,
      owner: 'Engineering Team',
      dueDate: row.created_at?.split('T')[0] || '',
      createdAt: row.created_at,
    }));
  },

  async createDependency(dep: Omit<Dependency, 'id' | 'createdAt'>): Promise<Dependency> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('dependencies')
      .insert({
        project_id: dep.projectId,
        title: dep.title || dep.sourceItem,
        depends_on: dep.dependentItem || '',
        status: dep.status || 'Pending',
      })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      projectId: data.project_id,
      title: data.title,
      sourceItem: data.title,
      dependentItem: data.depends_on || '',
      status: data.status as DependencyStatus,
      owner: dep.owner || 'Engineering Team',
      dueDate: dep.dueDate || '',
      createdAt: data.created_at,
    };
  },

  async updateDependency(id: string, updates: Partial<Dependency>): Promise<void> {
    const supabase = getSupabase();
    const dbUpdates: Record<string, any> = {};
    if (updates.title !== undefined || updates.sourceItem !== undefined) {
      dbUpdates.title = updates.title || updates.sourceItem;
    }
    if (updates.dependentItem !== undefined) {
      dbUpdates.depends_on = updates.dependentItem;
    }
    if (updates.status !== undefined) {
      dbUpdates.status = updates.status;
    }

    const { error } = await supabase.from('dependencies').update(dbUpdates).eq('id', id);
    if (error) throw error;
  },

  async deleteDependency(id: string): Promise<void> {
    const supabase = getSupabase();
    const { error } = await supabase.from('dependencies').delete().eq('id', id);
    if (error) throw error;
  },

  // ==========================================
  // DECISIONS
  // ==========================================
  async fetchDecisions(projectId?: string): Promise<DecisionItem[]> {
    const supabase = getSupabase();
    let query = supabase.from('decisions').select('*').order('created_at', { ascending: false });
    if (projectId) {
      query = query.eq('project_id', projectId);
    }
    const { data, error } = await query;
    if (error) throw error;

    return (data || []).map((row) => ({
      id: row.id,
      projectId: row.project_id,
      item: row.item,
      description: row.description || '',
      owner: row.owner || 'Alex Morgan',
      requestedFrom: row.requested_from || 'Client PO',
      dueDate: row.due_date || new Date().toISOString().split('T')[0],
      status: (row.status || 'Pending') as DecisionStatus,
      urgency: 'High',
      createdAt: row.created_at,
    }));
  },

  async createDecision(decision: Omit<DecisionItem, 'id' | 'createdAt'>): Promise<DecisionItem> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('decisions')
      .insert({
        project_id: decision.projectId,
        item: decision.item,
        description: decision.description || '',
        owner: decision.owner,
        requested_from: decision.requestedFrom,
        due_date: decision.dueDate,
        status: decision.status || 'Pending',
      })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      projectId: data.project_id,
      item: data.item,
      description: data.description || '',
      owner: data.owner,
      requestedFrom: data.requested_from,
      dueDate: data.due_date,
      status: data.status as DecisionStatus,
      urgency: decision.urgency || 'High',
      createdAt: data.created_at,
    };
  },

  async updateDecision(id: string, updates: Partial<DecisionItem>): Promise<void> {
    const supabase = getSupabase();
    const dbUpdates: Record<string, any> = {};
    if (updates.item !== undefined) dbUpdates.item = updates.item;
    if (updates.description !== undefined) dbUpdates.description = updates.description;
    if (updates.owner !== undefined) dbUpdates.owner = updates.owner;
    if (updates.requestedFrom !== undefined) dbUpdates.requested_from = updates.requestedFrom;
    if (updates.dueDate !== undefined) dbUpdates.due_date = updates.dueDate;
    if (updates.status !== undefined) dbUpdates.status = updates.status;

    const { error } = await supabase.from('decisions').update(dbUpdates).eq('id', id);
    if (error) throw error;
  },

  async deleteDecision(id: string): Promise<void> {
    const supabase = getSupabase();
    const { error } = await supabase.from('decisions').delete().eq('id', id);
    if (error) throw error;
  },

  // ==========================================
  // RETROSPECTIVES
  // ==========================================
  async fetchRetrospectives(projectId?: string): Promise<SprintRetrospective[]> {
    const supabase = getSupabase();
    let query = supabase.from('retrospectives').select('*').order('created_at', { ascending: false });
    if (projectId) {
      query = query.eq('project_id', projectId);
    }
    const { data, error } = await query;
    if (error) throw error;

    return (data || []).map((row) => ({
      id: row.id,
      sprintId: row.sprint_id,
      projectId: row.project_id,
      whatWentWell: Array.isArray(row.went_well) ? row.went_well : [],
      whatDidntGoWell: Array.isArray(row.didnt_go_well) ? row.didnt_go_well : [],
      whatToImprove: Array.isArray(row.improve) ? row.improve : [],
      actionItems: [],
      savedAt: row.created_at,
    }));
  },

  async saveRetrospective(
    retro: Omit<SprintRetrospective, 'id' | 'savedAt'>
  ): Promise<SprintRetrospective> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('retrospectives')
      .insert({
        project_id: retro.projectId,
        sprint_id: retro.sprintId,
        went_well: retro.whatWentWell || [],
        didnt_go_well: retro.whatDidntGoWell || [],
        improve: retro.whatToImprove || [],
      })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      sprintId: data.sprint_id,
      projectId: data.project_id,
      whatWentWell: data.went_well || [],
      whatDidntGoWell: data.didnt_go_well || [],
      whatToImprove: data.improve || [],
      actionItems: retro.actionItems || [],
      savedAt: data.created_at,
    };
  },

  // ==========================================
  // REPORTS
  // ==========================================
  async saveReport(
    projectId: string,
    reportType: string,
    title: string,
    content: string
  ): Promise<any> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('reports')
      .insert({
        project_id: projectId,
        report_type: reportType,
        title,
        content,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  // ==========================================
  // CHATS & MESSAGES (Requirements Page)
  // ==========================================
  async fetchChats(): Promise<ChatSession[]> {
    const supabase = getSupabase();
    const { data: chatRows, error: chatErr } = await supabase
      .from('chats')
      .select('*')
      .order('updated_at', { ascending: false });

    if (chatErr) throw chatErr;
    if (!chatRows || chatRows.length === 0) return [];

    const chatIds = chatRows.map((c) => c.id);
    const { data: msgRows, error: msgErr } = await supabase
      .from('messages')
      .select('*')
      .in('chat_id', chatIds)
      .order('created_at', { ascending: true });

    if (msgErr) console.warn('Could not load chat messages:', msgErr);

    const msgsByChat: Record<string, ChatMessage[]> = {};
    (msgRows || []).forEach((m) => {
      if (!msgsByChat[m.chat_id]) {
        msgsByChat[m.chat_id] = [];
      }
      msgsByChat[m.chat_id].push({
        id: m.id,
        sender: m.role === 'user' ? 'user' : 'assistant',
        content: m.content,
        timestamp: new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        attachments: Array.isArray(m.attachments) ? m.attachments : undefined,
      });
    });

    return chatRows.map((c) => ({
      id: c.id,
      title: c.title,
      createdAt: c.created_at,
      updatedAt: c.updated_at,
      messages: msgsByChat[c.id] || [],
    }));
  },

  async createChat(title: string): Promise<ChatSession> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('chats')
      .insert({
        title,
        updated_at: new Date().toISOString(),
      })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      title: data.title,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
      messages: [],
    };
  },

  async renameChat(id: string, newTitle: string): Promise<void> {
    const supabase = getSupabase();
    const { error } = await supabase
      .from('chats')
      .update({ title: newTitle, updated_at: new Date().toISOString() })
      .eq('id', id);
    if (error) throw error;
  },

  async deleteChat(id: string): Promise<void> {
    const supabase = getSupabase();
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user?.id) {
        await this.deleteChatFiles(user.id, id);
      }
    } catch (cleanErr) {
      console.warn('Storage cleanup warning during deleteChat:', cleanErr);
    }
    const { error } = await supabase.from('chats').delete().eq('id', id);
    if (error) throw error;
  },

  async addChatMessage(
    chatId: string,
    role: 'user' | 'assistant',
    content: string,
    attachments?: any[]
  ): Promise<ChatMessage> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('messages')
      .insert({
        chat_id: chatId,
        role,
        content,
        attachments: attachments || null,
      })
      .select()
      .single();

    if (error) throw error;

    // Bump chat updated_at
    await supabase.from('chats').update({ updated_at: new Date().toISOString() }).eq('id', chatId);

    return {
      id: data.id,
      sender: role,
      content: data.content,
      timestamp: new Date(data.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      attachments: Array.isArray(data.attachments) ? data.attachments : undefined,
    };
  },

  async updateChatMessage(messageId: string, content: string): Promise<void> {
    const supabase = getSupabase();
    const { error } = await supabase
      .from('messages')
      .update({ content })
      .eq('id', messageId);
    if (error) throw error;
  },

  // ==========================================
  // PROJECT CHAT MESSAGES (Project Assistant)
  // ==========================================
  async fetchProjectChatMessages(projectId: string): Promise<{ id: string; sender: 'user' | 'assistant'; content: string; timestamp: string }[]> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('project_chat_messages')
      .select('*')
      .eq('project_id', projectId)
      .order('created_at', { ascending: true });

    if (error) throw error;

    return (data || []).map((m) => ({
      id: m.id,
      sender: m.role === 'user' ? 'user' : 'assistant',
      content: m.content,
      timestamp: new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    }));
  },

  async addProjectChatMessage(projectId: string, role: 'user' | 'assistant', content: string): Promise<{ id: string; sender: 'user' | 'assistant'; content: string; timestamp: string }> {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('project_chat_messages')
      .insert({
        project_id: projectId,
        role,
        content,
      })
      .select()
      .single();

    if (error) throw error;

    return {
      id: data.id,
      sender: role,
      content: data.content,
      timestamp: new Date(data.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
  },

  // ==========================================
  // STORAGE & DOCUMENTS (user-files bucket)
  // ==========================================

  /**
   * Generates a temporary signed URL (valid for 3600 seconds) for private storage access.
   * Never uses public URLs.
   */
  async createSignedUrl(filePath: string, expiresIn: number = 3600): Promise<string> {
    const supabase = getSupabase();
    const { data, error } = await supabase.storage
      .from('user-files')
      .createSignedUrl(filePath, expiresIn);

    if (error) {
      if (error.message?.includes('expired') || error.message?.includes('JWT') || error.message?.includes('unauthorized')) {
        throw new Error('Your session has expired. Please log in again to access this file.');
      }
      throw error;
    }

    if (!data?.signedUrl) {
      throw new Error('Unable to generate download URL for this file.');
    }

    return data.signedUrl;
  },

  /**
   * Uploads a chat attachment to user-files: {user_id}/chat/{chat_id}/{timestamp}-{sanitized_file_name}
   */
  async uploadChatAttachment(
    chatId: string,
    file: File
  ): Promise<{ name: string; size: number; type: string; path: string }> {
    const supabase = getSupabase();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      throw new Error('You must be signed in to upload files.');
    }

    const validation = validateFile(file);
    if (!validation.valid) {
      throw new Error(validation.error);
    }

    const sanitized = sanitizeFileName(file.name);
    const filePath = `${user.id}/chat/${chatId}/${Date.now()}-${sanitized}`;

    const { error: uploadError } = await supabase.storage
      .from('user-files')
      .upload(filePath, file, {
        cacheControl: '3600',
        upsert: false,
      });

    if (uploadError) {
      if (uploadError.message?.includes('expired') || uploadError.message?.includes('JWT')) {
        throw new Error('Your session has expired. Please sign in again.');
      }
      throw uploadError;
    }

    return {
      name: file.name,
      size: file.size,
      type: file.type || 'application/octet-stream',
      path: filePath,
    };
  },

  /**
   * Deletes all files under {user_id}/chat/{chat_id}/ from user-files bucket
   */
  async deleteChatFiles(userId: string, chatId: string): Promise<void> {
    const supabase = getSupabase();
    const folderPath = `${userId}/chat/${chatId}`;
    const { data: files, error: listError } = await supabase.storage
      .from('user-files')
      .list(folderPath);

    if (!listError && files && files.length > 0) {
      const pathsToDelete = files
        .filter((f) => f.name && f.name !== '.emptyFolderPlaceholder')
        .map((f) => `${folderPath}/${f.name}`);
      if (pathsToDelete.length > 0) {
        const { error: removeErr } = await supabase.storage
          .from('user-files')
          .remove(pathsToDelete);
        if (removeErr) console.warn('Could not remove chat files from storage:', removeErr);
      }
    }
  },

  /**
   * Uploads a document to user-files: {user_id}/projects/{project_id}/{timestamp}-{sanitized_file_name}
   * and inserts a row in project_documents(project_id, file_name, file_path, file_size, mime_type)
   */
  async uploadProjectDocument(projectId: string, file: File): Promise<ProjectDocument> {
    const supabase = getSupabase();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      throw new Error('You must be signed in to upload project documents.');
    }

    const validation = validateFile(file);
    if (!validation.valid) {
      throw new Error(validation.error);
    }

    const sanitized = sanitizeFileName(file.name);
    const filePath = `${user.id}/projects/${projectId}/${Date.now()}-${sanitized}`;

    const { error: uploadError } = await supabase.storage
      .from('user-files')
      .upload(filePath, file, {
        cacheControl: '3600',
        upsert: false,
      });

    if (uploadError) {
      if (uploadError.message?.includes('expired') || uploadError.message?.includes('JWT')) {
        throw new Error('Your session has expired. Please sign in again.');
      }
      throw uploadError;
    }

    const { data: docRow, error: insertError } = await supabase
      .from('project_documents')
      .insert({
        project_id: projectId,
        file_name: file.name,
        file_path: filePath,
        file_size: file.size,
        mime_type: file.type || 'application/octet-stream',
      })
      .select()
      .single();

    if (insertError) {
      // Rollback uploaded storage object on db failure
      await supabase.storage.from('user-files').remove([filePath]);
      throw insertError;
    }

    return {
      id: docRow.id,
      name: docRow.file_name,
      size: formatFileSize(docRow.file_size || file.size),
      uploadedAt: docRow.created_at
        ? new Date(docRow.created_at).toISOString().split('T')[0]
        : new Date().toISOString().split('T')[0],
      type: docRow.mime_type || 'document',
      filePath: docRow.file_path,
      fileSize: docRow.file_size || file.size,
      mimeType: docRow.mime_type,
    };
  },

  /**
   * Deletes a project document: removes the storage object and the project_documents row
   */
  async deleteProjectDocument(documentId: string, filePath?: string): Promise<void> {
    const supabase = getSupabase();
    if (filePath) {
      const { error: storageError } = await supabase.storage
        .from('user-files')
        .remove([filePath]);
      if (storageError) {
        console.warn('Storage delete warning:', storageError);
      }
    }

    const { error: dbError } = await supabase
      .from('project_documents')
      .delete()
      .eq('id', documentId);

    if (dbError) throw dbError;
  },

  /**
   * Deletes all files under {user_id}/projects/{project_id}/ and all project_documents rows
   */
  async deleteProjectFiles(userId: string, projectId: string): Promise<void> {
    const supabase = getSupabase();
    const folderPath = `${userId}/projects/${projectId}`;
    const { data: files, error: listError } = await supabase.storage
      .from('user-files')
      .list(folderPath);

    if (!listError && files && files.length > 0) {
      const pathsToDelete = files
        .filter((f) => f.name && f.name !== '.emptyFolderPlaceholder')
        .map((f) => `${folderPath}/${f.name}`);
      if (pathsToDelete.length > 0) {
        const { error: removeErr } = await supabase.storage
          .from('user-files')
          .remove(pathsToDelete);
        if (removeErr) console.warn('Could not remove project files from storage:', removeErr);
      }
    }

    // Also remove rows from project_documents
    await supabase.from('project_documents').delete().eq('project_id', projectId);
  },

  /**
   * Deletes a chat message and removes any associated storage attachments
   */
  async deleteChatMessage(messageId: string, attachments?: FileAttachment[]): Promise<void> {
    const supabase = getSupabase();
    if (attachments && attachments.length > 0) {
      const pathsToDelete = attachments
        .map((a) => a.path)
        .filter((p): p is string => Boolean(p));
      if (pathsToDelete.length > 0) {
        await supabase.storage.from('user-files').remove(pathsToDelete);
      }
    }
    const { error } = await supabase.from('messages').delete().eq('id', messageId);
    if (error) throw error;
  },
};
