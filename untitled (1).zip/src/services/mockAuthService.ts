import { User } from '../types/auth';

/**
 * Mock Authentication Service
 * 
 * In a production backend, replace these methods with Firebase Auth,
 * Google Workspace OAuth, or your custom Express/FastAPI session tokens.
 */
export const mockAuthService = {
  async signInWithEmail(email: string, _password: string): Promise<User> {
    // Simulate network latency (250ms)
    await new Promise((resolve) => setTimeout(resolve, 250));

    // Extract human-friendly name from email
    const namePart = email.split('@')[0];
    const capitalizedName = namePart
      .replace(/[._-]/g, ' ')
      .replace(/\b\w/g, (char) => char.toUpperCase());

    return {
      id: `usr-${Date.now().toString(36)}`,
      name: capitalizedName || 'Project Lead',
      email,
      isGuest: false,
      role: 'Project Manager',
      avatarUrl: undefined,
    };
  },

  async registerWithEmail(email: string, _password: string, name?: string): Promise<User> {
    await new Promise((resolve) => setTimeout(resolve, 300));
    const finalName = name || email.split('@')[0].replace(/[._-]/g, ' ');

    return {
      id: `usr-${Date.now().toString(36)}`,
      name: finalName,
      email,
      isGuest: false,
      role: 'Scrum Master',
      avatarUrl: undefined,
    };
  },

  async signInWithGoogle(): Promise<User> {
    // UI-only mock for Google OAuth
    await new Promise((resolve) => setTimeout(resolve, 300));

    return {
      id: 'usr-google-demo',
      name: 'Alex Morgan',
      email: 'alex.morgan@company.io',
      isGuest: false,
      role: 'Agile Product Owner',
      avatarUrl: undefined,
    };
  },

  createGuestUser(): User {
    return {
      id: `guest-${Math.random().toString(36).substring(2, 7)}`,
      name: 'Guest User',
      email: 'guest@agilemind.local',
      isGuest: true,
      role: 'Guest Collaborator',
    };
  },
};
